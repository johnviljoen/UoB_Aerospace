function [Pressure,CL,CD]=xfoilsolver(aerofoil,alpha,Re,Mach)
dlmwrite('tempaerofoil.dat',aerofoil,'newline','pc','delimiter',' ');
    %=========================================
    %  Xfoil integration
    %=========================================
    xf = XFOIL;
    xf.KeepFiles = false; % Set it to true to keep all intermediate files created (Airfoil, Polars, ...)
    xf.Visible = false;
    %create aerofoil
    xf.Airfoil = Airfoil('tempaerofoil.dat');
    delete tempaerofoil.dat
    %Add five filtering steps to smooth the airfoil coordinates and help convergence
    xf.addFiltering(5);
    %Switch to OPER mode, and set Reynolds = 3E7, Mach = 0.1
    xf.addOperation(Re, Mach);
    %Set maximum number of iterations
    xf.addIter(1000)
    %Initializate the calculations
    xf.addAlpha(0,true);
    %Create a new polar
    xf.addPolarFile(['Polar' num2str(xf.ID) '.txt']);
    
    %NOTE: Can Calculate a sequence of angle of attack
    xf.addAlpha(alpha);
    xf.addPressureFile(['Pressure' num2str(xf.ID) '.txt']);
    %Close the polar file
    xf.addClosePolarFile;
    %And finally add the action to quit XFOIL
    xf.addQuit;
    xf.run
    %disp('Running XFOIL, please wait...')
    finished = xf.wait(100);
    if finished
        %disp('XFOIL analysis finished.')
        xf.readPolars;
        
        CD=xf.Polars{1,1}.CD;
        CL=xf.Polars{1,1}.CL;
        
    else
        xf.kill;
    end
    %=========================================
    fid=fopen(['Pressure' num2str(xf.ID) '.txt']);
    Pressure=textscan(fid,'   %f  %f','HeaderLines',1);
    fclose(fid);
    Pressure=cell2mat(Pressure);
    delete(['Pressure' num2str(xf.ID) '.txt']);
    
%     figure; plot(Pressure(:,1),-Pressure(:,2));
%     CD
%     CL
end