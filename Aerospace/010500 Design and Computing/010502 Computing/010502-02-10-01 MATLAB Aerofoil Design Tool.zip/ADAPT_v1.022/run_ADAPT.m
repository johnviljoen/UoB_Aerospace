load('S100.mat');load('Aerofoils.mat');
ADAPT(S{4},NACA0012,[0.7,1e7,0])