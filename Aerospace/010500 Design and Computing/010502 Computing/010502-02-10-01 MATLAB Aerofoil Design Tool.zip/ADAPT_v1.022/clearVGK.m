function clearVGK(varargin)
%clear VGK files
%
%clear leftover VGK files from VGK directory

fclose('all');
%clear VGK files
keep={'vgkcon.exe','vgkv20.exe','.','..'};
cd('VGK')
L=dir;
for i=1:length(L)
    name=L(i).name;
    if sum(strcmp(name,keep))==0
        delete(name)
    end
end
cd('..')