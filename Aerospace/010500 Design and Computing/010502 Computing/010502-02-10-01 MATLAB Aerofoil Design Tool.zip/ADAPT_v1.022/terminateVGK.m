% status=dos('Taskkill /IM vgkcon.exe /F');
function terminateVGK(varargin)
task='Taskkill /IM vgkcon.exe /F';
startInfo = System.Diagnostics.ProcessStartInfo('cmd.exe', sprintf('/c "%s"', task));
startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;  %// if you want it invisible
proc = System.Diagnostics.Process.Start(startInfo);