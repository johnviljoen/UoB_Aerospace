function cp=readcp()
cp=importdata('euler\flowplt.plt');
cp=cp.textdata(7:3:(M.totvertices*3+4),1);
cp=str2double(cp);

end