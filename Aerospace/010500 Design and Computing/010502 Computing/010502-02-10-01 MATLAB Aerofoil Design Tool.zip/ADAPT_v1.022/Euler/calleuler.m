function calleuler

% to compile stand-alone, use:
% mcc -m calleuler.m -d 'C:\place'

% There are many other options for the solver, however this script only supports
% steady flow calculations.

% Determine Mach numer, angle of attack, timestep and iterations
prompt = {'M_{\infty}:','\alpha','CFL','N_{iterations}'};
dlg_title = 'Inputs for the Euler solver';
num_lines = 1;
% Defaults will be inappropriate for larger meshes
def = {'0.8','0.0','2.0','4000'};

options.Resize='on';
options.WindowStyle='normal';
% Allow latex formatting of the text box
options.Interpreter='tex';

% Input box
answer = inputdlg(prompt,dlg_title,num_lines,def,options);
% Extract results
mach = str2double(answer(1));
aoa = str2double(answer(2));
CFL = str2double(answer(3));
nit = str2double(answer(4));

fileflowsettings = fopen('settings','w');

% Write the input file for the flow solver
% Solver can run sweeps in M or AoA. Here we only run a single case.
% number of Mach numbers, Mach start, Mach increment
fprintf(fileflowsettings,'%s\t%f\t%s','1',mach,'0.025');
% number of AoAs, AoA start, AoA increment
fprintf(fileflowsettings,'\n%s\t%f\t%s','1',aoa,'0.25');
% Density. Leave this unchanged.
fprintf(fileflowsettings,'\n%s','1.2');
% Temperature. Leave unchanged - this is set to achieve p_inf~1
fprintf(fileflowsettings,'\n%s','2.9e-3');
% Gamma. Leave unchanged.
fprintf(fileflowsettings,'\n%s','1.4');
% Gas constant R. Leave.
fprintf(fileflowsettings,'\n%s','287.0');
% option 0 stops code after nit cycles, 1 stops after residual tolerance
% (here -3). Best to use 0.
fprintf(fileflowsettings,'\n%s\t%i\t%s','0',nit,'-3.0');
% CFL number used to set explicit timestep
fprintf(fileflowsettings,'\n%f',CFL);
% 2nd order dissipation constant
fprintf(fileflowsettings,'\n%s','1.0');
% 4th order dissipation constant
fprintf(fileflowsettings,'\n%s','0.05');
% Don't change these. They are switches to apply dissipation at each stage
% of the RK integration. It is best to apply at the 1st stage and then keep
% constant, so this setting is optimal.
fprintf(fileflowsettings,'\n%s\t%s\t%s\t%s','1','0','0','0');
% steady (0), unsteady (1)    no restart (0), restart (1)
fprintf(fileflowsettings,'\n%s\t%s','0','0');
% unsteady settings - not used here, but these are sensible defaults if
% they were used
fprintf(fileflowsettings,'\n%s\t%s\t%s\t%s','.0956','600','30','1.0');
% mesh motion settings - not used here
fprintf(fileflowsettings,'\n%s\t%s','5','2.0');
% aeroelastic option - not used here
fprintf(fileflowsettings,'\n%s','2');

fclose(fileflowsettings);

%data
%pause

% if a mesh exists, use that, otherwise make a new one
fullFileName=fullfile(cd, 'griduns')
if exist(fullfile(cd, 'griduns'), 'file')
  warningMessage = sprintf('Click OK to use existing mesh...', fullFileName);
  uiwait(msgbox(warningMessage));
else
  % Mesh does not exist.
  warningMessage = sprintf('Click OK to create mesh...', fullFileName);
  uiwait(msgbox(warningMessage));
  
  promptm = {'N_{levels}','N_{buffer}'};
  dlg_titlem = 'Inputs for the Cut-cell mesher';
  num_linesm = 1;
  defm = {'11','5'};

  optionsm.Resize='on';
  optionsm.WindowStyle='normal';
  optionsm.Interpreter='tex';

  answerm = inputdlg(promptm,dlg_titlem,num_linesm,defm,optionsm);
  %answer(1)
  % number of refinement levels
  nlev = str2double(answerm(1));
  % number of buffer stages (ie width) for each level
  nbuf = str2double(answerm(2));
  
  filemeshsettings = fopen('cutsettings','w');
 
  % write the mesher input file
  % initial number of points along each each (x and y) - here 3, followed
  % by boundary flag for farfield (0) or wall (1)
  fprintf(filemeshsettings,'%s\t%s\t%s\t%s','3','3','0','0');
  % lower left farfield point
  fprintf(filemeshsettings,'\n%s\t%s','-25','-25');
  % upper right farfield point
  fprintf(filemeshsettings,'\n%s\t%s','25','25');
  % this is a flag to offset the background mesh (to avoid having geometry
  % and mesh points coincident). Set to 1 to activate.
  fprintf(filemeshsettings,'\n%s','0');
  % number of mesh levels to use
  fprintf(filemeshsettings,'\n%i',nlev);
  % need to specify the buffer number for each level
  for i=1:nlev
      fprintf(filemeshsettings,'\n%i\t%i',i,nbuf);
  end

  fclose(filemeshsettings);
  
  status = system('CartCell.exe');
  
end

status = system('EulerFlow.exe');
% pproc just makes the colourful tecplot files (flowplt.plt), and cp.dat 
status = system('pproc.exe');

% read in and plot Cp vs x.
filename = 'cp.dat';
delimiterIn = ' ';
headerlinesIn = 1;
vals = importdata(filename,delimiterIn,headerlinesIn)
plot(vals.data(:,1),vals.data(:,3));

end



