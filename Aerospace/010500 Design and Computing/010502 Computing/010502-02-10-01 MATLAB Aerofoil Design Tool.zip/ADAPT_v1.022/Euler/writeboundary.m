function writeboundary(a)
boundary=fopen('boundary.dat','wt')
    %write header line
    fprintf(boundary,'%i',1)
    %write boundary length
    fprintf(boundary,'\n%i   %i\n%i',length(a(:,1)),length(a(:,1)),length(a(:,1)))
    %write boundary data
    fprintf(boundary,'\n%f\t%f',a')
    fclose(boundary)    
end