function M=importmesh()
temp=importdata('griduns',' ');
M.totcells=temp(1,1);
M.totedges=temp(1,2);
M.totvertices=temp(1,3);
temp=importdata('griduns',' ',1);
a=1;
b=M.totedges;
M.edgedata=temp.data(a:b,1:4);
a=a+M.totedges;
b=b+M.totvertices;
M.vertexdata=temp.data(a:b,1:3);
a=a+M.totvertices;
b=b+M.totcells;
M.celldata=temp.data(a:b,1);
end