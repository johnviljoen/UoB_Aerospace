function M=RBFmesh(S,a,M)
    writeboundary(a);
if nargin==2
    createmesh(a);
    M=importmesh;
else
    writemesh(M)    
end
    h.fig=figure('units','pixels',...
              'name','FFD',...
              'numbertitle','off',...
              'resizefcn',@resizefig);
    hold on;
    TAB_ON='RBF';
    rbf_main(0,0,'start');
    Length; P; R; H; cstaerofoil=[]; %extend scope
    h.wsrbf1=[];h.wsrbf2=[];
    
    %BASE BUTTONS===============================================
    h.exptext=uicontrol('Style','edit',...
     'Position',[80 10 200 20]);     
    h.export=uicontrol('string','Export',...
      'Position',[20 10 50 20],...
      'Callback',{@export,h.exptext});
    h.refresh=uicontrol('string','Refresh',...
      'Callback',@resizefig); 
    h.plotpres=uicontrol('string','Potential Flow',...
      'Callback',{@potflow, 1, 1});
    h.xfoil=uicontrol('string','XFoil',...
      'Callback',{@xfoillink, 2, 1});
    h.euler=uicontrol('string','Euler',...
      'Callback',@eulerlink);
    h.plotpresRe=uicontrol('style','text',...
     'string','Re =',...
     'BackgroundColor',[0.8 0.8 0.8]);
    h.plotpresalpha=uicontrol('style','text',...
     'string','alpha =',...
     'BackgroundColor',[0.8 0.8 0.8]);
    h.plotpresReedit=uicontrol('style','edit',...
     'string','1e5');
     %'callback',{@potflow, 0, a});
    h.plotpresalphaedit=uicontrol('style','edit',...
     'string','6');
     %'callback',{@potflow, 0, a});
     %=============================================================
         
function rbf_main(varargin)
    
    switch varargin{3}
        case 'start'
    [isaero,a]=checkaerofoil(a);
    
    Css=setCss(S);
    Aas=setAas(S,a);
    
    H=Aas/Css;
    iter=0;
    Length=length(S(:,1));
    optiter=0;
    firstid=1;
    firstopt=1;
    run_interact=1; %used to stop interact running inside itself
    for i=1:Length %set P
        P{i}=impoint(gca,S(i,:));
        addNewPositionCallback(P{i},@(pos) interact(pos, i));
        setPositionConstraintFcn(P{i},@(pos) constraintfunction(pos,i))
        h.ch(i)=uicontrol('style','checkbox',...
            'val',0,'visible','off');
    end
    %set rotation center
    h.rocen=impoint(gca,[mean2(S(:,1)) mean2(S(:,2))]); %rocen= rotation center
    set(h.rocen,'Visible','off');
    setColor(h.rocen,'green');
    
    pos_old=S;
    h.axes=get(get(0,'CurrentFigure'),'CurrentAxes');
    setpoints;
    set(h.axes, 'Units', 'pixels');
    setcbpos;
    
     h.reset=uicontrol('string','Reset',...
          'Callback',@resetpoints);
     h.group=uicontrol('Style','Toggle',...
         'String','Show Grouping',...
         'Value',0,...
         'Callback',@group);
     h.selectall=uicontrol('string','Select All',...
          'Callback',@selectall);
     h.clrselection=uicontrol('string','Clear Selection',...
          'Callback',@clrselection);
     h.rotate=uicontrol('Style','Toggle',...
         'String','Rotate',...
         'Value',0,...
         'Callback',@rotate);
     h.lastused=0; %initialise for later
     h.origaero=[]; %initialise for later
     h.targetaerofoil=[]; %initialise for later
     
     if isaero==0
         set(h.plotpres,'enable','off');
         set(h.plotpresReedit,'enable','off');
         set(h.plotpresalphaedit,'enable','off');
         set(h.xfoil,'enable','off');
         set(h.inversedesign,'enable','off');
         set(h.optimise,'enable','off');
     end
    
        case 'setcbpos'
            setcbpos;
    
        case 'off'
        if get(h.rbftab,'value')==1
        set(h.group,'visible','off');
        set(h.selectall,'visible','off');
        set(h.clrselection,'visible','off');
        set(h.rotate,'visible','off');
        set(h.reset,'visible','off');
        set(h.inversedesign,'visible','off');
        set(h.optimise,'enable','off');
        set(h.axes,'visible','off');
        for j=1:Length
        set(P{j},'visible','off');
        set(h.ch(j),'visible','off');
        end
        delete(R)
        R=[];
        set(h.rbftab,'value',0)
        end
    
        case 'on'
        set(h.rbftab,'value',1)
        if strcmp(TAB_ON,'RBF')==0
        TAB_ON='RBF';    
        set(h.group,'visible','on');
        set(h.selectall,'visible','on');
        set(h.clrselection,'visible','on');
        set(h.rotate,'visible','on');
        set(h.reset,'visible','on');
        set(h.inversedesign,'visible','on');
        set(h.optimise,'enable','on');
        set(h.axes,'visible','on');
        set(h.group,'value',0);
        
        for j=1:Length
        set(P{j},'visible','on');
        end
        if isempty(R)==0
            delete(R)
        end
        setpoints;
        resizefig;
        end
    end
     
% RBF FUNCTIONS =========================================================
function new_pos = constraintfunction(pos, j)
    if get(h.rotate, 'Value')==1
        cen=getPosition(h.rocen);
        r=norm(pos_old(j, :)-cen,2);
        theta=gettheta(pos-cen);
        new_pos=[r*cos(theta) r*sin(theta)] + cen;
    else
        new_pos=pos;
    end
end

function theta = gettheta(pos) %position about origin!!
        theta=atan(pos(2)/pos(1));
        if pos(1)<0
            theta = theta + pi;
        end   
end

function rotate(varargin)
    if get(h.rotate,'Value')==0
        set(h.rocen,{'visible'},{'off'});
    else
        set(h.rocen,{'visible'},{'on'});
    end
end

function group(varargin)
    if get(h.group,'Value')==0
        set(h.ch(:),{'visible'},{'off'});
    else
        set(h.ch(:),{'visible'},{'on'});
    end
end

function selectall(varargin)
        set(h.ch(:),'Value',1)
end

function clrselection(varargin)
        set(h.ch(:),'Value',0)
end
     
function setcbpos
    xlim = get(h.axes, 'XLim');
    ylim = get(h.axes, 'YLim');
    
    save_units = get(h.axes, 'Units');
    set(h.axes, 'Units', 'pixels')
    axes_position_in_pixels = get(h.axes,'Position');
    set(h.axes, 'Units', save_units)
    
    origin = [ xlim(1) ylim(1) ];
    corner = [ xlim(2) ylim(2) ];
    slope = corner - origin;
    
    for i=1:Length
        b=getPosition(P{i});
        normalized_position = (b(1:2) - origin) ./ slope;
        pos = axes_position_in_pixels(1:2) + ...
        normalized_position .* axes_position_in_pixels(3:4);
        pos=pos+[5 5];
        set(h.ch(i),'Position',[pos 14 14])
    end
end %set check box positions

function resetpoints(varargin)
     run_interact=0;
     for i=1:Length
         if i==Length
             run_interact=1;
         end
        setPosition(P{i},S(i,:));
        delete(R)
        setpoints; 
        setcbpos;
     end
     for l=1:Length %reset pos_old
        pos_old(l,:)=getPosition(P{l});
     end
     iter=0; optiter=0;
     if ishandle(h.origaero)==1
         delete(h.origaero)
     end
     if ishandle(h.targetaerofoil)==1
         delete(h.targetaerofoil)
     end
end

function setpoints
    %set(0,'CurrentFigure',h.fig)
    Q=zeros(Length+3,2);
    for i=1:Length
        Q(i+3,:) = getPosition(P{i});
    end
    a=H*Q; %key line; sets new point matrix
    R=plot(h.axes,a(:,1),a(:,2),'r');
end

function interact(varargin) %creates interactive loop for callback
    pos=varargin{1};
    j=varargin{2};
    if run_interact==1
        run_interact=0;
        if get(h.ch(j),'Value')==1
            if get(h.rotate,'Value')==1
                cen=getPosition(h.rocen);
                theta_change = gettheta(pos-cen)-gettheta(pos_old(j,:)-cen);
                for k=1:Length
                    if get(h.ch(k),'Value')==1 && k~=j
                        r=norm(getPosition(P{k})-cen,2);
                        theta=gettheta(getPosition(P{k})-cen);
                        theta=theta+theta_change;
                        setPosition(P{k},[r*cos(theta) r*sin(theta)] +cen );
                    end
                end
            else
            pos_change=pos-pos_old(j,:); %set change     
            for k=1:Length
                if get(h.ch(k),'Value')==1 && k~=j
                    setPosition(P{k},getPosition(P{k})+pos_change);
                end
            end
            end
        end
        for l=1:Length %set for next move
            pos_old(l,:)=getPosition(P{l});
        end
        delete(R)
        setpoints; 
        setcbpos;
        if isempty(findobj('name','Pressure distribution on aerofoil'))==0
            switch h.lastused
                case 2
            xfoillink(0,0,0,0);
                case 1
            potflow(0,0,0,0);
                otherwise
            end
        end
        run_interact=1;
    end
end
%=====================================================================
end

% SOLVER FUNCTIONS================================================
function [Pressure,CL,CD]=xfoilinterface(aerofoil, alpha, Re)
    xf=xfoilstart(aerofoil, alpha, Re);
    [Pressure,CL,CD]=xfoilfinish(xf);
end

function xf=xfoilstart(aerofoil, alpha, Re)
%ONLY USE FOR PARALLEL INSTANCES OF XFOIL
    dlmwrite('tempaerofoil.txt',aerofoil,'newline','pc','delimiter',' ');
    %=========================================
    %  Xfoil integration
    %=========================================
    xf = XFOIL;
    xf.KeepFiles = false; % Set it to true to keep all intermediate files created (Airfoil, Polars, ...)
    xf.Visible = false;
    %create aerofoil
    xf.Airfoil = Airfoil('tempaerofoil.txt');
    delete tempaerofoil.txt
    %Add five filtering steps to smooth the airfoil coordinates and help convergence
    xf.addFiltering(5);
    %Switch to OPER mode, and set Reynolds = 3E7, Mach = 0.1
    xf.addOperation(Re, 0);
    %Set maximum number of iterations
    xf.addIter(500)
    %Initializate the calculations
    xf.addAlpha(0,true);
    %Create a new polar
    xf.addPolarFile(['Polar' num2str(xf.ID) '.txt']);
    
    %NOTE: Can Calculate a sequence of angle of attack
    xf.addAlpha(alpha);
    xf.addPressureFile(['Pressure' num2str(xf.ID) '.txt']);
    %Close the polar file
    xf.addClosePolarFile;
    %And finally add the action to quit XFOIL
    xf.addQuit;
    xf.run
    %disp('Running XFOIL, please wait...')
end

function [Pressure,CL,CD]=xfoilfinish(xf)
%ONLY USE FOR PARALLEL INSTANCES OF XFOIL
finished = xf.wait(100);
    if finished
        %disp('XFOIL analysis finished.')
        xf.readPolars;
        
        CD=xf.Polars{1,1}.CD;
        CL=xf.Polars{1,1}.CL;
        
    else
        xf.kill;
    end
    %=========================================
    fid=fopen(['Pressure' num2str(xf.ID) '.txt']);
    Pressure=textscan(fid,'   %f  %f','HeaderLines',1);
    fclose(fid);
    Pressure=cell2mat(Pressure);
    delete(['Pressure' num2str(xf.ID) '.txt']);
end

function xfoillink(varargin)
    if varargin{3}==2
        h.lastused=2; %2==xfoil 1==potflow
    end
        %varargin{3}=2 => open if not already open
    if isempty(findobj('name','Pressure distribution on aerofoil'))==0 || varargin{3}==2
    Re=str2num(get(h.plotpresReedit,'string'));
    alpha=str2double(get(h.plotpresalphaedit,'string'));
    %Re=U/(1.36e-4); %U/kinematic viscosity of air at 20C
    switch TAB_ON
    case 'RBF'
        aerofoil = a;
    case 'CST'
        aerofoil = cstaerofoil;
    end
    [Pressure,CL,CD]=xfoilinterface(aerofoil, alpha, Re);
    if varargin{4}==1
        CD, CL
    end
    % PLOTS OF SURFACE QUANTITIES
    cut=floor(length(Pressure(:,1))/2);
    if isempty(findobj('name','Pressure distribution on aerofoil'))==1
        h.presfig=figure('menubar','none',...
            'numbertitle','off',...
            'name','Pressure distribution on aerofoil');
        clf;
        hold on;
        title('Pressure distribution on aerofoil');
        xlabel('x');
        ylabel('-Cp');
        h.presplot1=plot(Pressure(1:cut,1),-Pressure(1:cut,2),'c');
        h.presplot2=plot(Pressure(cut+1:end,1),-Pressure(cut+1:end,2),'m');
        h.presaxes=get(get(0,'CurrentFigure'),'CurrentAxes');
    else
        delete(h.presplot1);
        delete(h.presplot2);
        h.presplot1=plot(h.presaxes,Pressure(1:cut,1),-Pressure(1:cut,2),'c');
        h.presplot2=plot(h.presaxes,Pressure(cut+1:end,1),-Pressure(cut+1:end,2),'m');
    end
    end
end

function potflow(varargin)
if varargin{3}==1
    h.lastused=1; %2==xfoil 1==potflow
end
    %varargin{3}=1 => open if not already open
if isempty(findobj('name','Pressure distribution on aerofoil'))==0 || varargin{3}==1 
U=10;  %arbitary
alpha=str2double(get(h.plotpresalphaedit,'string'));
if varargin{4}==1
    printcl=1;
else
    printcl=0;
end
switch TAB_ON
    case 'RBF'
        aerofoil = a;
    case 'CST'
        aerofoil = cstaerofoil;
end
[cp, xcp npanel]=potflowsolver(aerofoil,U,alpha,printcl);
% PLOTS OF SURFACE QUANTITIES
if isempty(findobj('name','Pressure distribution on aerofoil'))==1
    h.presfig=figure('menubar','none',...
        'numbertitle','off',...
        'name','Pressure distribution on aerofoil');
    clf;
    hold on;
    title('Pressure distribution on aerofoil');
    xlabel('x');
    ylabel('-Cp');
    xlim([0 1])
    h.presplot1=plot(xcp(1:npanel/2),-cp(1:npanel/2),'m');
    h.presplot2=plot(xcp(npanel/2+1:npanel),-cp(npanel/2+1:npanel),'c');
    h.presaxes=get(get(0,'CurrentFigure'),'CurrentAxes');
else
    delete(h.presplot1);
    delete(h.presplot2);
    h.presplot1=plot(h.presaxes,xcp(1:npanel/2),-cp(1:npanel/2),'m');
    h.presplot2=plot(h.presaxes,xcp(npanel/2+1:npanel),-cp(npanel/2+1:npanel),'c');
end
end
end

function [cp, xcp, npanel]=potflowsolver(aerofoil,U,alpha,print)
    
fsvel=U;
fsadeg=alpha;
% FREE STREAM STUFF
fsarad=fsadeg*pi/180.;
u_fs_ana=fsvel*cos(fsarad);
w_fs_ana=fsvel*sin(fsarad);

% GET GEOMETRY PANEL INFORMATION
xpan=aerofoil;
npaer=length(aerofoil);
npanel=npaer-1;


% DEFINE PANEL END POINTS
for i=1:npanel
    pan_sta(i,1)=xpan(i,1);
    pan_sta(i,2)=xpan(i,2);
    pan_end(i,1)=xpan(i+1,1);
    pan_end(i,2)=xpan(i+1,2);
end

% DEFINE PANEL ANGLES
for i=1:npanel
    dx=pan_end(i,1)-pan_sta(i,1);
    dz=pan_end(i,2)-pan_sta(i,2);
    tht_pan(i)=atan2(dz,dx);
    pan_len(i)=sqrt(dx*dx+dz*dz);
end

% DEFINE CONTROL POINTS 
for i=1:npanel
    if i==1
    xcp(i)=(0.9*xpan(i,1)+0.1*xpan(i+1,1));
    zcp(i)=(0.9*xpan(i,2)+0.1*xpan(i+1,2));   
    elseif i==npanel  
    xcp(i)=(0.1*xpan(i,1)+0.9*xpan(i+1,1));
    zcp(i)=(0.1*xpan(i,2)+0.9*xpan(i+1,2));
    else
    xcp(i)=0.5*(xpan(i,1)+xpan(i+1,1));
    zcp(i)=0.5*(xpan(i,2)+xpan(i+1,2)); 
    end
end

% INFLUENCE COEFFICIENTS
for i=1:npanel
    for j=1:npanel
        %convert to local panel coordinates
        xx=xcp(i)-pan_sta(j,1);
        zz=zcp(i)-pan_sta(j,2);
        xend=pan_end(j,1)-pan_sta(j,1);
        zend=pan_end(j,2)-pan_sta(j,2);
        xpa=xx*cos(tht_pan(j))+zz*sin(tht_pan(j));
        zpa=-xx*sin(tht_pan(j))+zz*cos(tht_pan(j));
        x2=xend*cos(tht_pan(j))+zend*sin(tht_pan(j));
        z2=0;
        %find r1,r2,th1,th2 as in Katz and Plotkin 
        r1=sqrt(xpa*xpa+zpa*zpa);
        r2=sqrt((xpa-x2)*(xpa-x2)+zpa*zpa);
        th1=atan2(zpa,xpa);
        th2=atan2(zpa,(xpa-x2));
        %compute velocity in panel frame
        if i==j
            U1L=-0.5*(xpa-x2)/x2;
            U2L=0.5*xpa/x2;
            W1L=-1/(2.*pi());
            W2L=1/(2.*pi());
        else
            U1L=-(zpa*log(r2/r1)+xpa*(th2-th1)-x2*(th2-th1))/(2.*pi()*x2);
            U2L=(zpa*log(r2/r1)+xpa*(th2-th1))/(2.*pi()*x2);
            W1L=-((x2-zpa*(th2-th1))-xpa*log(r1/r2)+x2*log(r1/r2))/(2.*pi()*x2);
            W2L=((x2-zpa*(th2-th1))-xpa*log(r1/r2))/(2.*pi()*x2);
        end
        %return velocity to global coordinates
        u1=U1L*cos(-tht_pan(j))+W1L*sin(-tht_pan(j));
        u2=U2L*cos(-tht_pan(j))+W2L*sin(-tht_pan(j));
        w1=-U1L*sin(-tht_pan(j))+W1L*cos(-tht_pan(j));
        w2=-U2L*sin(-tht_pan(j))+W2L*cos(-tht_pan(j));
        %get influence cooefficient
        if j==1
        ainf(i,1)=-u1*sin(tht_pan(i))+w1*cos(tht_pan(i)); 
        holda=-u2*sin(tht_pan(i))+w2*cos(tht_pan(i));
        b(i,1)=u1*cos(tht_pan(i))+w1*sin(tht_pan(i));
        holdb=u2*cos(tht_pan(i))+w2*sin(tht_pan(i));
        elseif j==npanel
        ainf(i,npanel)=-u1*sin(tht_pan(i))+w1*cos(tht_pan(i))+holda; 
        ainf(i,npaer)=-u2*sin(tht_pan(i))+w2*cos(tht_pan(i));
        b(i,npanel)=u1*cos(tht_pan(i))+w1*sin(tht_pan(i))+holdb;
        b(i,npaer)=u2*cos(tht_pan(i))+w2*sin(tht_pan(i));
        else
        ainf(i,j)=-u1*sin(tht_pan(i))+w1*cos(tht_pan(i))+holda; 
        holda=-u2*sin(tht_pan(i))+w2*cos(tht_pan(i));
        b(i,j)=u1*cos(tht_pan(i))+w1*sin(tht_pan(i))+holdb;
        holdb=u2*cos(tht_pan(i))+w2*sin(tht_pan(i));
        end
    end
end
savinf=ainf;
%ADD KUTTA CONDITION
ainf(npaer,1)=1;
ainf(npaer,npaer)=1;

% FORM RHS
for i=1:npanel
    rhs(i,1)=(u_fs_ana*sin(tht_pan(i))-w_fs_ana*cos(tht_pan(i)));
end
rhs(npaer,1)=0;

% FIND STRENGTHS
slam=ainf\rhs;

% CALCULATE SURFACE SOLUTION QUANTITIES AT CONTROL POINTS
lift1=0.;
lift2=0.;
lift3=0.;
for i=1:npanel
    vtpan(i)=0;
    for j=1:npanel+1
    vtpan(i)=vtpan(i)+b(i,j)*slam(j);
    end
    fstan=u_fs_ana*cos(tht_pan(i))+w_fs_ana*sin(tht_pan(i));
    cp(i)=1.-(vtpan(i)+fstan)^2/(fsvel*fsvel);
    lift1=lift1+(slam(i)+slam(i+1))*pan_len(i);
    lift2=lift2+2.*(vtpan(i)-fstan)*pan_len(i);
    fx(i)=-pan_len(i)*cp(i)*cos(tht_pan(i));
    fy(i)=pan_len(i)*cp(i)*sin(tht_pan(i));
    lift3=lift3+fx(i)*cos(fsarad)+fy(i)*sin(fsarad);
    velt_cp(i)=-(vtpan(i)+fstan);
end
if print==1
lift1=lift1/fsvel
lift2=lift2/fsvel;
lift3=lift3;
end
end

function eulerlink(varargin)
    vals=calleuler();
    h.presfig=figure('menubar','none',...
        'numbertitle','off',...
        'name','Pressure distribution on aerofoil');
    clf;
    hold on;
    title('Pressure distribution on aerofoil');
    xlabel('x');
    ylabel('-Cp');
    xlim([0 1])
    plot(vals.data(:,1),vals.data(:,3));
end

function vals=calleuler()

% to compile stand-alone, use:
% mcc -m calleuler.m -d 'C:\place'

% There are many other options for the solver, however this script only supports
% steady flow calculations.

% Determine Mach numer, angle of attack, timestep and iterations
prompt = {'M_{\infty}:','\alpha','CFL','N_{iterations}'};
dlg_title = 'Inputs for the Euler solver';
num_lines = 1;
% Defaults will be inappropriate for larger meshes
def = {'0.8','0.0','2.0','4000'};

options.Resize='on';
options.WindowStyle='normal';
% Allow latex formatting of the text box
options.Interpreter='tex';

% Input box
answer = inputdlg(prompt,dlg_title,num_lines,def,options);
% Extract results
mach = str2double(answer(1));
aoa = str2double(answer(2));
CFL = str2double(answer(3));
nit = str2double(answer(4));

fileflowsettings = fopen('settings','w');

% Write the input file for the flow solver
% Solver can run sweeps in M or AoA. Here we only run a single case.
% number of Mach numbers, Mach start, Mach increment
fprintf(fileflowsettings,'%s\t%f\t%s','1',mach,'0.025');
% number of AoAs, AoA start, AoA increment
fprintf(fileflowsettings,'\n%s\t%f\t%s','1',aoa,'0.25');
% Density. Leave this unchanged.
fprintf(fileflowsettings,'\n%s','1.2');
% Temperature. Leave unchanged - this is set to achieve p_inf~1
fprintf(fileflowsettings,'\n%s','2.9e-3');
% Gamma. Leave unchanged.
fprintf(fileflowsettings,'\n%s','1.4');
% Gas constant R. Leave.
fprintf(fileflowsettings,'\n%s','287.0');
% option 0 stops code after nit cycles, 1 stops after residual tolerance
% (here -3). Best to use 0.
fprintf(fileflowsettings,'\n%s\t%i\t%s','0',nit,'-3.0');
% CFL number used to set explicit timestep
fprintf(fileflowsettings,'\n%f',CFL);
% 2nd order dissipation constant
fprintf(fileflowsettings,'\n%s','1.0');
% 4th order dissipation constant
fprintf(fileflowsettings,'\n%s','0.05');
% Don't change these. They are switches to apply dissipation at each stage
% of the RK integration. It is best to apply at the 1st stage and then keep
% constant, so this setting is optimal.
fprintf(fileflowsettings,'\n%s\t%s\t%s\t%s','1','0','0','0');
% steady (0), unsteady (1)    no restart (0), restart (1)
fprintf(fileflowsettings,'\n%s\t%s','0','0');
% unsteady settings - not used here, but these are sensible defaults if
% they were used
fprintf(fileflowsettings,'\n%s\t%s\t%s\t%s','.0956','600','30','1.0');
% mesh motion settings - not used here
fprintf(fileflowsettings,'\n%s\t%s','5','2.0');
% aeroelastic option - not used here
fprintf(fileflowsettings,'\n%s','2');

fclose(fileflowsettings);

%data
%pause

% if a mesh exists, use that, otherwise make a new one
fullFileName=fullfile(cd, 'griduns')
if exist(fullfile(cd, 'griduns'), 'file')
  warningMessage = sprintf('Click OK to use existing mesh...', fullFileName);
  uiwait(msgbox(warningMessage));
else
  % Mesh does not exist.
  warningMessage = sprintf('Click OK to create mesh...', fullFileName);
  uiwait(msgbox(warningMessage));
  
  promptm = {'N_{levels}','N_{buffer}'};
  dlg_titlem = 'Inputs for the Cut-cell mesher';
  num_linesm = 1;
  defm = {'11','5'};

  optionsm.Resize='on';
  optionsm.WindowStyle='normal';
  optionsm.Interpreter='tex';

  answerm = inputdlg(promptm,dlg_titlem,num_linesm,defm,optionsm);
  %answer(1)
  % number of refinement levels
  nlev = str2double(answerm(1));
  % number of buffer stages (ie width) for each level
  nbuf = str2double(answerm(2));
  
  filemeshsettings = fopen('cutsettings','w');
 
  % write the mesher input file
  % initial number of points along each each (x and y) - here 3, followed
  % by boundary flag for farfield (0) or wall (1)
  fprintf(filemeshsettings,'%s\t%s\t%s\t%s','3','3','0','0');
  % lower left farfield point
  fprintf(filemeshsettings,'\n%s\t%s','-25','-25');
  % upper right farfield point
  fprintf(filemeshsettings,'\n%s\t%s','25','25');
  % this is a flag to offset the background mesh (to avoid having geometry
  % and mesh points coincident). Set to 1 to activate.
  fprintf(filemeshsettings,'\n%s','0');
  % number of mesh levels to use
  fprintf(filemeshsettings,'\n%i',nlev);
  % need to specify the buffer number for each level
  for i=1:nlev
      fprintf(filemeshsettings,'\n%i\t%i',i,nbuf);
  end

  fclose(filemeshsettings);
  
  status = system('CartCell.exe');
  
end

status = system('EulerFlow.exe');
% pproc just makes the colourful tecplot files (flowplt.plt), and cp.dat 
status = system('pproc.exe');

% read in and plot Cp vs x.
filename = 'cp.dat';
delimiterIn = ' ';
headerlinesIn = 1;
vals = importdata(filename,delimiterIn,headerlinesIn);

end
%=================================================================
% BASE FUNCTIONS =================================================
function lockaxes(handle)
     xax=get(handle,'xlim');
     yax=get(handle,'ylim');
     axis(handle,[xax(1) xax(2) yax(1) yax(2)]);
end 

function makeborder(handle)
     axis(handle, 'tight');
     xax=get(handle,'xlim');
     yax=get(handle,'ylim');
     bo=max(xax(2)-xax(1),yax(2)-yax(1))/8;
     axis(handle, [xax(1)-bo,xax(2)+bo,yax(1)-bo,yax(2)+bo])
end

function resizefig(varargin)
     fp=get(gcf,'Position');
     if fp(3)<775
         set(gcf,'Position',[fp(1:2) 775 fp(4)]);
     end
     fp=get(gcf,'Position');
         set(h.axes,'Position', [30 50 fp(3)-60 fp(4)-90])
         makeborder(h.axes)
         axis(h.axes,'equal');
         lockaxes(h.axes);
         set(h.reset,'Position', [fp(3)-70 10 50 20]);
         set(h.group,'Position', [20 fp(4)-30 100 20]);
         set(h.selectall,'Position', [125 fp(4)-30 80 20]);
         set(h.clrselection,'Position', [210 fp(4)-30 80 20]);
         set(h.rotate,'Position', [295 fp(4)-30 80 20]);
         
     rbf_main(0,0,'setcbpos'); %run setcbpos
     set(h.refresh,'Position', [fp(3)-125 10 50 20]);
     set(h.plotpres,'Position', [fp(3)-220 10 90 20]);
     set(h.xfoil,'Position', [fp(3)-285 10 60 20]);
     set(h.euler,'Position', [fp(3)-350 10 60 20]);
     set(h.plotpresRe,'Position', [fp(3)-490 10 25 16]);
     set(h.plotpresalpha,'Position', [fp(3)-415 10 35 16]);
     set(h.plotpresReedit,'Position', [fp(3)-460 10 40 20]);
     set(h.plotpresalphaedit,'Position', [fp(3)-375 10 20 20]);
end
     
function export(varargin)
    texthandle=varargin{3};
    filename=get(texthandle,'string');
    dlmwrite(filename,a,'delimiter',' ','newline','pc');
end
%=================================================================
end

%non-nested functions
function A=calcarea(aerofoil)
%using greens theorm to calculate the area of the aerofoil
minval=min(aerofoil);
aerofoil=aerofoil+ones(size(aerofoil))*abs(minval(1,2)); %translate above x-axis
A=0;
    for i=1:length(aerofoil)
        x1=aerofoil(i,1);
        y1=aerofoil(i,2);
        if i~=length(aerofoil)
            x2=aerofoil(i+1,1);
            y2=aerofoil(i+1,2);
        else
            x2=aerofoil(1,1);
            y2=aerofoil(1,2);
        end
        if x1 ~= x2 %stop m=inf
        m=(y2-y1)/(x2-x1); c=y1-m*x1;
        A=A + ((m*x2^2)/2 +c*x2)-((m*x1^2)/2 +c*x1);
        end
    end  
    A=abs(A);
end

function [isaero,aerofoil]=checkaerofoil(aerofoil)
l_old=1; k=0; %l=1 means x decreaseing l=2 means increasing; k=change count
isaero=1;
    for i=2:length(aerofoil(:,1))
        if aerofoil(i,1)<aerofoil(i-1,1)
            l=1;
        elseif aerofoil(i,1)>aerofoil(i-1,1)
            l=2;
        end
        if l~=l_old
            k=k+1;
            n=i-1;
        end
        if k>=2
            isaero=0;
            break
        end
        l_old=l;
    end
    lowermean=mean(aerofoil(1:n,2));
    uppermean=mean(aerofoil(n:length(aerofoil(:,1)),2));
    if lowermean>uppermean
        aerofoil=aerofoil(length(aerofoil(:,1)):-1:1,:); %flip aerofoil
    end
end

function Aas=setAas(S,a)
Ls=length(S(:,1));
La=length(a(:,1));
Aas=zeros(La,Ls+3);
Aas(:,1)=ones(La,1);
Aas(:,2:3)=a;
for i=1:La
for j=1:Ls
    Aas(i,j+3)=phi(norm(a(i,:) - S(j,:)));
end
end
end

function Css=setCss(S)
Ls=length(S(:,1));
Css=zeros(Ls+3,Ls+3);
Css(4:Ls+3,1)=ones(Ls,1);
Css(1,4:Ls+3)=ones(1,Ls);
Css(4:Ls+3,2:3)=S;
Css(2:3,4:Ls+3)=S';
for i=1:Ls;
for j=1:Ls;
    Css(i+3,j+3)=phi(norm(S(i,:) - S(j,:)));
end
end
end

function PHI=phi(r)
S=1;
if r<S
  PHI=((1-r/S))^2;
else PHI=0;
end
% PHI=((1-r))^2;
% PHI=(1-r)^4*(4*r+1);
end

function M=importmesh()
temp=importdata('griduns',' ');
M.totcells=temp(1,1);
M.totedges=temp(1,2);
M.totvertices=temp(1,3);
temp=importdata('griduns',' ',1);
a=1;
b=M.totedges;
M.edgedata=temp.data(a:b,1:4);
a=a+M.totedges;
b=b+M.totvertices;
M.vertexdata=temp.data(a:b,1:3);
a=a+M.totvertices;
b=b+M.totcells;
M.celldata=temp.data(a:b,1);
end

function createmesh(a)
fullFileName=fullfile(cd, 'griduns')
% Mesh does not exist.
  warningMessage = sprintf('Click OK to create mesh...', fullFileName)
  uiwait(msgbox(warningMessage));
  writeboundary(flipud(a));
  promptm = {'N_{levels}','N_{buffer}'};
  dlg_titlem = 'Inputs for the Cut-cell mesher';
  num_linesm = 1;
  defm = {'11','5'};

  optionsm.Resize='on';
  optionsm.WindowStyle='normal';
  optionsm.Interpreter='tex';

  answerm = inputdlg(promptm,dlg_titlem,num_linesm,defm,optionsm);
  %answer(1)
  % number of refinement levels
  nlev = str2double(answerm(1));
  % number of buffer stages (ie width) for each level
  nbuf = str2double(answerm(2));
  
  filemeshsettings = fopen('cutsettings','w');
 
  % write the mesher input file
  % initial number of points along each each (x and y) - here 3, followed
  % by boundary flag for farfield (0) or wall (1)
  fprintf(filemeshsettings,'%s\t%s\t%s\t%s','3','3','0','0');
  % lower left farfield point
  fprintf(filemeshsettings,'\n%s\t%s','-25','-25');
  % upper right farfield point
  fprintf(filemeshsettings,'\n%s\t%s','25','25');
  % this is a flag to offset the background mesh (to avoid having geometry
  % and mesh points coincident). Set to 1 to activate.
  fprintf(filemeshsettings,'\n%s','0');
  % number of mesh levels to use
  fprintf(filemeshsettings,'\n%i',nlev);
  % need to specify the buffer number for each level
  for i=1:nlev
      fprintf(filemeshsettings,'\n%i\t%i',i,nbuf);
  end

  fclose(filemeshsettings);
  
  status = system('CartCell.exe');
  %M=importmesh();
end

function writeboundary(a)
boundary=fopen('boundary.dat','wt');
    %write header line
    fprintf(boundary,'%i',1);
    %write boundary length
    fprintf(boundary,'\n%i   %i\n%i',length(a(:,1)),length(a(:,1)),length(a(:,1)));
    %write boundary data
    fprintf(boundary,'\n%f\t%f',a');
    fclose(boundary);    
end

function writemesh(M)
griduns=fopen('griduns','wt');
    %write header line
    fprintf(griduns,'%12i%12i%12i',M.totcells,M.totedges,M.totvertices);
    %write edgedata
    fprintf(griduns,'\n%12i%12i%12i%12i',M.edgedata');
    %write vertex data
    fprintf(griduns,'\n%12i\t%5.12e\t%5.12e',M.vertexdata');
    %write vertex data
    fprintf(griduns,'\n%3.14e',M.celldata');
    fclose(griduns);
end