%EXAMPLE 4
script={'OPTset.areacon=1;',... %set area contstraint to Area>Area0
'opt([],[],''XFOIL'',''OPT'')',... %run optimisation using XFOIL
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{8},NACA4412,[0.2,1e6,3],script); %run ADAPT