function aero=translateaero(aero,tran)
aero=[aero ones(size(aero(:,1)))]*tran;
aero=aero(:,1:2);
end