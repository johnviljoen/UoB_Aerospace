function [target,tran]=normtargetLE(target,LE)
% figure; plot(target(:,1),target(:,2));hold on
% target=target';
target(:,3)=ones(size(target(:,1)));
orig=target;
% translate le to 0,0 =================

    tran1=[1 0 -LE(1);
            0 1 -LE(2);
            0 0 1]';
        target=target*tran1;
% ====================================
% rotate tail to align with x-axis =====
thetatail=atan(target(end,2)/target(end,1));
        if target(end,1)<0
            thetatail = thetatail + pi;
        end
    tran2=[cos(thetatail) sin(thetatail) 0;
            -sin(thetatail) cos(thetatail) 0;
            0 0 1]';
    target=target*tran2;
% % ====================================
% scale to unit chord ===============
scalefactor=1/target(end,1);
    tran3=[scalefactor 0 0;
            0 scalefactor 0;
            0 0 1]';
    target=target*tran3;
% ===================================
    tran=tran1*tran2*tran3;
    target=target(:,1:2);
%     figure
%     plot(target(:,1),target(:,2),'r');
%     hold on
%     plot(orig(:,1),orig(:,2),'g');
end