function [target,tran]=normtarget(target)
% figure; plot(target(:,1),target(:,2));hold on
% target=target';
target(:,3)=ones(size(target(:,1)));
orig=target;
% translate le to 0,0 =================
taildiff=target-(ones(size(target(:,1)))*target(1,:));
for i=1:length(target(:,1))
taildist(i)=norm(taildiff(i,1:2));
end
    [~, mint]=max(taildist);
    tran1=[1 0 -target(mint,1);
            0 1 -target(mint,2);
            0 0 1]';
        target=target*tran1;
% ====================================
% rotate tail to align with x-axis =====
thetatail=atan(target(end,2)/target(end,1));
        if target(end,1)<0
            thetatail = thetatail + pi;
        end
    tran2=[cos(thetatail) sin(thetatail) 0;
            -sin(thetatail) cos(thetatail) 0;
            0 0 1]';
    target=target*tran2;
% % ====================================
% scale to unit chord ===============
scalefactor=1/(max(target(:,1))-min(target(:,1)));
    tran3=[scalefactor 0 0;
            0 scalefactor 0;
            0 0 1]';
    target=target*tran3;
% ===================================
    tran=tran1*tran2*tran3;
    target=target(:,1:2);
%     orig=orig*tran;
%     target=target';
%     plot(target(:,1),target(:,2),'r');
%     plot(orig(:,1),orig(:,2),'g');
end