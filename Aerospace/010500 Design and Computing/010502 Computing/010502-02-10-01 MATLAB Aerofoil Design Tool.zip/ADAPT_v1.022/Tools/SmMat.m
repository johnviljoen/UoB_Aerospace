function D=SmMat(S,Rad,Fac,Cyc)
for ii=1:length(S(:,1))
    for jj=1:length(S(:,1))
    D(ii,jj)=norm(S(ii,:)-S(jj,:)); 
    end   
end
D(S(:,2)<0,S(:,2)>0)=Rad+1;
D(S(:,2)>0,S(:,2)<0)=Rad+1;
OUT=D>Rad;
IN=D<=Rad;
D(OUT)=0;
D(IN)=Fac*(Rad-D(IN))/(Rad);
D(logical(eye(size(D))))=1;
D=D./(sum(D)'*ones(1,length(D(:,1))));
D=D^Cyc;
end