function [meanerror,toterror,C]=aeroerror(orig,approx,plotfigures)
if nargin==2
    plotfigures=0;
end
% tic
% [~,C.input]=checkaerofoil(orig); 
% [~,C.target]=checkaerofoil(approx);
C.input=orig;
C.target=approx;
% if length(C.target)<length(C.input) %ensure shortest aero is "input"
%     temp=C.target;
%     C.target=C.input;
%     C.input=temp;
% end
k=1;
C.input(:,2)=C.input(:,2)+2;
C.target(:,2)=C.target(:,2)+2;
[~,C.mini]=min(C.input(:,1));
[~,C.minj]=min(C.target(:,1));
C.intersections=[];

for i=1:length(C.input(:,1))-1
    for j=1:length(C.target(:,1))-1
%         if (C.target(j,1)<C.input(i,1)   && C.target(j,1)>C.input(i+1,1)   && i<=(1.5*C.mini) && j<(1.5*C.minj)) ||...
%            (C.target(j+1,1)<C.input(i,1) && C.target(j+1,1)>C.input(i+1,1) && i<=(1.5*C.mini) && j<(1.5*C.minj)) ||...
%            (C.target(j,1)>C.input(i,1)   && C.target(j,1)<C.input(i+1,1)   && i>=(0.5*C.mini) && j>(0.5*C.minj)) ||...
%            (C.target(j+1,1)>C.input(i,1) && C.target(j+1,1)<C.input(i+1,1) && i>=(0.5*C.mini) && j>(0.5*C.minj))
% plot(C.input(i:i+1,1),C.input(i:i+1,2),'m')
% plot(C.target(i:i+1,1),C.target(i:i+1,2),'g')
% [C.input(i,:) C.input(i+1,:)]
% [C.target(j,:) C.target(j+1,:)]
            if (i<=(1.5*C.mini) && j<(1.5*C.minj) ||...
                    i<=(1.5*C.mini) && j<(1.5*C.minj) ||...
                    i>=(0.5*C.mini) && j>(0.5*C.minj) ||...
                    i>=(0.5*C.mini) && j>(0.5*C.minj))
           [x y]=lineintersect([C.input(i,:) C.input(i+1,:)],[C.target(j,:) C.target(j+1,:)]); 
           if isnan(x)==0
                C.intersections(k,:)=[x,y];
                C.intindex(k,:)=[i,j];
                k=k+1;
           end
            end
%         end
    end
end

% C.intersections=unique(C.intersections,'rows','stable');
if plotfigures==1
figure;
plot(C.input(:,1),C.input(:,2),'b-')
hold on
plot(C.target(:,1),C.target(:,2),'r-')
plot(C.intersections(:,1),C.intersections(:,2),'og')
end
%     C.inputwint=zeros(length(C.input(:,1)),3);
%     C.targetwint=zeros(length(C.target(:,1)),3);
C.inputwint=C.input;
C.targetwint=C.target;
C.inputwint(1,3)=1;
C.targetwint(1,3)=1;
C.inputwint(end,3)=1;
C.targetwint(end,3)=1;
K=1;
if isempty(C.intersections)==0
intlength=length(C.intersections(:,1));
else
intlength=0;
end
for i=1:intlength
    line=C.intindex(i,1)+K;
    C.inputwint=[C.inputwint(1:line-1,:);
        C.intersections(i,:),1;
        C.inputwint(line:end,:)];
    K=K+1;
end
K=1;
for i=1:intlength
    line=C.intindex(i,2)+K;
    C.targetwint=[C.targetwint(1:line-1,:);
        C.intersections(i,:),1;
        C.targetwint(line:end,:)];
    K=K+1;
end

% if isequal(C.intersections(1,:),[1,1])==0
% C.inputwint=[C.inputwint;
%     C.input(1:C.intindex(1,1),:),zeros(length(1:C.intindex(1,1)),1);
%     C.intersections(1,:),1];
% C.targetwint=[C.targetwint;
%     C.target(1:C.intindex(1,2),:),zeros(length(1:C.intindex(1,2)),1);
%     C.intersections(1,:),1];
% % end
% C.inputwint(1,3)=1;
% C.targetwint(1,3)=1;
% for i=2:length(C.intindex(:,1))
%     C.inputwint=[C.inputwint;
%     C.input(C.intindex(i-1,1)+1:C.intindex(i,1),:),zeros(length(C.intindex(i-1,1)+1:C.intindex(i,1)),1);
%     C.intersections(i,:),1];
% C.targetwint=[C.targetwint;
%     C.target(C.intindex(i-1,2)+1:C.intindex(i,2),:),zeros(length(C.intindex(i-1,2)+1:C.intindex(i,2)),1);
%     C.intersections(i,:),1];
% end
% C.inputwint=[C.inputwint;
%     C.input(C.intindex(end,1)+1:end,:),zeros(length(C.input(C.intindex(i,1)+1:end,1)),1);
%     C.input(end,:),1];
% C.targetwint=[C.targetwint;
%     C.target(C.intindex(end,2)+1:end,:),zeros(length(C.target(C.intindex(i,2)+1:end,1)),1);
%     C.target(end,:),1];
instart=1;
tastart=1;
L=1;
C.toterror=0;

for l=1:intlength+1
    for i=instart+1:length(C.inputwint(:,1))
        if C.inputwint(i,3)==1
            infinish=i;
            C.Loop{L}=C.inputwint(instart:infinish,1:2);
            instart=infinish;
            break
        end
    end
    for i=tastart+1:length(C.targetwint(:,1))
        if C.targetwint(i,3)==1
            tafinish=i;
            C.Loop{L}=[C.Loop{L}; C.targetwint(tafinish:-1:tastart,1:2)];
            C.Loop{L}=unique(C.Loop{L},'rows','stable');
            C.Loop{L}=[C.Loop{L}; C.Loop{L}(1,:)];
            tastart=tafinish;
            C.error{L}=area(C.Loop{L});
            C.toterror=C.toterror+C.error{L};
            L=L+1;
            break
        end
    end
end

toterror = C.toterror;
C.arc = arclength(orig);
C.apparc= arclength(approx);
C.meanerror = (2*C.toterror)/(C.arc+C.apparc);
meanerror=C.meanerror;
% toc
end

function A=arclength(aero)
A=0;
for i=1:length(aero(:,1))-1
A=A+norm((aero(i,:)-aero(i+1,:)),2);
end
end

function A=area(B)
%using greens theorm to calculate the area of the aerofoil
% minval=min(B);
% B=B+ones(size(B))*abs(minval(1,2)); %translate above x-axis
A=0;
    for i=1:length(B(:,1))
        x1=B(i,1);
        y1=B(i,2);
        if i~=length(B(:,1))
            x2=B(i+1,1);
            y2=B(i+1,2);
        else
            x2=B(1,1);
            y2=B(1,2);
        end
        if x1 ~= x2 %stop m=inf
        m=(y2-y1)/(x2-x1); c=y1-m*x1;
        A=A + ((m*x2^2)/2 +c*x2)-((m*x1^2)/2 +c*x1);
        end
    end  
    A=abs(A);
end