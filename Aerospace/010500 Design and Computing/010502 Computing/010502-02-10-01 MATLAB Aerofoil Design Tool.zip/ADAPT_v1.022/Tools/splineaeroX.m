function [Y,sp,X2]=splineaeroX(aero,X,smoothing)
if nargin==2
    smoothing=0;
end
% tic
[~,aero]=checkaerofoil(aero);

% xx=arclength(aero);
xx=aero(1:end-1,:)-aero(2:end,:);
xx=sqrt(xx(:,1).^2+xx(:,2).^2);
xx=[0;xx];
xx=xx.^(1/2); %centrepedial
% D=(aero(:,1).*(D/max(D)))+((aero(:,1)-1).*(D1/max(D1)));
xx=cumsum(xx);
xx=2*xx/xx(end);
xx=xx-1;
xx;
if smoothing==0
sp=spline(xx,aero');
p=1;
elseif smoothing==1
p=[];
[~,minaero]=min(aero(:,1));
w=ones(size(xx));
w([1,minaero,end])=1e12;
[sp,p]=csaps(xx,aero',p, [], w);
end

% Y=ppval(sp,xx)';
% figure;
% plot(aero(:,1),aero(:,2))
% hold on
% plot(Y(:,1),Y(:,2),'r')

taildiff=aero-(ones(size(aero(:,1)))*aero(end,:));
taildist=sqrt(taildiff(:,1).^2+taildiff(:,2).^2);
[~, le_approx]=max(taildist);
DIST=1;
while DIST>1e-8
    xx=linspace(xx(le_approx-3),xx(le_approx+3),51);
    Y=ppval(sp,xx)';
%     plot(Y(:,1),Y(:,2),'g')
    taildiff=Y-(ones(size(Y(:,1)))*aero(end,:));
    taildist=sqrt(taildiff(:,1).^2+taildiff(:,2).^2);
    [~, le_approx]=max(taildist);
    Y2=ppval(sp,[xx(le_approx-1),xx(le_approx+1)])';
    DIST=norm(Y2(1,:)-Y2(2,:));
end
XLE=xx(le_approx);
LE=ppval(sp,XLE);
[aero,tran]=normtargetLE(aero,LE);
% 
% 
% [~,tran]=normtarget(denseaero);
% denseaero=translate(denseaero,tran);
if length(X)==1
l=X;
X=linspace(-pi,pi,X)';
X=(1-cos(X))./2;
X(1:floor(l/2))=-X(1:floor(l/2));
Xmid=ceil(length(X)/2);
else
    if min(X)<-0.1
    else
        [~,Xmid]=min(X);
        X(1:Xmid)=-X(1:Xmid);
    end
end

SX=sign(X);
SX(Xmid)=1;
SX=[SX(1); SX; SX(end)];

[~,minind]=min(abs(X));

X1=X;
X1(1:minind)=X1(1:minind)*(1+XLE);
X1(minind:end)=X1(minind:end)*(1-XLE);
X1=X1+XLE;

X1=[X1(1)-1e-3; X1; X1(end)+1e-3];
Y=translate(ppval(sp,X1)',tran);

Yguess=Y;
%search for correct X positions
low=1; high=2;
B=zeros(length(X),3);
for i=1:length(X)

while SX(high)*Y(high,1)<=X(i)
    low=low+1;
    high=high+1;
    if high>length(SX)
        high=high-1;
        break
    end
end

B(i,1)=X1(low);
B(i,3)=X1(high);
B(i,2)=(B(i,1)+B(i,3))/2;
end
B(Xmid,:)=XLE;
% B(1,:)=-1;
% B(end,:)=1;
SX=SX(2:end-1);
T=(1:length(X))';
Ytemp=translate(ppval(sp,B(:,2))',tran);
lx=length(X);
LE=find(T==Xmid);
Ytemp(LE,1)=Ytemp(LE,1)*sign(Ytemp(LE,2));
Ytemp=SX.*Ytemp(:,1);

k=1;
tol=1e-10;

while ~isempty(Ytemp)
% for j=1:12
C=Ytemp-X(T);
H=find(C>0);
L=find(C<0);
B(T(H),3)=B(T(H),2);
B(T(L),1)=B(T(L),2);
B(T,2)=(B(T,1)+B(T,3))/2;

Ytemp=translate(ppval(sp,B(T,2))',tran);
% Ytemp=translate(ppval(sp,B(:,2))',tran);


LE=find(T==Xmid);
if ~isempty(LE)
Ytemp(LE,1)=Ytemp(LE,1)*sign(Ytemp(LE,2));
end
Ytemp=SX(T).*Ytemp(:,1);

d=abs(Ytemp-X(T));
T=T(find(d>tol));
if k>400
    d(find(T==1))=d(find(T==1))/100;
    d(find(T==lx))=d(find(T==lx))/100;
    if k>600
    d(find(T==1))=d(find(T==1))/100;
    d(find(T==lx))=d(find(T==lx))/100;
    if k>800
    d(find(T==1))=d(find(T==1))/100;
    d(find(T==lx))=d(find(T==lx))/100;
    end
    end
end
Ytemp=Ytemp(find(d>tol));
k=k+1;



if k==1000
    i;
    k;
    d;
    X(T);
    T;
    Ytemp;
    fprintf('Spline Failed: d=%g, X(T)=%g, T=%g, Ytemp=%g\n',d,X(T),T, Ytemp);
%     disp('spline failed')
%     fail
    break
end
end
k;
X2=B(:,2);
Y=translate(ppval(sp,X2)',tran);
[~,minY]=min(Y(:,1));
Y(minY,:)=0;
X2=X2';
% figure; plot(Y(:,1),Y(:,2),'bx-');
% hold on; plot(aero(:,1),aero(:,2),'r-x');
% toc;
end

function aero=translate(aero,tran)
aero=[aero ones(size(aero(:,1)))]*tran;
aero=aero(:,1:2);
end

function [target,tran]=normtargetLE(target,LE)
% figure; plot(target(:,1),target(:,2));hold on
% target=target';
target(:,3)=ones(size(target(:,1)));
orig=target;
% translate le to 0,0 =================

    tran1=[1 0 -LE(1);
            0 1 -LE(2);
            0 0 1]';
        target=target*tran1;
% ====================================
% rotate tail to align with x-axis =====
thetatail=atan(target(end,2)/target(end,1));
        if target(end,1)<0
            thetatail = thetatail + pi;
        end
    tran2=[cos(thetatail) sin(thetatail) 0;
            -sin(thetatail) cos(thetatail) 0;
            0 0 1]';
    target=target*tran2;
% % ====================================
% scale to unit chord ===============
scalefactor=1/target(end,1);
    tran3=[scalefactor 0 0;
            0 scalefactor 0;
            0 0 1]';
    target=target*tran3;
% ===================================
    tran=tran1*tran2*tran3;
    target=target(:,1:2);
%     figure
%     plot(target(:,1),target(:,2),'r');
%     hold on
%     plot(orig(:,1),orig(:,2),'g');
end

function [target,tran]=normtarget(target)
% figure; plot(target(:,1),target(:,2));hold on
% target=target';
target(:,3)=ones(size(target(:,1)));
orig=target;
% translate le to 0,0 =================
taildiff=target-(ones(size(target(:,1)))*target(1,:));
for i=1:length(target(:,1))
taildist(i)=norm(taildiff(i,1:2));
end
    [~, mint]=max(taildist);
    tran1=[1 0 -target(mint,1);
            0 1 -target(mint,2);
            0 0 1]';
        target=target*tran1;
% ====================================
% rotate tail to align with x-axis =====
thetatail=atan(target(end,2)/target(end,1));
        if target(end,1)<0
            thetatail = thetatail + pi;
        end
    tran2=[cos(thetatail) sin(thetatail) 0;
            -sin(thetatail) cos(thetatail) 0;
            0 0 1]';
    target=target*tran2;
% % ====================================
% scale to unit chord ===============
scalefactor=1/(max(target(:,1))-min(target(:,1)));
    tran3=[scalefactor 0 0;
            0 scalefactor 0;
            0 0 1]';
    target=target*tran3;
% ===================================
    tran=tran1*tran2*tran3;
    target=target(:,1:2);
%     orig=orig*tran;
%     target=target';
%     plot(target(:,1),target(:,2),'r');
%     plot(orig(:,1),orig(:,2),'g');
end

function [isaero,aerofoil]=checkaerofoil(aerofoil)
l_old=1; k=0; %l=1 means x decreaseing l=2 means increasing; k=change count
isaero=1;
    for i=2:length(aerofoil(:,1))
        if aerofoil(i,1)<aerofoil(i-1,1)
            l=1;
        elseif aerofoil(i,1)>aerofoil(i-1,1)
            l=2;
        end
        if l~=l_old
            k=k+1;
            n=i-1;
        end
        if k>=2
            isaero=0;
            break
        end
        l_old=l;
    end
    lowermean=mean(aerofoil(1:n,2));
    uppermean=mean(aerofoil(n:length(aerofoil(:,1)),2));
    if lowermean>uppermean
        aerofoil=aerofoil(length(aerofoil(:,1)):-1:1,:); %flip aerofoil
    end
end