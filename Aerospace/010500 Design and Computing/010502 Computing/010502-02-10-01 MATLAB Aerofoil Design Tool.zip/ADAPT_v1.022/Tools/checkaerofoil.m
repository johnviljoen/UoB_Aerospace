function [isaero,aerofoil]=checkaerofoil(aerofoil)
l_old=1; k=0; %l=1 means x decreaseing l=2 means increasing; k=change count
isaero=1;
    for i=2:length(aerofoil(:,1))
        if aerofoil(i,1)<aerofoil(i-1,1)
            l=1;
        elseif aerofoil(i,1)>aerofoil(i-1,1)
            l=2;
        end
        if l~=l_old
            k=k+1;
            n=i-1;
        end
        if k>=2
            isaero=0;
            break
        end
        l_old=l;
    end
    lowermean=mean(aerofoil(1:n,2));
    uppermean=mean(aerofoil(n:length(aerofoil(:,1)),2));
    if lowermean>uppermean
        aerofoil=aerofoil(length(aerofoil(:,1)):-1:1,:); %flip aerofoil
    end
end