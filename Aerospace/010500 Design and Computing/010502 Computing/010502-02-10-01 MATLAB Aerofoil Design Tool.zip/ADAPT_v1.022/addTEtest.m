NACA0012=NACA4(0,0,12,301);
[~,ind]=min(NACA0012(:,1));
te=0.005;
NACA0012te=NACA0012;
NACA0012te(1:ind,2)=NACA0012(1:ind,2)-te*NACA0012(1:ind,1);
NACA0012te(ind:end,2)=NACA0012(ind:end,2)+te*NACA0012(ind:end,1);
[~,ind]=min(NACA0012(:,1));
NACA4412=NACA4(4,4,12,301);
te=0.005;
NACA4412te=NACA4412;
NACA4412te(1:ind,2)=NACA4412(1:ind,2)-te*NACA4412(1:ind,1);
NACA4412te(ind:end,2)=NACA4412(ind:end,2)+te*NACA4412(ind:end,1);

script={'IDset.target=''NACA4412te'';',... %set target to NACA4412
'opt([],[],''VGK'',''ID'')',... %run inverse design with VGK
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{8},NACA0012te,[0.7,NaN,0],script); %run ADAPT