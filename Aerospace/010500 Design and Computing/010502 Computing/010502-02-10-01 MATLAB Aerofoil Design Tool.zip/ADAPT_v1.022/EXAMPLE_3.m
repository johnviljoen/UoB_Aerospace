%EXAMPLE 3
script={'IDset.target=''RAE2822'';',... %set target to RAE2822
    'IDset.iter=200;',... %increase maximum number of iteratiosn to 200
'opt([],[],''POTFLOW'',''ID'')',... %run inverse design with panel code
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{8},NACA0012,[NaN,NaN,3],script); %run ADAPT (note Mach and Re not used in this case)