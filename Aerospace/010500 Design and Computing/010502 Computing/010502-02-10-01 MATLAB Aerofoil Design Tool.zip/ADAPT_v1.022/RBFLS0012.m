function [error,LOG]=RBFLS0012(target,S,stat,p)
rbftime=tic;
weighted=1;
SR=0.8;
%create input NACA0012 aerofoil with matching x coords
[~,minx]=min(target);
XL=target(1:minx,1);
XU=target(minx+1:end,1);
% if norm(target(1,:)-target(end,:))>8e-4
% YL=-nacathick(12,XL,1);
% YU=nacathick(12,XU,1);
% else
% YL=-nacathick(12,XL,0);
% YU=nacathick(12,XU,0);
% end
YL=-nacathickTE(12,XL,-target(1,2));
YU=nacathickTE(12,XU,target(end,2));
input=[XL, YL; XU, YU];
if size(S)==1
if S==6
    Sx=0.5;
    Sx=[-0.1; Sx; 1.1]-0.5;
else
% Sx=linspace(0+(pi/8),(7*pi)/8,(S-4)/2)';
% Sx=cos(Sx)/cos(pi/8);
% Sx=(1-Sx)./2;
% Sx=linspace(0,1,(S-4)/2)';
% Sx=[-0.1; Sx; 1.1]-0.5;
Sx=linspace(-0.1,1.1,S/2)';
Sx=Sx-0.5;
% Sx=linspace(0,pi,S/2)';
% Sx=(1-cos(Sx))./2;
% Sx=1.2*Sx-0.6;
end
S=[Sx+0.5 sqrt(0.32^2*(1-((Sx.^2)/(0.65^2))))];
% S=[Sx nacathickTE(12,Sx,0)+0.2];
S=[S; S(:,1), -S(:,2)];
% S=[S; -0.1,0.1; -0.1,-0.1; 1.1,0.1; 1.1,-0.1];
end
% S=createpoints(input,n);

if stat==1
    if abs(input(1,2)-input(end,2))>1e-6
    S=[S; 0,0; input(1,:); input(end,:)];    
    stat=(length(S(:,1))-2):length(S(:,1));
    else
        S=[S; 0,0; input(end,:)];    
    stat=(length(S(:,1))-1):length(S(:,1));
    end
    Sopt=1:length(S(:,1));
    Sopt(stat)=[];
else
    Sopt=1:length(S(:,1));
end    



C=setCss(S);
a=input;
A=setAas(S,a);

H=A/C;
S2=S;
if weighted==1
    W=ones(length(target(:,1)),1);
    W(target(:,1)<0.2)=2;
    W=diag(W);
else
    W=ones(length(target(:,1)),1);
    W=diag(W);
end
S2=zeros(size(S));
S2(Sopt,:)=(W*H(:,Sopt+3))\(W*(target-input));
Q2=zeros(length(S2(:,1))+3,2);
Q2(4:end,:) = S2+S;
S2=S2+S;
a2=H*Q2;
error=abs(a2(:,2)-target(:,2));
error=[target(:,1),error];
LOG.input=input;
LOG.S=S;
LOG.S_sol=S2;
LOG.a_sol=a2;
LOG.error=error;
LOG.kulfan=kulfantol(error);

if p==1
figure;
plot(target(:,1),target(:,2));
hold on
plot(a2(:,1),a2(:,2),'r');
plot(S(:,1),S(:,2),'b*')
plot(S2(:,1),S2(:,2),'r*')
axis equal
figure;
plot(error(:,1),error(:,2))
% aero=a2;
% % target=input;
% aerotran=aero(2:end-1,2)./(aero(2:end-1,1).^0.8.*(ones(size(aero(2:end-1,1)))-aero(2:end-1,1)));
% aerotran=[aero(2:end-1,1),aerotran];
% targettran=target(2:end-1,2)./(target(2:end-1,1).^0.8.*(ones(size(target(2:end-1,1)))-target(2:end-1,1)));
% targettran=[target(2:end-1,1),targettran];
% % figure; plot(aerotran(:,1),aerotran(:,2),'c')
% % hold on; plot(targettran(:,1),targettran(:,2))
% [s,tran_s]=gradaero(aero);
% [s_tar,tran_s_tar]=gradaero(target);
% s=[s(2:end-1,1) s(2:end-1,2).*(s(2:end-1,1).^0.7.*(ones(size(s(2:end-1,1)))-s(2:end-1,1)).^0.5)];
% s_tar=[s_tar(2:end-1,1) s_tar(2:end-1,2).*(s_tar(2:end-1,1).^0.7.*(ones(size(s_tar(2:end-1,1)))-s_tar(2:end-1,1)).^0.5)];
% figure; plot(s(:,1),s(:,2),'g')
% hold on; plot(s_tar(:,1),s_tar(:,2),'k')
% Serror=(s(:,2)-s_tar(:,2));
% % figure; plot(tran_s_tar(:,1),tran_s_tar(:,2),'k')
% % hold on; plot(tran_s(:,1),tran_s(:,2),'r')
% figure; plot(s(:,1),Serror,'r')
% Serror;
% max(abs(Serror))
% [C]=curve3p(aero);
% [C_tar]=curve3p(target);
% C=[C(2:end-1,1) C(2:end-1,2).*(C(2:end-1,1).^1.2.*(ones(size(C(2:end-1,1)))-C(2:end-1,1)))];
% C_tar=[C_tar(2:end-1,1) C_tar(2:end-1,2).*(C_tar(2:end-1,1).^1.2.*(ones(size(C_tar(2:end-1,1)))-C_tar(2:end-1,1)))];
% figure; plot(C(:,1),C(:,2),'m')
% hold on; plot(C_tar(:,1),C_tar(:,2),'k')
% Cerror=(C(:,2)-C_tar(:,2));
% figure; plot(C(:,1),Cerror,'m')
end

t=toc(rbftime);
t*50000/60;

function PHI=phi(r)
% SR=0.8;
r=r./SR;
% PHI=((1-r))^2; %C0
PHI=((ones(size(r))-r).^4).*((4.*r)+ones(size(r))); %C2
PHI=PHI.*(r<1);
%  PHI=((1-r))^2; %C0
% PHI=(1-r)^4*(4*r+1); %C2
% PHI=(1-r)^6*(35*r^2+18*r+1); %C4
% PHI=r^2*log(r); %Thin Plate Spline
% PHI=pi*((1/12*r^3)-r^2*r+(4/3*r^3)); %Euclids Hat
end

function Aas=setAas(S,a)
Ls=length(S(:,1));
La=length(a(:,1));
Aas=zeros(La,Ls+3);
Ax=zeros(La,Ls);
Ay=zeros(La,Ls);
Sx=zeros(La,Ls);
Sy=zeros(La,Ls);
Aas(:,1)=ones(La,1);
Aas(:,2:3)=a;
Ax=a(:,1)*ones(1,Ls);
Ay=a(:,2)*ones(1,Ls);
Sx=ones(La,1)*S(:,1)';
Sy=ones(La,1)*S(:,2)';
Aas(1:La,4:Ls+3)=phi(sqrt((Ax-Sx).^2+(Ay-Sy).^2));
end

function Css=setCss(S)
Ls=length(S(:,1));
Css=zeros(Ls+3,Ls+3);
Sx=zeros(Ls,Ls);
Sy=zeros(Ls,Ls);
Css(4:Ls+3,1)=ones(Ls,1);
Css(1,4:Ls+3)=ones(1,Ls);
Css(4:Ls+3,2:3)=S;
Css(2:3,4:Ls+3)=S';
Sx=ones(Ls,1)*S(:,1)';
Sy=ones(Ls,1)*S(:,2)';
Css(4:Ls+3,4:Ls+3)=phi(sqrt((Sx-Sx').^2+(Sy-Sy').^2));
end

end

function z=nacathickTE(t,x,TE)
t=t/100;
d=[0.2969; -0.1260;
    -0.3516; 0.2843;
    -0.1036];

c=1;
    z=5*t*c*((d(1)*(x./c).^0.5)+(d(2)*(x./c))+(d(3)*(x./c).^2)+(d(4)*(x./c).^3)+(d(5)*(x./c).^4));
    z=z+TE*x;
end

function [bool,kulerror]=kulfantol(error)
tol1=8e-4;
tol2=4e-4;
LE=find(error(:,1)<0.2);
TE=find(error(:,1)>=0.2);
error(:,2)=abs(error(:,2));
kulerror(LE,1)=error(LE,2)-tol2;
kulerror(TE,1)=error(TE,2)-tol1;
if find(kulerror>0)
    bool=0;
else
    bool=1;
end
       
end