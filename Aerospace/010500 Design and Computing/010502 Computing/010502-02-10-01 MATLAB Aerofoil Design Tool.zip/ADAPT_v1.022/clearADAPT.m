function clearADAPT(varargin)
fclose('all');
clearXFOIL;
terminateVGK;
clearVGK;
end