function ADAPT(S,a,cond,script)
%ADAPT(RBF ctrl pnt positions, inital aerofoil, flow conditions, script);
%
%ADAPT (Aerofoil Deformation And oPTimisation) is a radial basis function,
%two-dimensional aerofoil deformation and optimisation platform. It is
%coupled with a variety of two-dimensional aerodynamic solvers as well as a
%conjugate gradient, penalty function based optimiser.
%
%ADAPT allows simple optimisation and design tasks to be complete quickly
%and easily with the ability to directly compare results across different
%solvers and flow conditions.
%
%v1.02
%created by Dominic Masters, University of Bristol;
%please direct any quieries or issues to dominic.masters@bristol.ac.uk
global h
    h.fig=figure('units','pixels',...
              'name','Aerofoil Deformation And oPTimisation',...
              'numbertitle','off',...
              'resizefcn',@resizefig);
    hold on;
    if nargin<3
        cond=[0.6; 1e7; 0];
    end
    if nargin<4
        script=[];
    end
    terminateVGK;
%     addpath(genpath(fullfile(fileparts(pwd),'/ffd')))
    [isaero,a]=checkaerofoil(a);
    a_orig=a;
    S_orig=S;
    
    Css=setCss(S);
    Aas=setAas(S,a);
    H=Aas/Css;
    
    iter=0;
    Length=length(S(:,1));
    optiter=0;
    MESH_SHOWN=0;
    CMESH_SHOWN=0;
    CUT_CELL=0;
    CMESH=0;
    fixed=0;
    eulerstruc_run=0;
    Col='brmgcyk';
%     color={'blue';'red';'magenta';'green';'cyan';'yellow';'black'};
    Ams=[];Hmesh=[];M=[]; ACms=[]; HCmesh=[]; C=[]; Pairs=[];
    CL_orig=[]; CD_orig=[]; CP_orig=[]; CM_orig=[]; aarea_orig=[]; Objcurrent=[]; a_orig2=[]; obj_orig=[];
    OPTLOG=[]; vgkr=0; type=[]; solver=[]; CP_tar=[]; Mach=[]; alpha=[]; Re=[]; U=[];
    plotno=[]; PLOTS=[]; flagstop=0; Evals=[]; D=[]; SmCyc=[]; dk=[]; dk_last=[];
    gradJ=[]; gradJ_last=[]; CD=[]; CL=[]; CM=[]; CP=[];
    CG='PR'; % 'SD,'PR' or 'FR'
    %XFOIL default settings
    XFOILset.filt=2;
    XFOILset.Ncrit=9;
    XFOILset.VACC=0.01;
    XFOILset.XTrTop=1;
    XFOILset.XTrBottom=1;
    XFOILset.MaxIter=500;
    XFOILset.NPANEL=160;
    XFOILset.viscous=1;
    %VGK default settings
    VGKset.viscous=0;
    VGKset.XTU=0.1;
    VGKset.XTL=0.1;
    VGKset.NSurfaceMesh=160;
    VGKset.CoarseIter=100;
    VGKset.FineIter=200;
    VGKset.SubRelax=1.3;
    VGKset.SupRelax=1;
    VGKset.ArtVisc=0.8;
    VGKset.PartCons=0.25;
    VGKset.CMeshRelax=0.15;
    VGKset.CMeshInvIter=5;
    VGKset.FMeshRelax=0.15;%0.075?
    VGKset.FMeshInvIter=5;
    VGKset.MomThickXTU=0;
    VGKset.MomThickXTL=0;
    %Optimisation default settings
    OPTset.iter=100;
    OPTset.delta=1e-4;
    OPTset.convtol=1e-10;
    OPTset.k=2e-2;
    OPTset.diff=1e-8;
    OPTset.clcon=2;
    OPTset.areacon=2;
    OPTset.cmcon=2;
    OPTset.pencl=0.01;
    OPTset.pena=0.01;
    OPTset.pencm=0.01;
    OPTset.SmRad=0.2;
    OPTset.SmFac=0.4;
    OPTset.SmCyc=0;
    %Inverse Design default settings
    IDset.iter=100;
    IDset.target='NACA4412';
    IDset.convtol=1e-10;
    IDset.delta=1e-4;
    IDset.k=2e-2;
    IDset.diff=1e-8;
    IDset.settail=1;
    IDset.SmRad=0.2;
    IDset.SmFac=0.4;
    IDset.SmCyc=0;
    %Design Variable default settings
    DVset.SmRad=0.2;
    DVset.SmFac=0.4;
    DVset.SmCyc=1;
    %Gradient type (either trimmed or full)
    GradType='trimmed';
    
    run_interact=1; %used to stop interact running inside itself
    runinteractDE=1;
    h.presfig=[]; h.obfig=[]; h.obfunfig=[]; h.presfigvgk=[]; h.presfigES=[];
    h.presplotvgk=[]; h.DVeditfig=[];
    firstid=1; %flag first inverse design
    firstopt=1; %flag first optimisation
    for i=1:Length %set P
        P{i}=impoint(gca,S(i,:));
        h.imcallback{i}=addNewPositionCallback(P{i},@(pos) interact(pos, i));
        setPositionConstraintFcn(P{i},@(pos) constraintfunction(pos,i))
        h.ch(i)=uicontrol('style','checkbox',...
            'val',0,'visible','off');
        h.P(i) = findobj(P{i},'-depth',0);
    end
    %set rotation center
    h.rocen=impoint(gca,[mean(S(:,1)) mean(S(:,2))]); %rocen= rotation center
    set(h.rocen,'Visible','off');
    setColor(h.rocen,'green');
    
    pos_old=S;
    h.axes=get(get(0,'CurrentFigure'),'CurrentAxes');
    setpoints;
    set(h.axes, 'Units', 'pixels');
    setcbpos;
    meshon=0;
    cmeshon=0;
    R; h.ORF=[];
    ORF=1.3; vis=0; XTU='0.2'; XTL='0.2';
    
    DV=defaultDV;
%     DV=DV(1:end-stat);
%     DV=symmetricDV;
    
%         Length; P;  H; Hmesh;  cstaerofoil=[]; %extend scope
%     h.wsrbf1=[];h.wsrbf2=[];

%     createmesh(a);
    
    %BASE BUTTONS===============================================  
    h.export=uicontrol('string','Export',...
      'Position',[20 10 50 20],...
      'Callback',@export_input);
    h.refresh=uicontrol('string','Refresh',...
      'Callback',@resizefig); 
    h.plotpres=uicontrol('string','Potential Flow',...
      'Callback',{@potflow, 1, 1});
    h.xfoil=uicontrol('string','XFoil',...
      'Callback',@xfoillink,...  
      'ButtonDownFcn',@xfoilsettings);
    h.euler=uicontrol('string','Euler (Uns)',...
      'Callback',@eulerlink);
    h.eulers=uicontrol('string','Euler (Str)',...
      'Callback',@eulerstruclink);
    h.VGK=uicontrol('string','VGK',...
      'Callback',@VGKinterface,...
      'ButtonDownFcn',@VGKsettings);
    h.plotpresRe=uicontrol('style','text',...
     'string','Re =',...
     'BackgroundColor',[0.8 0.8 0.8]);
    h.plotpresalpha=uicontrol('style','text',...
     'string','alpha =',...
     'BackgroundColor',[0.8 0.8 0.8]);
    h.plotpresReedit=uicontrol('style','edit',...
     'string',num2str(cond(2),'%g'));
     %'callback',{@potflow, 0, a});
    h.plotpresalphaedit=uicontrol('style','edit',...
     'string',num2str(cond(3),'%g'));
     %'callback',{@potflow, 0, a});
     h.plotpresMach=uicontrol('style','text',...
     'string','Mach =',...
     'BackgroundColor',[0.8 0.8 0.8]);
     h.plotpresMachedit=uicontrol('style','edit',...
     'string',num2str(cond(1),'%g'));
     h.reset=uicontrol('string','Reset',...
          'Callback',@resetpoints);
     h.group=uicontrol('Style','Toggle',...
         'String','Show Grouping',...
         'Value',0,...
         'Callback',@group);
     h.selectall=uicontrol('string','Select All',...
          'Callback',@selectall);
     h.clrselection=uicontrol('string','Clear Selection',...
          'Callback',@clrselection);
     h.rotate=uicontrol('Style','Toggle',...
         'String','Rotate',...
         'Value',0,...
         'Callback',@rotate);
     h.showmesh=uicontrol('style','toggle',...
         'string','Show',...
         'Callback',@showmesh);
     h.createcut=uicontrol('string','Create Cut-Cell Mesh',...
        'callback',@createmesh);
     h.showcmesh=uicontrol('style','toggle',...
         'string','Show',...
         'Callback',@showcmesh);
     h.createcmesh=uicontrol('string','Create C-Mesh',...
        'callback',@createCmesh);
    h.editDE=uicontrol('style','toggle',...
        'string','Edit Control Points',...
        'callback',@editDE);
    h.addDE=uicontrol('string','Add',...
        'visible','off',...
        'callback',@addDE);
    h.removeDE=uicontrol('style','toggle',...
        'string','Remove',...
        'visible','off',...
        'callback',@removeDE);
    h.subdivisionDE=uicontrol('string','Sub Divsion',...
        'visible','off',...
        'callback',@subdivisionDE);
    h.DVedit=uicontrol('string','Edit Design Variables',...
        'callback',@designvariableeditor);
    h.optimise=uicontrol('string','Optimise',...
        'callback',@optimiseinput);
    h.inversedesign=uicontrol('string','Inverse Design',...
        'callback',@inversedesigninput);
    %=============================================================
     h.lastused=0; %initialise for later
     h.origaero=[]; %initialise for later
     h.targetaerofoil=[]; %initialise for later
     
    
     
% RBF FUNCTIONS =========================================================
function new_pos = constraintfunction(pos, j)
    if fixed==1
        new_pos=pos_old(j,:);
    elseif get(h.rotate, 'Value')==1
        cen=getPosition(h.rocen);
        r=norm(pos_old(j, :)-cen,2);
        theta=gettheta(pos-cen);
        new_pos=[r*cos(theta) r*sin(theta)] + cen;
    else
        new_pos=pos;
    end
end

function theta = gettheta(pos) %position about origin!!
        theta=atan(pos(2)/pos(1));
        if pos(1)<0
            theta = theta + pi;
        end   
end

function rotate(varargin)
    if get(h.rotate,'Value')==0
        set(h.rocen,{'visible'},{'off'});
    else
        set(h.rocen,{'visible'},{'on'});
    end
end

function group(varargin)
    if get(h.group,'Value')==0
        set(h.ch(:),{'visible'},{'off'});
    else
        set(h.ch(:),{'visible'},{'on'});
    end
end

function selectall(varargin)
        set(h.ch(:),'Value',1)
end

function clrselection(varargin)
        set(h.ch(:),'Value',0)
end
     
function setcbpos
    xlim = get(h.axes, 'XLim');
    ylim = get(h.axes, 'YLim');
    
    save_units = get(h.axes, 'Units');
    set(h.axes, 'Units', 'pixels')
    axes_position_in_pixels = get(h.axes,'Position');
    set(h.axes, 'Units', save_units)
    
    origin = [ xlim(1) ylim(1) ];
    corner = [ xlim(2) ylim(2) ];
    slope = corner - origin;
    
    for i=1:Length
        b=getPosition(P{i});
        normalized_position = (b(1:2) - origin) ./ slope;
        pos = axes_position_in_pixels(1:2) + ...
        normalized_position .* axes_position_in_pixels(3:4);
        pos=pos+[5 5];
        set(h.ch(i),'Position',[pos 14 14])
    end
end %set check box positions

function resetpoints(varargin)
    OPTLOG=[];
     run_interact=0;
     for ii=1:Length
         if ii==Length
             run_interact=1;
         end
        setPosition(P{ii},S_orig(ii,:));
        delete(R)
        setpoints; 
        setcbpos;
     end
     for l=1:Length %reset pos_old
        pos_old(l,:)=getPosition(P{l});
     end
     iter=0; optiter=0;
     if ishandle(h.origaero)==1
         delete(h.origaero)
     end
     if ishandle(h.targetaerofoil)==1
         delete(h.targetaerofoil)
     end
end

function setpoints
    %set(0,'CurrentFigure',h.fig)
    Q=zeros(Length+3,2);
    for ii=1:Length
        S(ii,:) = getPosition(P{ii});
    end
    Q(4:end,:)=S;
    a=H*Q; %key line; sets new point matrix
    R=plot(h.axes,a(:,1),a(:,2),'r');
end

function updatemesh()
    calcmesh();
    for I=1:M.totedges
set(h.mesh(I),'XData',[M.V1_pos(I,1),M.V2_pos(I,1)],'YData',[M.V1_pos(I,2),M.V2_pos(I,2)])
    end
end

function updatecmesh()
    for I=1:Length
        S(I,:) = getPosition(P{I});
    end
    calcCmesh(S);
    for I=1:3
        for J=1:2
set(h.cmesh(I,J),'XData',C.block{I}(C.route{I,J},1),'YData',C.block{I}(C.route{I,J},3))    
        end
    end
    if eulerstruc_run==1
      C.X1=reshape(C.block{1,1}(:,1),C.size(1,1),C.size(1,2));
      C.Y1=reshape(C.block{1,1}(:,3),C.size(1,1),C.size(1,2));
      C.X2=reshape(C.block{1,2}(:,1),C.size(2,1),C.size(2,2));
      C.Y2=reshape(C.block{1,2}(:,3),C.size(2,1),C.size(2,2));
      C.X3=reshape(C.block{1,3}(:,1),C.size(3,1),C.size(3,2));
      C.Y3=reshape(C.block{1,3}(:,3),C.size(3,1),C.size(3,2));
      C.X=[C.X1(1:end-1,:);C.X2(1:end-1,:);C.X3];
      C.Y=[C.Y1(1:end-1,:);C.Y2(1:end-1,:);C.Y3];
      set(h.flood,'XData',C.X,'YData',C.Y);
    end
end

function showmesh(varargin)
    if get(h.showmesh,'value')==1
        if CUT_CELL==0
            warningMessage = sprintf('Cut-cell mesh not present, create one now?');
            answer=questdlg(warningMessage);
            if strcmp(answer,'Yes')==1
                createmesh;
            else
                set(h.showmesh,'value',0)
                return
            end
        end
        meshon=1;
        calcmesh();
        
        if MESH_SHOWN==0
            for I=1:M.totedges
    h.mesh(I)=plot([M.V1_pos(I,1),M.V2_pos(I,1)],[M.V1_pos(I,2),M.V2_pos(I,2)],'color',M.colour(M.V1(I),:));
            
            end
            uistack(R,'top')
            for I=1:Length
                uistack(h.P(I),'top')
            end
        else
            updatemesh()
            set(h.mesh,'visible','on')
        end

        MESH_SHOWN=1;
    else
        meshon=0;
        set(h.mesh,'visible','off')
    end
    if cmeshon==1
        set(h.cmesh,'visible','off')
        if eulerstruc_run==1;
        set(h.flood,'visible','off')
        end
        cmeshon=0;
    end
        set(h.showcmesh,'value',0)
end

function showcmesh(varargin)
    if get(h.showcmesh,'value')==1
        if CMESH==0
            warningMessage = sprintf('C-mesh not present, create one now?');
            answer=questdlg(warningMessage);
            if strcmp(answer,'Yes')==1
                createCmesh;
            else
                set(h.showcmesh,'value',0)
                return
            end
        end
        cmeshon=1;
        calcCmesh(S);
        
        if CMESH_SHOWN==0
            for I=1:3
                C.route{I,1}=1:length(C.block{I});
                C.route{I,1}=C.route{I,1}';
                L=C.size(I,1);
                for K=2:2:C.size(I,2)
                    C.route{I,1}((K-1)*L+1:K*L)=flipud(C.route{I,1}((K-1)*L+1:K*L));
                end
            h.cmesh(I,1)=plot(C.block{I}(C.route{I,1},1),C.block{I}(C.route{I,1},3),'g');
            uistack(h.cmesh(I,1),'bottom');
            C.route{I,2}=[];
            for J=1:C.size(I,1)
                C.route{I,2}=[C.route{I,2}, J:C.size(I,1):C.n(I)];
            end
                C.route{I,2}=C.route{I,2}';
                L=C.size(I,2);
                for K=2:2:C.size(I,1)
                    C.route{I,2}((K-1)*L+1:K*L)=flipud(C.route{I,2}((K-1)*L+1:K*L));
                end
            h.cmesh(I,2)=plot(C.block{I}(C.route{I,2},1),C.block{I}(C.route{I,2},3),'g');   
            uistack(h.cmesh(I,2),'bottom');
            end
            if eulerstruc_run==1;
                set(h.flood,'visible','on')
            end
%             set(gca,'children',flipud(get(gca,'children')))
        else

            updatecmesh()
            set(h.cmesh,'visible','on')
            if eulerstruc_run==1;
                set(h.flood,'visible','on')
            end
        end
            if meshon==1
                set(h.mesh,'visible','off')
                meshon=0;
            end
        set(h.showmesh,'value',0)        
        CMESH_SHOWN=1;
    else
        cmeshon=0;
        set(h.cmesh,'visible','off')
        if eulerstruc_run==1;
        set(h.flood,'visible','off')
        end
    end
end

function editDE(varargin)
    if get(h.editDE,'Value')==1
        set(h.rotate,'value',0)
        rotate()
        set(h.group,'value',0)
        group()
        choice = questdlg(['Do you want to retain the current aerofoil and control point positions?'],...
            'Retain Positions?','Yes','No','Yes');
        switch choice
            case 'Yes'
                a_orig=a;
            case 'No'
                resetpoints()
        end
%         set(gcf, 'WindowButtonUpFcn', @ButtonUpFcn);
        buttonhandles=findobj('style','pushbutton','-or','style','toggle',...
            '-or','style','edit');
        set(buttonhandles,'Enable','off')
        set([h.reset; h.refresh],'Enable','on')
        set(h.editDE,'Enable','on')
        DEhandles=[h.addDE; h.removeDE; h.subdivisionDE];
        set(DEhandles,'visible','on')
        set(DEhandles,'enable','on')
        for ii=1:Length
        removeNewPositionCallback(P{ii},h.imcallback{ii});
        h.imcallback{ii}=addNewPositionCallback(P{ii},@(pos) interactDE(pos, ii));
        setColor(P{ii},'green')
        end
    else
        buttonhandles=findobj('style','pushbutton','-or','style','toggle',...
            '-or','style','edit');
        DEhandles=[h.addDE; h.removeDE; h.subdivisionDE];
        set(buttonhandles,'Enable','on')
        set(DEhandles,'visible','off')
        for ii=1:Length
        removeNewPositionCallback(P{ii},h.imcallback{ii});
        h.imcallback{ii}=addNewPositionCallback(P{ii},@(pos) interact(pos, ii));
        setColor(P{ii},'blue')
        % reinitialise RBF matrix
        S=[];
        for l=1:Length %set for next move
            S(l,:)=getPosition(P{l});
        end
        S_orig=S;
        pos_old=S;
%         DV=symmetricDV;
        DV=defaultDV;
        Css=setCss(S_orig);
        Aas=setAas(S_orig,a_orig);
        H=Aas/Css;
        delete(R)
        setpoints; 
        setcbpos;
        %=======================
        if meshon==1
            Ams=setAas(S_orig,M.vertexdata(:,2:3));
%             Cssmesh=setCss(S);
            Hmesh=Ams/Css;
        end
        if cmeshon==1
            for I=1:3
            ACms{I}=setAas(S_orig,C.block{I}(:,[1 3]));
            HCmesh{I}=ACms{I}/Css;
            end
        end
        end
    end
end

function addDE(varargin)
pos=ginput(1);
Length=Length+1;
P{Length}=impoint(h.axes,pos);
h.imcallback{Length}=addNewPositionCallback(P{Length},@(pos) interactDE(pos, Length));
setColor(P{Length},'green')
setPositionConstraintFcn(P{Length},@(pos) constraintfunction(pos,i))
h.ch(Length)=uicontrol('style','checkbox',...
    'val',0,'visible','off');
h.P(Length) = findobj(P{Length},'-depth',0);
setcbpos();
end

function removeDE(varargin)
    if get(h.removeDE,'Value')==1
        for j=1:Length
            set(h.ch(j),'visible','on')
            set(h.ch(j),'value',0)
        end
    else
        pdel=[];
        for j=1:Length
                removeNewPositionCallback(P{j},h.imcallback{j});
            if get(h.ch(j),'value')==1
                delete(h.P(j))
                delete(h.ch(j))
%                 delete(h.imcallback(j))
                pdel=[pdel, j];
            else
            set(h.ch(j),'visible','off')
            end
        end
        P(pdel)=[];
        h.imcallback=[];
        delete(h.imcallback)
        h.P(pdel)=[];
        h.ch(pdel)=[];
        Length=Length-length(pdel);
        for j=1:Length
        h.imcallback{j}=addNewPositionCallback(P{j},@(pos) interactDE(pos, j));
        end
    end
%     point=2;
%         P(point)=[];
%         removeNewPositionCallback(P{point},h.imcallback(point));
%         h.ch(point)=[];
%         h.imcallback(point)=[];
%         P
%         delete(h.P(point))
%         h.P(point)=[];
%         h.P
%         Length=Length-1;
end

function interactDE(varargin)   
    
end

function subdivisionDE(varargin)
    S=sortrows(S,2);
    S(S(:,2)>0,:)=sortrows(S(S(:,2)>0,:),1);
    S(S(:,2)<0,:)=flipud(sortrows(S(S(:,2)<0,:),1));
    sub=subdivision(S,1,1);
    for ii=1:Length
        setPosition(P{ii},sub(ii,:));
    end
    for ii=Length+1:length(sub(:,1))
        Length=Length+1;
        P{Length}=impoint(h.axes,sub(ii,:));
        h.imcallback{Length}=addNewPositionCallback(P{Length},@(pos) interactDE(pos, Length));
        setColor(P{Length},'green')
        setPositionConstraintFcn(P{Length},@(pos) constraintfunction(pos,i))
        h.ch(Length)=uicontrol('style','checkbox',...
            'val',0,'visible','off');
        h.P(Length) = findobj(P{Length},'-depth',0);
        setcbpos();
        for l=1:Length %set for next move
            S(l,:)=getPosition(P{l});
        end
    end
    DV=defaultDV;
end

function D=defaultDV(varargin)
    D=[];
    for ii=1:length(S(:,1))
        D{ii}=zeros(size(S));
        D{ii}(ii,:)=[0 1];
    end
end

function D=symmetricDV(varargin)
    D=[];
    [sym,pairs]=checksymmetry(S);
    
    if sym==1
        pairs=sortrows(pairs,2);
        pairs=sortrows(pairs',1);
        pairs=pairs';
        for ii=1:length(pairs(:,1))
            D{ii}=zeros(size(S));
            D{ii}(pairs(ii,1),:)=[0 1];
            D{ii}(pairs(ii,2),:)=[0 -1];
        end
    else
        D=defaultDV;
    end
end

function D=camb_thickDV(varargin)
    D=[];
    [sym,pairs]=checksymmetry(S);
    
    if sym==1
        pairs=sortrows(pairs,2);
        pairs=sortrows(pairs',1);
        pairs=pairs';
        for ii=1:length(pairs(:,1))
            D{2*ii-1}=zeros(size(S));
            D{2*ii-1}(pairs(ii,1),:)=[0 1];
            D{2*ii-1}(pairs(ii,2),:)=[0 -1];
            D{2*ii}=zeros(size(S));
            D{2*ii}(pairs(ii,1),:)=[0 1];
            D{2*ii}(pairs(ii,2),:)=[0 1];
        end
    else
        D=defaultDV;
    end
end

function designvariableeditor(varargin)
if isempty(h.DVeditfig)==1 || ishandle(h.DVeditfig)==0
    for ii=1:length(DV)
        for jj=1:length(DV{ii}(:,1))
            if isequal(DV{ii}(jj,:),[0 0])==0
                h.arrow{ii}(jj)=arrow(S(jj,:),S(jj,:)+(0.1*DV{ii}(jj,:)),15,'BaseAngle',60,...
                    'TipAngle',15,'facecolor',[0 1 0], 'edgecolor',[0 1 0]);
            else
                h.arrow{ii}(jj)=0;
            end
        end
    end
    sc=get(0,'ScreenSize');
    fp=get(h.fig,'Position');
    figpos=[fp(1) fp(2) 280 130+(25*length(S(:,1)))];
    if (figpos(1)+figpos(3))>sc(3)
        figpos(1)=figpos(1)+(sc(3)-figpos(1)-figpos(3));
    end
    if (figpos(2)+figpos(4))>sc(4)-25
        figpos(2)=figpos(2)+(sc(4)-(figpos(2)+figpos(4)))-25;
    end
    h.DVeditfig=figure('units','pixels',...
              'menubar','none',...
              'name','Design Variable Editor',...
              'numbertitle','off',...
              'resize','off',...
              'Position',figpos,...
              'CloseRequestFcn',@closefunction);
    fp=get(h.DVeditfig,'Position');
    buttonhandles=findobj('style','pushbutton','-or','style','toggle',...
        '-or','style','edit');
    set(h.rotate,'value',0)
    set(h.rocen,{'visible'},{'off'});
    set(buttonhandles,'Enable','off')
    set(h.DVedit,'Enable','on')
    
    fixed=1;
    DVno=1;
    for ii=1:length(DV{1}(:,1))
        if h.arrow{DVno}(ii)~=0;
        set(h.arrow{DVno}(ii),'facecolor',[1 0 0], 'edgecolor',[1 0 0])
        end
    end
    for ii=1:Length
        setString(P{ii},num2str(ii))
    end
    %=GUI BUTTONS====================
    h.DVtext1=uicontrol('style','text',...
        'string',['Design Variable ' num2str(DVno) ' of ' num2str(length(DV))],...
        'BackgroundColor',[0.8 0.8 0.8],...
        'Position',[10 fp(4)-25 130 16]);
    h.DVnext=uicontrol('string','Next',...
        'Position',[210 fp(4)-50 60 20],...
        'Callback',@next);
    h.DVprevious=uicontrol('string','Previous',...
        'Position',[145 fp(4)-50 60 20],...
        'Callback',@previous);
    h.DVadd=uicontrol('string','Add',...
        'Position',[10,fp(4)-50 60 20],...
        'Callback',@DVadd);
    h.DVdelete=uicontrol('string','Delete',...
        'Position',[75,fp(4)-50 60 20],...
        'Callback',@DVdelete);
%     h.DVtranslate=uicontrol('style','toggle',...
%         'string','Translate',...
%         'value',1,...
%         'Position',[145,fp(4)-50 60 20],...
%         'Callback',@DVtranslate);
%     h.DVrotate=uicontrol('style','toggle',...
%         'string','Rotate',...
%         'Position',[210,fp(4)-50 60 20],...
%         'enable','off',...
%         'Callback',@DVrotate);
    h.presetstext=uicontrol('style','text',...
        'string','Presets',...
        'Position',[10 35 90 16],...
        'BackgroundColor',[0.8 0.8 0.8]);
    h.presets=uicontrol('style','popup',...
        'string','Default|Symmetric|Camb_Thick|Custom',...
        'position',[105 35 120 20],...
        'callback',@presets);
    h.DVOK=uicontrol('string','OK',...
        'Position',[180 5 90 20],...
        'Callback',@closefunction);
%     h.DVnormalise=uicontrol('string','Normalise',...
%         'Position',[85 5 90 20],...
%         'Callback',@normalise);
%     h.DVtext3=uicontrol('style','text',...
%         'string','x',...
%         'Position',[145,fp(4)-70 60 16],...
%         'BackgroundColor',[0.8 0.8 0.8]);
    h.DVtext4=uicontrol('style','text',...
        'string','y',...
        'Position',[210,fp(4)-70 60 16],...
        'BackgroundColor',[0.8 0.8 0.8]);
    for jj=1:length(S(:,1))
        h.DVtext2{jj}=uicontrol('style','text',...
            'string',['Control Point ' num2str(jj)],...
            'BackgroundColor',[0.8 0.8 0.8],...
            'Position',[10 fp(4)-(65+25*jj) 190 16]);
%         h.DVx{jj}=uicontrol('style','edit',...
%             'string',num2str(DV{DVno}(jj,1)),...
%             'Position',[145 fp(4)-(65+25*jj) 60 20],...
%             'Callback',{@editDV,jj,1});
        h.DVy{jj}=uicontrol('style','edit',...
            'string',num2str(DV{DVno}(jj,2)),...
            'Position',[210 fp(4)-(65+25*jj) 60 20],...
            'Callback',{@editDV,jj,2});
    end
    

else
    figure(h.DVeditfig)
end
    function presets(varargin)
    try
       for jjj=1:length(DV)
           for iii=1:length(DV{jjj}(:,1))
                if h.arrow{jjj}(iii)~=0;
                    delete(h.arrow{jjj}(iii))
                end
           end
       end
    catch err
        err
    end
        preset=get(h.presets,'value');
        switch preset
            case 1 %defualt
                DV=defaultDV;
            case 2 %symmetric
                DV=symmetricDV;
            case 3 %symmetric
                DV=camb_thickDV;
            case 4 %custom
                
        end
    
    set(0, 'currentfigure', h.fig);
%     set(f, 'currentaxes', axs);
    for iii=1:length(DV)
        for jjj=1:length(DV{iii}(:,1))
            if isequal(DV{iii}(jjj,:),[0 0])==0
                h.arrow{iii}(jjj)=arrow(S(jjj,:),S(jjj,:)+(0.1*DV{iii}(jjj,:)),15,'BaseAngle',60,...
                    'TipAngle',15,'facecolor',[0 1 0], 'edgecolor',[0 1 0]);
            else
                h.arrow{iii}(jjj)=0;
            end
        end
    end
    set(0, 'currentfigure', h.DVeditfig);
    if DVno>length(DV)
        DVno=1;
    end
    for iii=1:length(DV{1}(:,1))
        if h.arrow{DVno}(iii)~=0;
        set(h.arrow{DVno}(iii),'facecolor',[1 0 0], 'edgecolor',[1 0 0])
        end
    end
    for jjj=1:length(S(:,1))
%         set(h.DVx{jjj},'string',num2str(DV{DVno}(jjj,1)))
        set(h.DVy{jjj},'string',num2str(DV{DVno}(jjj,2)))
    end
    set(h.DVtext1,'string',['Design Variable ' num2str(DVno) ' of ' num2str(length(DV))]);
    end

    function closefunction(varargin)
    if isempty(gcbf)
       if length(dbstack) == 1
              warning(message('MATLAB:closereq:ObsoleteUsage'));
       end
       close('force');
    else
       delete(gcbf);
       try
       for jjj=1:length(DV)
           for iii=1:length(DV{jjj}(:,1))
                if h.arrow{jjj}(iii)~=0;
                    delete(h.arrow{jjj}(iii))
                end
           end
       end
       end
       buttonhandles=findobj('style','pushbutton','-or','style','toggle',...
        '-or','style','edit');
    set(buttonhandles,'Enable','on')
    fixed=0;
    for II=1:Length
        setString(P{II},' ')
    end
    end
    end
    
    function next(varargin)
        try
        for iii=1:length(DV{DVno}(:,1))
            if h.arrow{DVno}(iii)~=0;
                set(h.arrow{DVno}(iii),'facecolor',[0 1 0], 'edgecolor',[0 1 0])
            end
        end
        end
        DVno=mod(DVno+1,length(DV));
        if DVno==0; DVno=length(DV); end
        set(h.DVtext1,'string',...
            ['Design Variable ' num2str(DVno) ' of ' num2str(length(DV))]);
        for iii=1:length(DV{DVno}(:,1))
            if h.arrow{DVno}(iii)~=0;
                set(h.arrow{DVno}(iii),'facecolor',[1 0 0], 'edgecolor',[1 0 0])
            end
        end
        for jjj=1:length(S(:,1))
%             set(h.DVx{jjj},'string',num2str(DV{DVno}(jjj,1)))
            set(h.DVy{jjj},'string',num2str(DV{DVno}(jjj,2)))
        end
    end
    
    function previous(varargin)
        for iii=1:length(DV{DVno}(:,1))
            if h.arrow{DVno}(iii)~=0;
                set(h.arrow{DVno}(iii),'facecolor',[0 1 0], 'edgecolor',[0 1 0])
            end
        end
        DVno=mod(DVno-1,length(DV));
        if DVno==0; DVno=length(DV); end
        set(h.DVtext1,'string',...
            ['Design Variable ' num2str(DVno) ' of ' num2str(length(DV))]);
        for iii=1:length(DV{DVno}(:,1))
            if h.arrow{DVno}(iii)~=0;
                set(h.arrow{DVno}(iii),'facecolor',[1 0 0], 'edgecolor',[1 0 0])
            end
        end
        for jjj=1:length(S(:,1))
%             set(h.DVx{jjj},'string',num2str(DV{DVno}(jjj,1)))
            set(h.DVy{jjj},'string',num2str(DV{DVno}(jjj,2)))
        end
    end
    
    function DVadd(varargin)
        for iii=1:length(DV{DVno}(:,1))
            if h.arrow{DVno}(iii)~=0;
                set(h.arrow{DVno}(iii),'facecolor',[0 1 0], 'edgecolor',[0 1 0])
            end
        end
        DV{end+1}=zeros(size(S));
        h.arrow{end+1}=zeros(size(h.arrow{1}));
        DVno=length(DV);
        set(h.DVtext1,'string',...
            ['Design Variable ' num2str(DVno) ' of ' num2str(length(DV))]);
        for jjj=1:length(S(:,1))
%             set(h.DVx{jjj},'string',num2str(DV{DVno}(jjj,1)))
            set(h.DVy{jjj},'string',num2str(DV{DVno}(jjj,2)))
        end
    end
    
    function DVdelete(varargin)
       if length(DV)>1
       for iii=1:length(DV{DVno}(:,1))
            if h.arrow{DVno}(iii)~=0;
                delete(h.arrow{DVno}(iii))
            end
       end
        DV=DV([1:DVno-1,DVno+1:end]);
        h.arrow=h.arrow([1:DVno-1,DVno+1:end]);
        next
        previous
       end
    end
    
    function DVtranslate(varargin)
        set(h.DVtranslate,'value',1)
    end
    
    function DVrotate(varargin)
        
    end
    
    function editDV(varargin)
        b(1)=varargin{3};
        b(2)=varargin{4};
        if b(2)==1
            DV{DVno}(b(1),b(2))=str2double(get(h.DVx{b(1)},'string'));
        elseif b(2)==2
            DV{DVno}(b(1),b(2))=str2double(get(h.DVy{b(1)},'string'));
        end
        try
            delete(h.arrow{DVno}(b(1)))
            h.arrow{DVno}(b(1))=0;
        end
        if isequal(DV{DVno}(b(1),:),[0 0])==0;
        set(0, 'currentfigure', h.fig)
        h.arrow{DVno}(b(1))=arrow(S(b(1),:),S(b(1),:)+(0.1*DV{DVno}(b(1),:)),...
            15,'BaseAngle',60,'TipAngle',15,'facecolor',[1 0 0], 'edgecolor',[1 0 0]);
        set(0, 'currentfigure', h.DVeditfig)
        end
        set(h.presets,'value',3);
    end
    
    function normalise(varargin)
        for iii=1:length(DV{DVno}(:,1));
            if norm(DV{DVno}(iii,:))==1 || norm(DV{DVno}(iii,:))==0;
            else
                DV{DVno}(iii,:)=DV{DVno}(iii,:)/norm(DV{DVno}(iii,:));
                set(h.DVx{iii},'string',num2str(DV{DVno}(iii,1)))
                set(h.DVy{iii},'string',num2str(DV{DVno}(iii,2)))
                set(0, 'currentfigure', h.fig)
                delete(h.arrow{DVno}(iii))
                h.arrow{DVno}(iii)=arrow(S(iii,:),S(iii,:)+(0.1*DV{DVno}(iii,:)),...
                15,'BaseAngle',60,'TipAngle',15,'facecolor',[1 0 0], 'edgecolor',[1 0 0]);
                set(0, 'currentfigure', h.DVeditfig)
            end
        end
    end
end

function DV=smoothDV(DV)
D=SmMat(S_orig,DVset.SmRad,DVset.SmFac,DVset.SmCyc);
for ii=1:length(S_orig(:,1))
    DV{ii}=D'*DV{ii};
end

end

function interact(varargin) %creates interactive loop for callback
    pos=varargin{1};
    j=varargin{2};
    if run_interact==1
        run_interact=0;
        if get(h.ch(j),'Value')==1
            if get(h.rotate,'Value')==1
                cen=getPosition(h.rocen);
                theta_change = gettheta(pos-cen)-gettheta(pos_old(j,:)-cen);
                for k=1:Length
                    if get(h.ch(k),'Value')==1 && k~=j
                        r=norm(getPosition(P{k})-cen,2);
                        theta=gettheta(getPosition(P{k})-cen);
                        theta=theta+theta_change;
                        setPosition(P{k},[r*cos(theta) r*sin(theta)] +cen );
                    end
                end
            else
            pos_change=pos-pos_old(j,:); %set change     
            for k=1:Length
                if get(h.ch(k),'Value')==1 && k~=j
                    setPosition(P{k},getPosition(P{k})+pos_change);
                end
            end
            end
        end
        for l=1:Length %set for next move
            pos_old(l,:)=getPosition(P{l});
        end
        delete(R)
        setpoints; 
        setcbpos;
%         if isempty(findobj('name','Pressure distribution on aerofoil'))==0
%             switch h.lastused
%                 case 2
%             %xfoillink(0,0,0,0);
%                 case 1
%             potflow(0,0,0,0);
%                 otherwise
%             end
%         end
        run_interact=1;
    end
    if meshon==1 && MESH_SHOWN==1
        updatemesh()
    end
    if cmeshon==1 && CMESH_SHOWN==1
        updatecmesh()
    end
end
%=====================================================================
% MESHING FUNCTIONS ================================================
function calcmesh()
    %set(0,'CurrentFigure',h.fig)
    Q=zeros(Length+3,2);
    for I=1:Length
        Q(I+3,:) = getPosition(P{I});
    end
    M.vertexdata(:,2:3)=Hmesh*Q; %key line; sets new point matrix
    for I=1:M.totedges
            M.V1(I)=M.edgedata(I,1);
            M.V1_pos(I,1:2)=M.vertexdata(M.V1(I),2:3);
            M.V2(I)=M.edgedata(I,2);
            M.V2_pos(I,1:2)=M.vertexdata(M.V2(I),2:3);
    end
end

function cp=readcp()
cp=importdata('euler\flowplt.plt');
cp=cp.textdata(7:3:(M.totvertices*3+4),1);
cp=str2double(cp);

end

function colour=setmeshcolour(cp)
mincp=min(cp);
maxcp=max(cp);
colour=zeros(length(cp),3);
for I=1:length(cp)
    if mincp<=cp(I) && cp(I)<(mincp+(0.25*(maxcp-mincp)))
            colour(I,3)=1;
            colour(I,2)=(cp(I)-mincp)/(0.25*(maxcp-mincp));
        elseif (mincp+(0.25*(maxcp-mincp)))<=cp(I) && cp(I)<(mincp+(0.5*(maxcp-mincp)))
            colour(I,2)=1;
            colour(I,3)=1-((cp(I)-mincp)/(0.25*(maxcp-mincp))-1);
        elseif (mincp+(0.5*(maxcp-mincp)))<=cp(I) && cp(I)<(mincp+(0.75*(maxcp-mincp)))
            colour(I,2)=1;
            colour(I,1)=(cp(I)-mincp)/(0.25*(maxcp-mincp))-2;            
        elseif (mincp+(0.75*(maxcp-mincp)))<=cp(I) && cp(I)<=maxcp
            colour(I,1)=1;
            colour(I,2)=1-((cp(I)-mincp)/(0.25*(maxcp-mincp))-3);
    end
end

end

function createmesh(varargin)
a_orig2=checkboundary(a_orig);
writeboundary(a_orig2)
fullFileName=fullfile(cd, 'euler\griduns');
% Mesh does not exist.
%   warningMessage = sprintf('Click OK to create mesh...', fullFileName);
%   uiwait(msgbox(warningMessage));
  promptm = {'N_{levels}','N_{buffer}'};
  dlg_titlem = 'Inputs for the Cut-cell mesher';
  num_linesm = 1;
  defm = {'11','5'};

  optionsm.Resize='on';
  optionsm.WindowStyle='normal';
  optionsm.Interpreter='tex';

  answerm = inputdlg(promptm,dlg_titlem,num_linesm,defm,optionsm);
  %answer(1)
  % number of refinement levels
  nlev = str2double(answerm(1));
  % number of buffer stages (ie width) for each level
  nbuf = str2double(answerm(2));
  
  filemeshsettings = fopen('euler\cutsettings','w+');
 
  % write the mesher input file
  % initial number of points along each each (x and y) - here 3, followed
  % by boundary flag for farfield (0) or wall (1)
  fprintf(filemeshsettings,'%s\t%s\t%s\t%s','3','3','0','0');
  % lower left farfield point
  fprintf(filemeshsettings,'\n%s\t%s','-25','-25');
  % upper right farfield point
  fprintf(filemeshsettings,'\n%s\t%s','25','25');
  % this is a flag to offset the background mesh (to avoid having geometry
  % and mesh points coincident). Set to 1 to activate.
  fprintf(filemeshsettings,'\n%s','1');
  % number of mesh levels to use
  fprintf(filemeshsettings,'\n%i',nlev);
  % need to specify the buffer number for each level
  for ii=1:nlev
      fprintf(filemeshsettings,'\n%i\t%i',ii,nbuf);
  end

  fclose(filemeshsettings);
  cd('euler')
  status = system('CartCell.exe');
  cd('..')
  M=importmesh();
  Ams=setAas(S,M.vertexdata(:,2:3));
%   Cssmesh=setCss(S);
  Hmesh=Ams/Css;
  if CUT_CELL==1 && MESH_SHOWN==1
          delete(h.mesh)
          calcmesh()
      for I=1:M.totedges
            M.V1(I)=M.edgedata(I,1);
            M.V1_pos(I,1:2)=M.vertexdata(M.V1(I),2:3);
            M.V2(I)=M.edgedata(I,2);
            M.V2_pos(I,1:2)=M.vertexdata(M.V2(I),2:3);
    h.mesh(I)=plot([M.V1_pos(I,1),M.V2_pos(I,1)],[M.V1_pos(I,2),M.V2_pos(I,2)],'color',M.colour(M.V1(I),:));
      end
        set(gca,'children',flipud(get(gca,'children')))
        if meshon==0
        set(h.mesh,'visible','off')
        end
            
  end
  CUT_CELL=1;
end

function createCmesh(varargin)
  promptm = {'N_{aerofoil}','N_{radial}','First Cell Height'};
  dlg_titlem = 'Inputs for the C mesher';
  num_linesm = 1;
  defm = {'97','33','0.75E-02'};

  optionsm.Resize='on';
  optionsm.WindowStyle='normal';
  optionsm.Interpreter='tex';

  answerm = inputdlg(promptm,dlg_titlem,num_linesm,defm,optionsm);
  
  A = regexp( fileread('CBACODES/gridgen.conf'), '\n', 'split');
  A{14} = sprintf('  surface.ni=%s',answerm{1});
  A{19} = sprintf('  grid.nj=%s',answerm{2});
  A{63} = sprintf('  surface.firstcellheight=%s',answerm{3});
  fid = fopen('CBACODES/gridgen.conf', 'w+');
  fprintf(fid, '%s\n', A{:});
  fclose(fid);
  
    %write aerofoil to file
    aero=fopen('CBACODES/aero.dat','w+');
    fprintf(aero,'RBF AEROFOIL \n %i',length(a_orig(:,1)));
    fprintf(aero,'\n\t %1.10f \t %1.10f',a_orig');
    fclose(aero);
    
    %run mesh generator
    cd('CBACODES')
    system('gridgen2d.exe');
    cd('..')
    
    C=importcmesh();
    for I=1:3
    ACms{I}=setAas(S_orig,C.block{I}(:,[1 3]));
    HCmesh{I}=ACms{I}/Css;
    end
%   if CMESH==1 && CMESH_SHOWN==1
%           delete(h.mesh)
%           calcmesh()
%       for I=1:M.totedges
%             M.V1(I)=M.edgedata(I,1);
%             M.V1_pos(I,1:2)=M.vertexdata(M.V1(I),2:3);
%             M.V2(I)=M.edgedata(I,2);
%             M.V2_pos(I,1:2)=M.vertexdata(M.V2(I),2:3);
%     h.mesh(I)=plot([M.V1_pos(I,1),M.V2_pos(I,1)],[M.V1_pos(I,2),M.V2_pos(I,2)],'color',M.colour(M.V1(I),:));
%       end
%         set(gca,'children',flipud(get(gca,'children')))
%         if meshon==0
%         set(h.mesh,'visible','off')
%         end
%             
%   end
  CMESH=1;
end

function calcCmesh(S1)
    Q=zeros(length(S1(:,1))+3,2);
    Q(4:end,:)=S1;
    for I=1:3
    C.block{I}(:,[1 3])=HCmesh{I}*Q; %key line; sets new point matrix
    end
end
%=================================================================
% OPTIMISER FUNCTIONS ============================================
function optimiseinput(varargin)
    scr=get(0,'ScreenSize');
    h.optinputfig=figure('units','pixels',...
              'menubar','none',...
              'name','Optimise Input',...
              'numbertitle','off',...
              'resize','off',...
              'Position',[scr(3)/2 scr(4)/2 400 265]);
    h.opttext2=uicontrol('style','text',...
              'string','Max Iterations',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 235 200 16]);
    h.optiter=uicontrol('style','edit',...
              'Position',[230 235 150 20],...
              'callback',{@setVAR,'iter'});
    h.opttext14=uicontrol('style','text',...
              'string','Convergence Tol',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 210 200 16]); 
    h.optconvtol=uicontrol('style','edit',...
              'Position',[230 210 150 20],...
              'callback',{@setVAR,'convtol'});
    h.opttext7=uicontrol('style','text',...
              'string','Delta',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 185 200 16]);
    h.optdelta=uicontrol('style','edit',...
              'Position',[230 185 150 20],...
              'callback',{@setVAR,'delta'});
    h.opttext8=uicontrol('style','text',...
              'string','Starting Step Size',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 160 200 16]);
    h.optk=uicontrol('style','edit',...
              'Position',[230 160 150 20],...
              'callback',{@setVAR,'k'});
    h.opttext9=uicontrol('style','text',...
              'string','Line Search Tol (<1e-4)',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 135 200 16]);
    h.optdiff=uicontrol('style','edit',...
              'Position',[230 135 150 20],...
              'callback',{@setVAR,'diff'}); 
    h.opttext11=uicontrol('style','text',...
              'string','Cl Constraint',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 110 200 16]);
    h.optclcon=uicontrol('style','popupmenu',...
              'position',[230 110 150 20],...
              'string',{'CL=CL0','CL>CL0'},...
              'callback',{@setVAR,'clcon'});
    h.opttext12=uicontrol('style','text',...
              'string','Area Constraint',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 85 200 16]);
    h.optareacon=uicontrol('style','popupmenu',...
              'position',[230 85 150 20],...
              'string',{'Area=Area0','Zup>Zup0, Zlo<Zlo0'},...
              'callback',{@setVAR,'areacon'});
    h.opttext13=uicontrol('style','text',...
              'string','Cm Constraint',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 60 200 16]);
    h.optcmcon=uicontrol('style','popupmenu',...
              'position',[230 60 150 20],...
              'string',{'CM=CM0','|CM|<|CM0|'},...
              'callback',{@setVAR,'cmcon'});      
    h.opttext10=uicontrol('style','text',...
              'string','Penalty Function Weights (Cl,Area,Cm)',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 35 200 16]);
    h.optpencl=uicontrol('style','edit',...
              'Position',[230 35 46 20],...
              'callback',{@setVAR,'pencl'});
    h.optpena=uicontrol('style','edit',...
              'Position',[282 35 46 20],...
              'callback',{@setVAR,'pena'});
    h.optpencm=uicontrol('style','edit',...
              'Position',[334 35 46 20],...
              'callback',{@setVAR,'pencm'});      
    h.optvgk=uicontrol('string','VGK',...
              'Position',[175 10 100 20],...
              'callback',{@opt,'VGK','OPT'});
    h.optxfoil=uicontrol('string','XFoil',...
              'Position',[280 10 100 20],...
              'callback',{@opt,'XFOIL','OPT'});
%     h.opteuler=uicontrol('string','Euler',...
%               'Position',[70 10 100 20],...
%               'enable','off',...
%               'callback',{@optEulerStruc,h});

        set(h.optiter,'string',OPTset.iter);
        set(h.optconvtol,'string',OPTset.convtol);
        set(h.optdelta,'string',OPTset.delta);
        set(h.optk,'string',OPTset.k);
        set(h.optdiff,'string',OPTset.diff);
        set(h.optclcon,'val',OPTset.clcon);
        set(h.optareacon,'val',OPTset.areacon);
        set(h.optcmcon,'val',OPTset.cmcon);
        set(h.optpencl,'string',OPTset.pencl);
        set(h.optpena,'string',OPTset.pena);
        set(h.optpencm,'string',OPTset.pencm);

    function setVAR(varargin)
        varname=varargin{3};
        if strcmp(varname,'clcon') || strcmp(varname,'areacon') || strcmp(varname,'cmcon')
        eval(['OPTset.' varname '=' num2str(get(varargin{1},'val')) ';'])
%         eval(['OPTset.' varname])
        else
        eval(['OPTset.' varname '=' get(varargin{1},'string') ';'])
%         eval(['OPTset.' varname])
        end
    end
end

function inversedesigninput(varargin)
    scr=get(0,'ScreenSize');
    h.idinputfig=figure('units','pixels',...
              'menubar','none',...
              'name','Inverse Design Input',...
              'numbertitle','off',...
              'resize','off',...
              'Position',[scr(3)/2 scr(4)/2 400 190]);
%     h.idtext3=uicontrol('style','text',...
%               'string','Solver',...
%               'BackgroundColor',[0.8 0.8 0.8],...
%               'Position',[10 185 200 16]);
%     h.idsolver=uicontrol('style','popupmenu',...
%               'position',[230 185 150 20],...
%               'string',{'Potential Flow','XFOIL','VGK'});
    h.idtext1=uicontrol('style','text',...
              'string','Target Aerofoil (Workspace Variable)',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 160 200 16]);
    h.idtext2=uicontrol('style','text',...
              'string','Max Iterations',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 135 200 16]);
    h.idtarget=uicontrol('style','edit',...
              'Position',[230 160 150 20],...
              'callback',{@setVAR,'target'});
    h.iditer=uicontrol('style','edit',...
              'Position',[230 135 150 20],...
              'callback',{@setVAR,'iter'});
    h.idtext5=uicontrol('style','text',...
              'string','Convergence Tol',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 110 200 16]); 
    h.idconvtol=uicontrol('style','edit',...
              'Position',[230 110 150 20],...
              'callback',{@setVAR,'convtol'});      
    h.idtext7=uicontrol('style','text',...
              'string','Delta',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 85 200 16]);
    h.iddelta=uicontrol('style','edit',...
              'Position',[230 85 150 20],...
              'callback',{@setVAR,'delta'});
    h.idtext8=uicontrol('style','text',...
              'string','Starting Step Size',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 60 200 16]);
    h.idk=uicontrol('style','edit',...
              'Position',[230 60 150 20],...
              'callback',{@setVAR,'k'}); 
    h.idtext9=uicontrol('style','text',...
              'string','Line Search Tol (<1e-4)',...
              'BackgroundColor',[0.8 0.8 0.8],...
              'Position',[10 35 200 16]);
    h.iddiff=uicontrol('style','edit',...
              'Position',[230 35 150 20],...
              'callback',{@setVAR,'diff'});
    h.idvgk=uicontrol('string','VGK',...
              'Position',[70 10 100 20],...
              'callback',{@opt,'VGK','ID'});
    h.idxfoil=uicontrol('string','XFoil',...
              'Position',[175 10 100 20],...
              'callback',{@opt,'XFOIL','ID'});
    h.idpotflow=uicontrol('string','Potential Flow',...
              'Position',[280 10 100 20],...
              'callback',{@opt,'POTFLOW','ID'});      
          
        set(h.idtarget,'string',IDset.target);
        set(h.iditer,'strin',IDset.iter);
        set(h.idconvtol,'string',IDset.convtol);
        set(h.iddelta,'string',IDset.delta);
        set(h.idk,'string',IDset.k);
        set(h.iddiff,'string',IDset.diff);

    function setVAR(varargin)
        varname=varargin{3};
        if strcmp(varname,'target')
        eval(['IDset.' varname '=''' get(varargin{1},'string') ''';'])  
        else
        eval(['IDset.' varname '=' get(varargin{1},'string') ';'])
        end
%         eval(['IDset.' varname])
    end
end

function opt(varargin)
    try
    type=varargin{4};
    solver=varargin{3};
    Evals=0;
    if strcmp(type,'OPT')
%     saveoptinfo;
    totaliterations=OPTset.iter;
    try
    close(h.optinputfig);
    end
    D=SmMat(S_orig,OPTset.SmRad,OPTset.SmFac,OPTset.SmCyc);
    SmCyc=OPTset.SmCyc;
    convtol=OPTset.convtol;
    elseif strcmp(type,'ID')
        totaliterations=IDset.iter;
        convtol=IDset.convtol;
        D=SmMat(S_orig,IDset.SmRad,IDset.SmFac,IDset.SmCyc);
        SmCyc=IDset.SmCyc;
        try
        close(h.idinputfig);
        end
        targetaerofoil=evalin('base',IDset.target);
        [isaerotar,targetaerofoil]=checkaerofoil(targetaerofoil);
        if strcmp(solver,'POTFLOW')
        tar_x=a(:,1);
        tar_x=tar_x-min(a(:,1));
        tar_x=tar_x/max(tar_x);
        targetaerofoil=splineaeroX(targetaerofoil,tar_x);
        end
        targetaerofoil=targetaerofoil*(max(a(:,1))-min(a(:,1)));
        targetaerofoil(:,1)=targetaerofoil(:,1)+min(a(:,1));
        convtol=IDset.convtol;
    end
    %Re=U/(1.36e-4); %U/kinematic viscosity of air at 20C
    if strcmp(solver,'VGK')
    alpha = get(h.plotpresalphaedit,'string');
    Mach = get(h.plotpresMachedit,'string');
    Re = str2double(get(h.plotpresReedit,'string'));
    Re= Re/(1e6);    
    elseif strcmp(solver,'XFOIL')
        Re=str2double(get(h.plotpresReedit,'string'));
    alpha=str2double(get(h.plotpresalphaedit,'string'));
    Mach=str2double(get(h.plotpresMachedit,'string'));
    elseif strcmp(solver,'POTFLOW')
    alpha=str2double(get(h.plotpresalphaedit,'string'));
    U=10;
    end
    if strcmp(type,'ID')
        if strcmp(solver,'XFOIL')
            [CP_tar,CL_tar,CD_tar,CM_tar]=xfoilinterface(targetaerofoil, alpha, Re, Mach);
            OPTLOG.CP_tar=CP_tar;
            OPTLOG.CL_tar=CL_tar;
            OPTLOG.CD_tar=CD_tar;
            OPTLOG.CM_tar=CM_tar;
            plotCP(CP_tar,['XFOIL_' type '_Target']);
        elseif strcmp(solver,'POTFLOW')
            [CP_tar,CL_tar]=potflowsolver(targetaerofoil,U,alpha,0);
            OPTLOG.CP_tar=CP_tar;
            OPTLOG.CL_tar=CL_tar;
            plotCP(CP_tar,['POTFLOW_' type '_Target']);
        elseif strcmp(solver,'VGK')
            [proc1,name1]=VGKstart(targetaerofoil,Mach,alpha,Re,'TAR');
            [CP_tar,CL_tar,CD_tar,CM_tar]=VGKfin(name1,proc1);
            OPTLOG.CP_tar=CP_tar;
            OPTLOG.CL_tar=CL_tar;
            OPTLOG.CD_tar=CD_tar;
            OPTLOG.CM_tar=CM_tar;
            plotCP(CP_tar,['VGK_' type '_Target']);
        end
    end
    %OPTIMISER
    firstiter=optiter;
%     optiter=0;
    if optiter==0
        OPTLOG.optiter=optiter+1;
        OPTLOG.solver={solver};
        OPTLOG.type={type};
    aarea_orig=calcarea(a);
    a_orig2=a;
    if strcmp(type,'OPT')
    h.origaero=plot(h.axes,a(:,1),a(:,2),'color',[0.2,0.2,0.2]);
    elseif strcmp(type,'ID')
        h.origaero=plot(h.axes,targetaerofoil(:,1),targetaerofoil(:,2),'color',[0.2,0.2,0.2]);
    end
    
    else
        OPTLOG.optiter=[OPTLOG.optiter; optiter+1];
        OPTLOG.solver=[OPTLOG.solver; solver];
        OPTLOG.type=[OPTLOG.type; type];
    end
    if strcmp(solver,'VGK')
        [proc1,name1]=VGKstart(a_orig2,Mach,alpha,Re,'OPT0');
        [CP_orig,CL_orig,CD_orig,CM_orig]=VGKfin(name1,proc1);
        OPTLOG.CP_orig=CP_orig;
        OPTLOG.CL_orig=CL_orig;
        OPTLOG.CD_orig=CD_orig;
    elseif strcmp(solver,'XFOIL') 
        [CP_orig,CL_orig,CD_orig,CM_orig]=xfoilinterface(a_orig2, alpha, Re, Mach);
%         if isempty(CD_orig)==1
%          [CP_orig,CL_orig,CD_orig,CM_orig]=xfoilinterface(a, alpha+1e-5, Re, Mach);
%         end
        OPTLOG.CP_orig=CP_orig;
        OPTLOG.CL_orig=CL_orig;
        OPTLOG.CD_orig=CD_orig;
    elseif strcmp(solver,'POTFLOW') 
        [CP_orig,CL_orig]=potflowsolver(a_orig2,U,alpha,0);
        OPTLOG.CP_orig=CP_orig;
        OPTLOG.CL_orig=CL_orig;
        CD_orig=1;
        CM_orig=[];
    end
    obj_orig=J(CD_orig,CL_orig,a_orig2,CP_orig,CM_orig);
    if optiter==0
    OPTLOG.obj_orig=obj_orig;
    else
    obj_orig=J(CD_orig,CL_orig,a_orig2,CP_orig,CM_orig);
    OPTLOG.obj_orig=[OPTLOG.obj_orig; obj_orig];
    end
    Evals=Evals+1;
    
    OPTLOG.aarea_orig=aarea_orig;
    
    CDnew=CD_orig;
    Clnew=CL_orig;
%     CP
    if strcmp(type,'OPT')
    fprintf('CD original = %1.3e, CL original = %1.3e, CM original = %1.3e\n',CD_orig, CL_orig, CM_orig);
    end
    
     if strcmp(solver,'VGK')
     [proc1,name1]=VGKstart(a,Mach,alpha,Re,'OPT');
     [CP,CL,CD,CM]=VGKfin(name1,proc1);
     plotCP(CP_orig,['VGK_' type '_Orig']);
     h.VGKoptplot=plotCP(CP,['VGK_' type]);
     elseif strcmp(solver,'XFOIL')
     [CP,CL,CD,CM]=xfoilinterface(a, alpha, Re, Mach);
%      if isempty(CD)==1
%          [CP,CL,CD,CM]=xfoilinterface(a, alpha+1e-5, Re, Mach);
%      end
     plotCP(CP_orig,['XFOIL_' type '_Orig']);
     h.XFOILoptplot=plotCP(CP,['XFOIL_' type]);
     elseif strcmp(solver,'POTFLOW')
     [CP,CL]=potflowsolver(a,U,alpha,0);
     CD=0;
     CM=[];
     plotCP(CP_orig,['POTFLOW_' type '_Orig']);
     h.POTFLOWoptplot=plotCP(CP,['POTFLOW_' type]);    
     end
     Evals=Evals+1;
     aarea=calcarea(a);
     Objcurrent=J(CD,CL,a,CP,CM);
     
%     obj_orig=J(CD_orig,CL_orig,aarea_orig);
    if isempty(h.obfunfig)==1 || ishandle(h.obfunfig)==0
     h.obfunfig=figure('menubar','none',...
    'numbertitle','off',...
    'name','Objective Function');
    ObPlot(optiter+1)=semilogy(optiter,Objcurrent,'bx');
    hold on;
    title('Objective Function');
    xlabel('Iterations');
    ylabel('Objective Function');
    h.obfunfigaxes=get(get(0,'CurrentFigure'),'CurrentAxes');
    end
    if isempty(CD_orig)==0
        if strcmp(type,'OPT')
       ObPlot(optiter+1)=semilogy(h.obfunfigaxes,optiter,CD,'rx');
        end
%     ObPlot(optiter+1)=semilogy(h.obfunfigaxes,optiter,Objcurrent,'bx');
    end
    drawnow
    if strcmp(type,'OPT')
    delta=OPTset.delta;
    elseif strcmp(type,'ID');
    delta=IDset.delta;
    end
    t_total=tic;
%     gradJ=zeros(Length,2);
    failed=0;
    
    
    for j=1:totaliterations 
       tic;
       fprintf('\nIteration %i\n',j);
       %compute sensitivities
       for m=1:Length
           posold(m,:)=getPosition(P{m});
       end
       gradJ=calcGrad(posold,delta);
       dk=conjGradient(gradJ,j);
%         Objcurrent
%         dk
        if any(dk)==0
            disp('Solution Converged as Gradient is Zero')
            break
        end
           % line search =======================
           if strcmp(type,'OPT')
           k=OPTset.k;
           elseif strcmp(type,'ID')
           k=IDset.k;
           end
           diff=100;
           if strcmp(type,'OPT')
           difflim=OPTset.diff;
           elseif strcmp(type,'ID')
           difflim=IDset.diff;
           end
           K=-k;
%            K_last=0;
%            K_last2=0;
           K_best=0;
           objnew=Objcurrent;
           obj_best=objnew;
           CLnew=CL;
           CDnew=CD;
           CPnew=CP;
           CMnew=CM;
           aareanew=aarea;
           dcount=0;
           count=0;
           it=0;
           Khist=0;
%                 objtemp=objnew;
%                CLtemp=CLnew;
%                CDtemp=CDnew;
%                CPtemp=CPnew;
%                CMtemp=CMnew;
               CD_best=CDnew;
               CL_best=CLnew;
               CP_best=CPnew;
               CM_best=CMnew;
               a_best=a;
               solverfailed=0;
           while abs(diff)>=difflim || count<3   
               it=it+1;
               diff=100;
%                if isempty(CDnew)==0
%                    objtemp=objnew;
%                    CLtemp=CLnew;
%                    CDtemp=CDnew;
%                    CPtemp=CPnew;
%                    CMtemp=CMnew;
%                end
%                aareatemp=aareanew;
%                posnew=posold;
               K=K+k;
               K_curr=K;
               k_curr=k;
               posnew=posold+K*dk;
               Qtemp=[0 0; 0 0; 0 0; posnew];
               atemp=H*Qtemp;
               max_def=max(abs(atemp(:,2)-a(:,2)));
               if max_def<0.1;
               if strcmp(solver,'VGK')
               [procls,namels]=VGKstart(atemp,Mach,alpha,Re,'LS');
               [CPnew,CLnew,CDnew,CMnew]=VGKfin(namels,procls);
               elseif strcmp(solver,'XFOIL')
                   try
               [CPnew,CLnew,CDnew,CMnew]=xfoilinterface(atemp, alpha, Re, Mach);
                   catch
                       CPnew=[];
                       CLnew=[];
                       CDnew=[];
                       CMnew=[];
                   end
               elseif strcmp(solver,'POTFLOW')
               [CPnew,CLnew]=potflowsolver(atemp,U,alpha,0);
               CMnew=[];
               CDnew=0;    
               end
               Evals=Evals+1;
               if isempty(CDnew)==1
                   objnew=[];
                   solverfailed=solverfailed+1;
                   status=sprintf('  solverfailed = %i',solverfailed);
                   if solverfailed>5 || (j~=1 && solverfailed >2)
                       K=K_best;
                         k=-k/2;
                   end
               elseif isempty(CDnew)==0
                   status=sprintf('  ok');
%                    K_last2=K_last;
%                    K_last=K;
                   solverfailed=0;
               aareanew=calcarea(atemp);
               objnew=J(CDnew,CLnew,atemp,CPnew,CMnew);
               end
               else
                   objnew=[];
                   status=sprintf('  Cancelled:Max_Def>10%%');
                   CPnew=[];
                   CLnew=[];
                   CDnew=[];
                   CMnew=[];
                   K=K_best;
                   k=-k/2;
               end
               obj_curr=objnew;
               if objnew>obj_best
                   diffold=diff;
                   diff=objnew-obj_best;
                   if diffold==diff
                       dcount=dcount+1;
                       if dcount>3% catch periodic changes
                           diff=0;
                       end
                   end
                   K=K_best;
                   atemp=a_best;
                   CLnew=CL_best;
                   CDnew=CD_best;
                   CPnew=CP_best;
                   CMnew=CM_best;
                   objnew=obj_best;
                   Khist(end+1)=K;
                   count=count +1;
                   k=-k/2;
               else
                   if isempty(CDnew)==0
                   diff=objnew-obj_best;
                   K_best=K;
                   CD_best=CDnew;
                   CL_best=CLnew;
                   CP_best=CPnew;
                   CM_best=CMnew;
                   a_best=atemp; 
                   obj_best=objnew;
                   if strcmp(solver,'VGK')
                   set(h.VGKoptplot,'XData',CP_best(:,1),'YData',-CP_best(:,2));
                   elseif strcmp(solver,'XFOIL')
                   set(h.XFOILoptplot,'XData',CP_best(:,1),'YData',-CP_best(:,2));
                   elseif strcmp(solver,'POTFLOW')
                   set(h.POTFLOWoptplot,'XData',CP_best(:,1),'YData',-CP_best(:,2));
                   end
                   drawnow
                   end
               end
                
               if it==1
               fprintf('%2s %2s  %12s  %13s %12s  %11s  %11s  %11s  %11s\n',...
                   'It','LS','Grad Step    ','Grad Step Best','Line Step    ','CD         ',...
                   'Objective ','Obj Best  ','Diff     ')
               end
               if isempty(CDnew)
                   CD_String='            ';
                   obj_string='            ';
               else
                   CD_String=num2str(CDnew,'%1.6e');
                   obj_string=num2str(obj_curr,'%1.6e');
               end
               if diff==100;
                   diff_string='            ';
               else
                   diff_string=num2str(diff,'%+1.6e');
               end
               text={num2str(it,'%2i'),num2str(count,'%2i'),num2str(K_curr,'%+1.6e'),...
                   num2str(K_best,'%+1.6e'),num2str(k_curr,'%+1.6e'),CD_String,...
                   obj_string,num2str(obj_best,'%1.6e'), diff_string,status};
               fprintf('%2s %2s  %11s  %12s  %12s  %11s  %11s  %11s  %11s %s\n',text{:})
               if abs(k)<1e-16
                   break
               end
           end
           fprintf('Objective Function = %1.6e\n', objnew)
           if j>1
           fprintf('Objective Function change this iteration = %1.6e\n', objnew-OPTLOG.obj(optiter))
           end
%            fprintf('\nCD = %1.6e\n', CDnew)
           fprintf('Number of Solver Evaluations = %i\n', Evals)
%             fprintf('\nStep size = %1.8e', K)
%             fprintf('\nStep size2 = %1.8e', k)
           %==================================
       run_interact=0;
       posnew=posold+K_best*dk; 
       for m=1:Length
           setPosition(P{m},posnew(m,:));
       end
       run_interact=1;
       delete(R)
       setpoints;
       if strcmp(type,'ID') && IDset.settail==1
        %get target tail position
        [dum_var,I]=max(targetaerofoil(:,1));
        targettail=targetaerofoil(I,:);
        [dum_var,I]=max(a(:,1));
           atail=a(I,:);
           taildiff=targettail-atail;
           for m=1:Length
               if m==Length
               run_interact=1;
               end
               setPosition(P{m},posnew(m,:)+[0 taildiff(2)]);%translate to tail
           end
           delete(R)
           setpoints; 
       end
       setcbpos;
       CP=CP_best;
       CD=CD_best;
       CL=CL_best;
       CM=CM_best;
       if strcmp(solver,'VGK')
%        [proc1,name1]=VGKstart(a,Mach,alpha,Re,'OPT');
%        [CP,CL,CD,CM]=VGKfin(name1,proc1);
       set(h.VGKoptplot,'XData',CP(:,1),'YData',-CP(:,2));
       elseif strcmp(solver,'XFOIL')
%        [CP,CL,CD,CM]=xfoilinterface(a, alpha, Re, Mach);
       set(h.XFOILoptplot,'XData',CP(:,1),'YData',-CP(:,2));
       elseif strcmp(solver,'POTFLOW')
%        [CP,CL]=potflowsolver(atemp,U,alpha,0);
%        CM=[];
%        CD=0;
       set(h.POTFLOWoptplot,'XData',CP(:,1),'YData',-CP(:,2));
       end
%        Evals=Evals+1;
%        if isempty(CD)==1
%            if strcmp(type,'ID') && IDset.settail==1
%            for m=1:Length
%                if m==Length
%                run_interact=1;
%                end
%                setPosition(P{m},posnew(m,:));%translate to tail
%            end
%            delete(R)
%            setpoints; 
%            end
%        setcbpos;
%        if strcmp(solver,'VGK')
%        [proc1,name1]=VGKstart(a,Mach,alpha,Re,'OPT');
%        [CP,CL,CD,CM]=VGKfin(name1,proc1);
%        set(h.VGKoptplot,'XData',CP(:,1),'YData',-CP(:,2));
%        elseif strcmp(solver,'XFOIL')
%        [CP,CL,CD,CM]=xfoilinterface(a, alpha, Re, Mach);
%        set(h.XFOILoptplot,'XData',CP(:,1),'YData',-CP(:,2));
%        elseif strcmp(solver,'POTFLOW')
%        [CP,CL]=potflowsolver(atemp,U,alpha,0);
%        CM=[];
%        CD=0;
%        set(h.POTFLOWoptplot,'XData',CP(:,1),'YData',-CP(:,2));
%        end
%        Evals=Evals+1;
%        end
optiter=optiter+1;
       aarea=calcarea(a);
       if isempty(CD)==0
           if strcmp(type,'OPT')
           try
       ObPlot(optiter+1)=plot(h.obfunfigaxes,optiter,CD,'rx');
           catch
           end
           end
       [Objcurrent,CLcon,Areacon,CMcon]=J(CD,CL,a,CP,CM);
       try
       ObPlot(optiter+1)=plot(h.obfunfigaxes,optiter,Objcurrent,'bx');
       catch
       end
       end
%        if (optiter-firstiter)>20
%            %delete(ObPlot(optiter-19))
%        end
       CD;
       try
       OPTLOG.S{optiter}=posnew;
       OPTLOG.aero{optiter}=a;
       OPTLOG.obj(optiter)=Objcurrent;
       OPTLOG.time(optiter)=toc;
       OPTLOG.evals(optiter)=Evals;
       OPTLOG.CP{optiter}=CP;
       OPTLOG.CD(optiter)=CD;
       OPTLOG.CL(optiter)=CL;
       if SmCyc~=0
           OPTLOG.gradJ0{optiter}=gradJ0;
       end
       OPTLOG.gradJ{optiter}=gradJ;
       OPTLOG.dk{optiter}=dk;
       if isempty(CM)==0
       OPTLOG.CM(optiter)=CM;
       OPTLOG.CM_change(optiter)=((CM-CM_orig)/CM_orig)*100;
       end
       OPTLOG.CD_change(optiter)=((CD-CD_orig)/CD_orig)*100;
       OPTLOG.CL_change(optiter)=((CL-CL_orig)/CL_orig)*100;
       if isempty(CLcon)==0
       OPTLOG.CLcon(optiter)=CLcon;
       end
       if isempty(Areacon)==0
       OPTLOG.Areacon(optiter)=Areacon;
       end
       if isempty(CMcon)==0
       OPTLOG.CMcon(optiter)=CMcon;
       end
       catch err2
           msgString = getReport(err2)
       end
       drawnow
    if isempty(CD)==1
        failed = failed +1;
        display('failed to calculate CD')
        if failed > 2
            display('optimisiation terminated')
%             delete(h.origaero);
        return
        end
    else
       fprintf('Obj: Current= %1.3e, Original= %1.3e, Change= %1.3e, %%-change= %3.2f\n',...
           Objcurrent, obj_orig,(Objcurrent-obj_orig),((Objcurrent-obj_orig)/obj_orig)*100); 
       if strcmp(type,'OPT') 
       fprintf('CD : Current= %1.3e, Original= %1.3e, Change= %1.3e, %%-change= %3.2f\n',...
           CD, CD_orig,(CD-CD_orig),((CD-CD_orig)/CD_orig)*100);
       fprintf('CL : Current= %1.3e, Original= %1.3e, Change= %1.3e, %%-change= %3.2f\n',...
           CL, CL_orig,(CL-CL_orig),((CL-CL_orig)/abs(CL_orig))*100);
       fprintf('CM : Current= %1.3e, Original= %1.3e, Change= %1.3e, %%-change= %3.2f\n',...
           CM, CM_orig,(CM-CM_orig),((CM-CM_orig)/abs(CM_orig))*100);
       if OPTset.areacon==1
       fprintf('Area: Current= %1.3e, Original= %1.3e, Change= %1.3e, %%-change= %3.2f\n',...
           aarea, aarea_orig,(aarea-aarea_orig),((aarea-aarea_orig)/aarea_orig)*100);
       OPTLOG.area(optiter)=aarea;
       elseif OPTset.areacon==2
           [dum_var,aind]=min(a_orig2(:,1));
                d=[a_orig2(1:aind,2)-a(1:aind,2);
                    a(aind:end,2)-a_orig2(aind:end,2)];
                N=sum(d<0);
                A=sum(-d(d<0));
       fprintf('Points Violating Thickness Constraint = %i, Total Thickness Violation = %1.3e\n',N, A);         
           OPTLOG.TotThickViol(optiter)=A;
           OPTLOG.NThickViol(optiter)=N;
       end
       end    
    end 
    assignin('base', 'optlog', OPTLOG)
           
   if j>1  
   iter_diff=OPTLOG.obj(end-1)-OPTLOG.obj(end);
   if iter_diff<convtol || K_best==0
       iter_diff;
       flagstop=flagstop+1;
       if flagstop>1
       fprintf('solution has converged to within convergence tolerance\n')
       break
       end
   else
       flagstop=0;
   end  
   end
%    calcGrad(posnew,delta)
       toc;
    end
    toc(t_total)
    catch err
        error(getReport(err))
    end

        
end

function [Val,con1,con2,con3]=J(CD,CL,aero,CP,CM)
if strcmp(type,'OPT')
penCl=OPTset.pencl;
penA=OPTset.pena;
penCm=OPTset.pencm;
con1=CLcon;
con2=areacon;
con3=CMcon;
Val=CD + penCl*con1 + penA*con2 + penCm*con3;
elseif strcmp(type,'ID')
    if strcmp(solver,'POTFLOW')
        Val=sqrt(mean((CP(:,2)-CP_tar(:,2)).^2));
    else
        [dum_var,mincp]=min(CP(:,1));
        [dum_var,mincpt]=min(CP_tar(:,1));
        CPs1=spline(CP(1:mincp,1),CP(1:mincp,2),CP_tar(1:mincpt,1));
        CPs2=spline(CP(mincp+1:end,1),CP(mincp+1:end,2),CP_tar(mincpt+1:end,1));
        CPs=[CPs1; CPs2];
        Val=sqrt(mean((CPs-CP_tar(:,2)).^2));
    end
con1=[];
con2=[];
con3=[];
end
function A=areacon
    if OPTset.areacon==1
        aarea_new=calcarea(aero);
        A=abs((aarea_new-aarea_orig)/aarea_orig);
    elseif OPTset.areacon==2
        [dum_var,aind]=min(a_orig2(:,1));
        d=[a_orig2(1:aind,2)-aero(1:aind,2);
            aero(aind:end,2)-a_orig2(aind:end,2)];
        A=sum(-d(d<0));
    end
end
function A=CLcon
    if OPTset.clcon==1
        A=abs(CL-CL_orig);
    elseif OPTset.clcon==2
        A=CL-CL_orig;
        if A>0
            A=0;
        end
        A=-A;
    end
end
function A=CMcon
    if OPTset.cmcon==1
        A=abs(CM-CM_orig);
    elseif OPTset.cmcon==2
        A=abs(CM)-abs(CM_orig);
        if A<0
            A=0;
        end
%                 A=-A;
    end
end
end
    
function gradJ=calcGrad(posold,delta)
    for l1=1:length(DV)
        posdelta=posold;
           posdelta=posdelta+(DV{l1}*delta);
           Qtemp=[0 0; 0 0; 0 0; posdelta];
           atemp=H*Qtemp;
       a_new{2*l1-1}=atemp;
       if strcmp(solver,'VGK')
        [proc{2*l1-1},name{2*l1-1}]=VGKstart(atemp,Mach,alpha,Re,['S' num2str(l1) 'p']);
       elseif strcmp(solver,'XFOIL')
       xf(2*l1-1)=xfoilstart(atemp, alpha, Re, Mach);
       elseif strcmp(solver,'POTFLOW')
       [CPpot1{l1},CLpot1(l1)]=potflowsolver(atemp,U,alpha,0);
       CM1=[];
       CD1=1;
       end
       posdelta=posold;
           posdelta=posdelta-(DV{l1}*delta);
           Qtemp=[0 0; 0 0; 0 0; posdelta];
           atemp=H*Qtemp;
       a_new{2*l1}=atemp;
       if strcmp(solver,'VGK')
        [proc{2*l1},name{2*l1}]=VGKstart(atemp,Mach,alpha,Re,['S' num2str(l1) 'm']);
       elseif strcmp(solver,'XFOIL')
       xf(2*l1)=xfoilstart(atemp, alpha, Re, Mach);
       elseif strcmp(solver,'POTFLOW')
       [CPpot2{l1},CLpot2(l1)]=potflowsolver(atemp,U,alpha,0);
       CM2=[];
       CD2=1;
       end
       Evals=Evals+2;
   end
   gradJ=zeros(size(S));
   for l1=1:length(DV)
       if strcmp(solver,'VGK')
       [CP1,CL1,CD1,CM1]=VGKfin(name{2*l1-1},proc{2*l1-1});
       [CP2,CL2,CD2,CM2]=VGKfin(name{2*l1},proc{2*l1});
       elseif strcmp(solver,'XFOIL')
       [CP1,CL1,CD1,CM1]=xfoilfinish(xf(2*l1-1));
%            if isempty(CD1)==1
%                [CP1,CL1,CD1,CM1]=xfoilinterface(a_new{2*l1-1}, alpha+1e-5, Re, Mach);
%            end
       CD1;
       [CP2,CL2,CD2,CM2]=xfoilfinish(xf(2*l1));
%            if isempty(CD2)==1
%                [CP2,CL2,CD2,CM2]=xfoilinterface(a_new{2*l1}, alpha+1e-5, Re, Mach);
%            end
       CD2;
       elseif strcmp(solver,'POTFLOW')
       CP1=CPpot1{l1};
       CP2=CPpot2{l1};
       CL1=CLpot1(l1);
       CL2=CLpot2(l1);
       end
           if isempty(CD1)==1 || isempty(CD2)==1 %stop error when CD is not calculated
               if isempty(CD1)==1 && isempty(CD2)==0
                    CD1=CD;
                    CL1=CL;
                    CP1=CP;
                    a_new{2*l1-1}=a;
                    CM1=CM;
                    Obj1=J(CD1,CL1,a_new{2*l1-1},CP1,CM1);
                    Obj2=J(CD2,CL2,a_new{2*l1},CP2,CM2);
                    if strcmp(GradType,'full')
                        sens(l1)=(Obj1-Obj2)/(delta);
                    else
                    if Obj2<Objcurrent%Obj1<Objcurrent || 
                        sens(l1)=(Obj1-Obj2)/(delta);
                        gradJ=gradJ+(sens(l1).*DV{l1});
                    else
                        sens(l1)=0;
                    end
                    end
               end
               if isempty(CD1)==0 && isempty(CD2)==1
                    CD2=CD;
                    CL2=CL;
                    CP2=CP;
                    a_new{2*l1}=a;
                    CM2=CM;
                    Obj1=J(CD1,CL1,a_new{2*l1-1},CP1,CM1);
                    Obj2=J(CD2,CL2,a_new{2*l1},CP2,CM2);
                    if strcmp(GradType,'full')
                        sens(l1)=(Obj1-Obj2)/(delta);
                    else
                    if Obj1<Objcurrent% || Obj2<Objcurrent
                        sens(l1)=(Obj1-Obj2)/(delta);
                        gradJ=gradJ+(sens(l1).*DV{l1});
                    else
                        sens(l1)=0;
                    end
                    end
               end
               if isempty(CD1)==1 && isempty(CD2)==1
%                         gradJ(l1,l2)=0;
                    CDall(l1,1)=0;
                   CDall(l1,2)=0;
                   Jall(l1,1)=0;
                   Jall(l1,2)=0;
                    disp(['Gradient not calculated for DV ' num2str(l1)])
               end
           else
                Obj1=J(CD1,CL1,a_new{2*l1-1},CP1,CM1);
                Obj2=J(CD2,CL2,a_new{2*l1},CP2,CM2);
                if strcmp(GradType,'full')
                    sens(l1)=(Obj1-Obj2)/(2*delta);
                else
                if Obj1<=Objcurrent || Obj2<=Objcurrent
                    sens(l1)=(Obj1-Obj2)/(2*delta);
                else
                    sens(l1)=0;
                end
                end
               gradJ=gradJ+(sens(l1).*DV{l1});
               CDall(l1,1)=CD1;
               CDall(l1,2)=CD2;
               Jall(l1,1)=Obj1;
               Jall(l1,2)=Obj2;
           end
   end
   gradJ0=gradJ;
   gradJ=D^SmCyc*gradJ;
%        CDall
%        Jall
%      gradJ
end

function dk=conjGradient(gradJ,j)
   % steepest decent method ===========
%            posnew=posold;
%            posnew(:,dof)=posold(:,dof)+k*gradJ(:,dof);
       %===================================
       % conjugate gradient method ========

    if j==1
        dk=-gradJ;
        gradJ_last=gradJ;
        dk_last=dk;
    else
        switch CG
            case 'SD' %steepest decent
                beta=[0 0];                
            case 'FR' %fletcher reeves
                beta(1)=(norm(gradJ(:,1),2)^2)/(norm(gradJ_last(:,1),2)^2);
                beta(2)=(norm(gradJ(:,2),2)^2)/(norm(gradJ_last(:,2),2)^2);
            case 'PR' %Polak Ribiere
                yk=gradJ-gradJ_last;
                if norm(gradJ_last(:,1),2)^2==0
                    beta(1)=0;
                else
                beta(1)=(gradJ(:,1)'*yk(:,1))/(norm(gradJ_last(:,1),2)^2);
                end
                if norm(gradJ_last(:,2),2)^2==0
                    beta(2)=0;
                else
                beta(2)=(gradJ(:,2)'*yk(:,2))/(norm(gradJ_last(:,2),2)^2);
                end
        end
        dk=-gradJ+([beta(1)*dk_last(:,1) beta(2)*dk_last(:,2)]);
        gradJ_last=gradJ;
        dk_last=dk;
    end

end

function D=SmMat(S,Rad,Fac,Cyc)
for ii=1:length(S(:,1))
    for jj=1:length(S(:,1))
    D(ii,jj)=norm(S(ii,:)-S(jj,:)); 
    end   
end
D(S(:,2)<0,S(:,2)>0)=Rad+1;
D(S(:,2)>0,S(:,2)<0)=Rad+1;
OUT=D>Rad;
IN=D<=Rad;
D(OUT)=0;
D(IN)=Fac*(Rad-D(IN))/(Rad);
D(logical(eye(size(D))))=1;
D=D./(sum(D)'*ones(1,length(D(:,1))));
D=D^Cyc;
end

% SOLVER FUNCTIONS================================================
function [CP,CL,CD,CM]=xfoilinterface(aerofoil, alpha, Re, Mach)
    xf=xfoilstart(aerofoil, alpha, Re, Mach);
    [CP,CL,CD,CM]=xfoilfinish(xf);
end

function xf=xfoilstart(aerofoil, alpha, Re, Mach)
%ONLY USE FOR PARALLEL INSTANCES OF XFOIL
    dlmwrite('tempaerofoil.dat',aerofoil,'newline','pc','delimiter',' ');
    %=========================================
    %  Xfoil integration
    %=========================================
    xf = XFOIL;
    xf.KeepFiles = false; % Set it to true to keep all intermediate files created (Airfoil, Polars, ...)
    xf.Visible = false;
    %create aerofoil
    xf.Airfoil = Airfoil('tempaerofoil.dat');
    delete tempaerofoil.dat
    %Add five filtering steps to smooth the airfoil coordinates and help convergence
    xf.addFiltering(XFOILset.filt);
    %Change Panel Density
    xf.changePaneling(XFOILset.NPANEL);
    %Switch to OPER mode, and set Reynolds = 3E7, Mach = 0.1
    xf.addOperation(Re, Mach, XFOILset.Ncrit, XFOILset.VACC, XFOILset.XTrTop, XFOILset.XTrBottom);
    %Set maximum number of iterations
    xf.addIter(XFOILset.MaxIter)
    if XFOILset.viscous==0
        xf.addInviscid;
    end
    %Initializate the calculations
    xf.addAlpha(0,true);
    %Create a new polar
    xf.addPolarFile(['Polar' num2str(xf.ID) '.txt']);
    
    %NOTE: Can Calculate a sequence of angle of attack
    xf.addAlpha(alpha);
    xf.addPressureFile(['Pressure' num2str(xf.ID) '.txt']);
    %Close the polar file
    xf.addClosePolarFile;
    %And finally add the action to quit XFOIL
    xf.addQuit;
    xf.run
    %disp('Running XFOIL, please wait...')
end

function [CP,CL,CD,CM]=xfoilfinish(xf)
%ONLY USE FOR PARALLEL INSTANCES OF XFOIL
finished = xf.wait(200);
    if finished
        %disp('XFOIL analysis finished.')
        try
        xf.readPolars;
        CD=xf.Polars{1,1}.CD;
        CL=xf.Polars{1,1}.CL;
        CM=xf.Polars{1,1}.CM;
        fid=fopen(['Pressure' num2str(xf.ID) '.txt']);
        CP=textscan(fid,'   %f  %f','HeaderLines',1);
        fclose(fid);
        CP=cell2mat(CP);
        delete(['Pressure' num2str(xf.ID) '.txt']);
        catch
            CD=[];
            CL=[];
            CM=[];
            CP=[];
        end
    else
        xf.kill;
    end
    %=========================================
     
end

function xfoillink(varargin)
%     if varargin{3}==2
%         h.lastused=2; %2==xfoil 1==potflow
%     end
%       figHandle = ancestor(src, 'figure');
%       clickType = get(h.fig, 'SelectionType')
%       if strcmp(clickType, 'alt')
%           disp('right click action goes here!');
%       end
        %varargin{3}=2 => open if not already open
    Re=str2num(get(h.plotpresReedit,'string'));
    alpha=str2double(get(h.plotpresalphaedit,'string'));
    Mach=str2double(get(h.plotpresMachedit,'string'));
    %Re=U/(1.36e-4); %U/kinematic viscosity of air at 20C
        aerofoil = a;
    [Pressure,CL,CD]=xfoilinterface(aerofoil, alpha, Re, Mach);
        CD
        CL
    plotCP(Pressure,'XFoil');

end

function xfoilsettings(varargin)
    prompt = {'Max Iterations','No. Panels (<354)','No Filtering Steps'...
        'Viscous','Vaccel','N Crit','Transition Top','Transition Bottom'};
    dlg_title = 'XFOIL Settings';
    num_lines = 1;
    def = {num2str(XFOILset.MaxIter),num2str(XFOILset.NPANEL),...
        num2str(XFOILset.filt),num2str(XFOILset.viscous),...
        num2str(XFOILset.VACC),num2str(XFOILset.Ncrit),...
        num2str(XFOILset.XTrTop),num2str(XFOILset.XTrBottom)};


    options.Resize='on';
    options.WindowStyle='normal';

    % Input box
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    XFOILset.MaxIter=str2double(answer{1});
    XFOILset.NPANEL=str2double(answer{2});
    XFOILset.filt=str2double(answer{3});
    XFOILset.viscous=str2double(answer{4});
    XFOILset.VACC=str2double(answer{5});
    XFOILset.Ncrit=str2double(answer{6});
    XFOILset.XTrTop=str2double(answer{7});
    XFOILset.XTrBottom=str2double(answer{8});
end

function potflow(varargin)
if varargin{3}==1
    h.lastused=1; %2==xfoil 1==potflow
end
    %varargin{3}=1 => open if not already open
if isempty(h.presfig)==1 || ishandle(h.presfig)==0 || varargin{3}==1 
U=10;  %arbitary
alpha=str2double(get(h.plotpresalphaedit,'string'));
if varargin{4}==1
    printcl=1;
else
    printcl=0;
end
        aerofoil = a;
[cp,CL]=potflowsolver(aerofoil,U,alpha,printcl);
CL
plotCP(cp,'POTFLOW');
end
end

function [CP,CL]=potflowsolver(aerofoil,U,alpha,print)
[dum_var,amin]=min(aerofoil(:,1));
aerofoil=aerofoil-ones(length(aerofoil(:,1)),1)*aerofoil(amin,:);
aerofoil=aerofoil/max(aerofoil(:,1));
        
fsvel=U;
fsadeg=alpha;
% FREE STREAM STUFF
fsarad=fsadeg*pi/180.;
u_fs_ana=fsvel*cos(fsarad);
w_fs_ana=fsvel*sin(fsarad);

% GET GEOMETRY PANEL INFORMATION
xpan=aerofoil;
npaer=length(aerofoil);
npanel=npaer-1;

% DEFINE PANEL END POINTS
pan_sta=xpan(1:npanel,:);
pan_end=xpan(2:npanel+1,:);

% DEFINE PANEL ANGLES
dx=pan_end(:,1)-pan_sta(:,1);
dz=pan_end(:,2)-pan_sta(:,2);
tht_pan=atan2(dz,dx);
pan_len=sqrt(dx.*dx+dz.*dz);

% DEFINE CONTROL POINTS 
c1=0.5*ones(npanel,1);
c2=0.5*ones(npanel,1);
c1(1)=0.9; c2(1)=0.1;
c1(end)=0.1; c2(end)=0.9;
xcp=c1.*xpan(1:npanel,1)+c2.*xpan(2:npanel+1,1);
zcp=c1.*xpan(1:npanel,2)+c2.*xpan(2:npanel+1,2);
xcp=xcp';
zcp=zcp';

% INFLUENCE COEFFICIENTS
%convert to local panel coordinates
xx=xcp'*ones(1,npanel)-ones(npanel,1)*pan_sta(:,1)';
zz=zcp'*ones(1,npanel)-ones(npanel,1)*pan_sta(:,2)';
xend=pan_end(:,1)-pan_sta(:,1);
zend=pan_end(:,2)-pan_sta(:,2);
xpa=xx.*(ones(npanel,1)*cos(tht_pan'))+zz.*(ones(npanel,1)*sin(tht_pan'));
zpa=-xx.*(ones(npanel,1)*sin(tht_pan'))+zz.*(ones(npanel,1)*cos(tht_pan'));
x2=xend.*cos(tht_pan)+zend.*sin(tht_pan);
x3=ones(npanel,1)*x2';
%find r1(i,j),r2(i,j),th1(i,j),th2(i,j) as in Katz and Plotkin 
r1=sqrt(xpa.*xpa+zpa.*zpa);
r2=sqrt((xpa-x3).*(xpa-x3)+zpa.*zpa);
th1=atan2(zpa,xpa);
th2=atan2(zpa,(xpa-x3));
%compute velocity in panel frame
U1L=-(zpa.*log(r2./r1)+xpa.*(th2-th1)-x3.*(th2-th1))./(2.*pi().*x3);
U1L(logical(eye(npanel)))=-0.5*(xpa(logical(eye(npanel)))-x2)./x2;
U2L=(zpa.*log(r2./r1)+xpa.*(th2-th1))./(2.*pi()*x3);
U2L(logical(eye(npanel)))=0.5*xpa(logical(eye(npanel)))./x2;
W1L=-((x3-zpa.*(th2-th1))-xpa.*log(r1./r2)+x3.*log(r1./r2))./(2.*pi()*x3);
W1L(logical(eye(npanel)))=-1/(2.*pi());
W2L=((x3-zpa.*(th2-th1))-xpa.*log(r1./r2))./(2.*pi()*x3);
W2L(logical(eye(npanel)))=1/(2.*pi());
%return velocity to global coordinates
u1=U1L.*(ones(npanel,1)*cos(-tht_pan'))+W1L.*(ones(npanel,1)*sin(-tht_pan'));
u2=U2L.*(ones(npanel,1)*cos(-tht_pan'))+W2L.*(ones(npanel,1)*sin(-tht_pan'));
w1=-U1L.*(ones(npanel,1)*sin(-tht_pan'))+W1L.*(ones(npanel,1)*cos(-tht_pan'));
w2=-U2L.*(ones(npanel,1)*sin(-tht_pan'))+W2L.*(ones(npanel,1)*cos(-tht_pan'));
%get influence cooefficient
holda=-u2.*(sin(tht_pan)*ones(1,npanel))+w2.*(cos(tht_pan)*ones(1,npanel));
holda=[zeros(npanel,1) holda(:,1:end-1)];
holdb=u2.*(cos(tht_pan)*ones(1,npanel))+w2.*(sin(tht_pan)*ones(1,npanel));
holdb=[zeros(npanel,1) holdb(:,1:end-1)];
ainf=-u1.*(sin(tht_pan)*ones(1,npanel))+w1.*(cos(tht_pan)*ones(1,npanel))+holda; 
ainf(:,end+1)=-u2(:,end).*sin(tht_pan)+w2(:,end).*cos(tht_pan);
b=u1.*(cos(tht_pan)*ones(1,npanel))+w1.*(sin(tht_pan)*ones(1,npanel))+holdb;
b(:,end+1)=u2(:,end).*cos(tht_pan)+w2(:,end).*sin(tht_pan);

savinf=ainf;
%ADD KUTTA CONDITION
ainf(npaer,1)=1;
ainf(npaer,npaer)=1;

% FORM RHS
rhs(:,1)=(u_fs_ana*sin(tht_pan)-w_fs_ana*cos(tht_pan));
rhs(npaer,1)=0;

% FIND STRENGTHS
slam=ainf\rhs;

% CALCULATE SURFACE SOLUTION QUANTITIES AT CONTROL POINTS
vtpan=b*slam;
fstan=u_fs_ana*cos(tht_pan)+w_fs_ana*sin(tht_pan);
cp=1.-(vtpan+fstan).^2/(fsvel*fsvel);
lift1=sum((slam(1:end-1)+slam(2:end)).*pan_len);
lift2=sum(2.*(vtpan-fstan).*pan_len);
fx=-pan_len.*cp.*cos(tht_pan);
fy=pan_len.*cp.*sin(tht_pan);
lift3=sum(fx.*cos(fsarad)+fy.*sin(fsarad));
% velt_cp=-(vtpan+fstan);
CL=lift1/fsvel;
% if print==1
% lift1=lift1/fsvel;
% lift2=lift2/fsvel;
% lift3=lift3;
% end
CP=[xcp',cp];
h.lastused=1;
end

function eulerlink(varargin)
    if CUT_CELL==0
        warningMessage = sprintf('Cut-cell mesh not present, create one now?');
        answer=questdlg(warningMessage);
        if strcmp(answer,'Yes')==1
            createmesh;
        else
            set(h.showmesh,'value',0)
            return
        end
    end
    meshon=1;
        
    calcmesh();
    writemesh(M);
    vals=calleuler();
    plotCP([vals.data(:,1),-vals.data(:,3)],'Euler (unstruc)');
    M.cp=readcp();
    M.colour=setmeshcolour(M.cp);
    if MESH_SHOWN==1
        for I=1:M.totedges
            set(h.mesh(I),'color',M.colour(M.V1(I),:))
        end
    end
end

function vals=calleuler()
% to compile stand-alone, use:
% mcc -m calleuler.m -d 'C:\place'

% There are many other options for the solver, however this script only supports
% steady flow calculations.

%delete old plot file
try
delete('euler\cp.dat')
end
% Determine Mach numer, angle of attack, timestep and iterations
prompt = {'M_{\infty}:','\alpha','CFL','N_{iterations}'};
dlg_title = 'Inputs for the Euler solver';
num_lines = 1;
% Defaults will be inappropriate for larger meshes
aoa = get(h.plotpresalphaedit,'string');
mach = get(h.plotpresMachedit,'string');
def = {mach,aoa,'2.0','4000'};

options.Resize='on';
options.WindowStyle='normal';
% Allow latex formatting of the text box
options.Interpreter='tex';

% Input box
answer = inputdlg(prompt,dlg_title,num_lines,def,options);
% Extract results
mach = str2double(answer(1));
aoa = str2double(answer(2));
CFL = str2double(answer(3));
nit = str2double(answer(4));

fileflowsettings = fopen('euler\settings','w+');

% Write the input file for the flow solver
% Solver can run sweeps in M or AoA. Here we only run a single case.
% number of Mach numbers, Mach start, Mach increment
fprintf(fileflowsettings,'%s\t%f\t%s','1',mach,'0.025');
% number of AoAs, AoA start, AoA increment
fprintf(fileflowsettings,'\n%s\t%f\t%s','1',aoa,'0.25');
% Density. Leave this unchanged.
fprintf(fileflowsettings,'\n%s','1.2');
% Temperature. Leave unchanged - this is set to achieve p_inf~1
fprintf(fileflowsettings,'\n%s','2.9e-3');
% Gamma. Leave unchanged.
fprintf(fileflowsettings,'\n%s','1.4');
% Gas constant R. Leave.
fprintf(fileflowsettings,'\n%s','287.0');
% option 0 stops code after nit cycles, 1 stops after residual tolerance
% (here -3). Best to use 0.
fprintf(fileflowsettings,'\n%s\t%i\t%s','0',nit,'-3.0');
% CFL number used to set explicit timestep
fprintf(fileflowsettings,'\n%f',CFL);
% 2nd order dissipation constant
fprintf(fileflowsettings,'\n%s','1.0');
% 4th order dissipation constant
fprintf(fileflowsettings,'\n%s','0.05');
% Don't change these. They are switches to apply dissipation at each stage
% of the RK integration. It is best to apply at the 1st stage and then keep
% constant, so this setting is optimal.
fprintf(fileflowsettings,'\n%s\t%s\t%s\t%s','1','0','0','0');
% steady (0), unsteady (1)    no restart (0), restart (1)
fprintf(fileflowsettings,'\n%s\t%s','0','0');
% unsteady settings - not used here, but these are sensible defaults if
% they were used
fprintf(fileflowsettings,'\n%s\t%s\t%s\t%s','.0956','600','30','1.0');
% mesh motion settings - not used here
fprintf(fileflowsettings,'\n%s\t%s','5','2.0');
% aeroelastic option - not used here
fprintf(fileflowsettings,'\n%s','2');

fclose(fileflowsettings);

%data
%pause

cd('euler')
status = system('EulerFlow.exe');
% pproc just makes the colourful tecplot files (flowplt.plt), and cp.dat 
status = system('pproc.exe');
cd('..')
% read in and plot Cp vs x.
filename = 'euler\cp.dat';
delimiterIn = ' ';
headerlinesIn = 1;
vals = importdata(filename,delimiterIn,headerlinesIn);

end

function eulerstruclink(varargin)
tic
if CMESH==0
    warningMessage = sprintf('C-mesh not present, create one now?');
    answer=questdlg(warningMessage);
    if strcmp(answer,'Yes')==1
        createCmesh;
    else
        set(h.showcmesh,'value',0)
        return
    end
end
cmeshon=1;
calcCmesh(S);
writecmesh(C);
  A = regexp( fileread('CBACODES/rotorsim.conf'), '\n', 'split');
  A{50} = sprintf('  flow.mach=%s',get(h.plotpresMachedit,'string'));
  A{53} = sprintf('  flow.incidence=%s',get(h.plotpresalphaedit,'string'));
  fid = fopen('CBACODES/rotorsim.conf', 'w');
  fprintf(fid, '%s\n', A{:});
  fclose(fid);
  
  [CP,CL,CD]=eulerstruc(varargin);
  CL
  CD
  
  plotCP([CP(:,1), -CP(:,2)],'Euler (struc)');
        s=3;
      C.solution1=importdata('CBACODES/flowfield.plt',' ',s);
      C.solution1=C.solution1.data;
      s=s+length(C.solution1(:,1))+1;
      C.solution2=importdata('CBACODES/flowfield.plt',' ',s);
      C.solution2=C.solution2.data;
      s=s+length(C.solution2(:,1))+1;
      C.solution3=importdata('CBACODES/flowfield.plt',' ',s);
      C.solution3=C.solution3.data;
      
      if eulerstruc_run==0
      C.X1=reshape(C.block{1,1}(:,1),C.size(1,1),C.size(1,2));
      C.Y1=reshape(C.block{1,1}(:,3),C.size(1,1),C.size(1,2));
%       C.Z1=reshape(C.block{1,1}(:,2),C.size(1,1),C.size(1,2));
      C.Col1=reshape(C.solution1(:,8),C.size(1,1),C.size(1,2));
      C.X2=reshape(C.block{1,2}(:,1),C.size(2,1),C.size(2,2));
      C.Y2=reshape(C.block{1,2}(:,3),C.size(2,1),C.size(2,2));
%       C.Z2=reshape(C.block{1,2}(:,2),C.size(2,1),C.size(2,2));
      C.Col2=reshape(C.solution2(:,8),C.size(2,1),C.size(2,2));
      C.X3=reshape(C.block{1,3}(:,1),C.size(3,1),C.size(3,2));
      C.Y3=reshape(C.block{1,3}(:,3),C.size(3,1),C.size(3,2));
%       C.Z3=reshape(C.block{1,3}(:,2),C.size(3,1),C.size(3,2));
      C.Col3=reshape(C.solution3(:,8),C.size(3,1),C.size(3,2));
      C.X=[C.X1(1:end-1,:);C.X2(1:end-1,:);C.X3];
      C.Y=[C.Y1(1:end-1,:);C.Y2(1:end-1,:);C.Y3];
      C.Z=zeros(size(C.X));
      C.Col=[C.Col1(1:end-1,:);C.Col2(1:end-1,:);C.Col3];
      h.flood=surf(h.axes,C.X,C.Y,C.Z,C.Col,...
      'facecolor','interp','edgealpha',0);
      else
           C.Col1=reshape(C.solution1(:,8),C.size(1,1),C.size(1,2));
           C.Col2=reshape(C.solution2(:,8),C.size(2,1),C.size(2,2));
           C.Col3=reshape(C.solution3(:,8),C.size(3,1),C.size(3,2));
           C.Col=[C.Col1(1:end-1,:);C.Col2(1:end-1,:);C.Col3];
           set(h.flood,'CData',C.Col)
      end
      
      uistack(h.flood,'bottom')
      eulerstruc_run=1;
      if CMESH_SHOWN==0
          set(h.flood,'visible','off')
      end
    toc
end

function [CP,CL,CD]=eulerstruc(varargin)
      batchES = fopen('CBACODES\batch.bat','w+');
      fprintf(batchES,'\n%s','preproc.exe');
      fprintf(batchES,'\n%s','rotorsim.exe');
      fprintf(batchES,'\n%s','echo 1 | postsurface.exe');
      fprintf(batchES,'\n%s','echo 1 | postvolume.exe');
      fprintf(batchES,'\n\n%s\n','exit 0');
      fclose(batchES);

      cd('CBACODES')
%       system('preproc.exe');
%       system('rotorsim.exe');
%       system('echo 1 | postsurface.exe');
%       system('echo 1 | postvolume.exe');
%       status=system('start /b /min batch.bat &');
      status=system('batch.bat &');
      cd('..')
      
      flag1 = true;
      flag2 = true;
      flag3 = true;
      flag4 = true;
        while flag1 || flag2 || flag3 || flag4
             flag1 = isprocess('preproc.exe');
             flag2 = isprocess('rotorsim.exe');
             flag3 = isprocess('postsurface.exe');
             flag4 = isprocess('postvolume.exe');
             pause(0.5) % check every 1 second
        end
      
      C.Cp=importdata('CBACODES/cpversusx.plt',' ',2);
      C.Cp=C.Cp.data;
      CP=C.Cp;
      fid = fopen('CBACODES\finalloads.dat');
      Text=textscan(fid,'%s','delimiter','\n');
      data=str2num(Text{1}{end});
      fclose(fid);
      C.CL=data(1);
      C.CD=data(2);
      C.CMz=data(5);
      CL=C.CL;
      CD=C.CD;
      CMz=C.CMz;
end

function VGKinterface(varargin)
%     VGKinput;
%     uiwait(h.VGKinputfig)
%     close(h.VGKinputfig)
    aoa = get(h.plotpresalphaedit,'string');
    mach = get(h.plotpresMachedit,'string');
    Re = str2double(get(h.plotpresReedit,'string'));
    Re= Re/(1e6);
%     if vis==1
%         prompt = {'Upper Surface','Lower Surface'};
%         dlg_title = 'Define transition points';
%         num_lines = 1;
%         def = {'0.2','0.2'};
% 
%         options.Resize='on';
%         options.WindowStyle='normal';
% 
%         % Input box
%         answer = inputdlg(prompt,dlg_title,num_lines,def,options);
%         XTU=answer{1};
%         XTL=answer{2};
%     end
%     [CP,CL,CD,CM]=VGK(a,ORF,mach,aoa,Re,XTU,XTL,'run');
    [proc,name]=VGKstart(a,mach,aoa,Re,'MAIN');
    [CP,CL,CD,CM]=VGKfin(name,proc);
    CD
    CL
    CM
    if VGKset.viscous==1
        plotCP(CP,'VGK (viscous)');
    else
        plotCP(CP,'VGK (inviscid)');
    end
end

function VGKsettings(varargin)
    prompt = {'Coarse Mesh Iterations','Fine Mesh Iterations','No. Panels (90-160)',...
        'Viscous','Subsonic Relaxation Parameter','Supersonic Relaxation Parameter',...
        'Artifical Viscosity','Partially Conservative Parameter'};
    dlg_title = 'VGK Settings';
    num_lines = 1;
    def = {num2str(VGKset.CoarseIter),num2str(VGKset.FineIter),...
        num2str(VGKset.NSurfaceMesh),num2str(VGKset.viscous),...
        num2str(VGKset.SubRelax),num2str(VGKset.SupRelax),...
        num2str(VGKset.ArtVisc),num2str(VGKset.PartCons)};
    options.Resize='on';
    options.WindowStyle='normal';
    % Input box
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    VGKset.CoarseIter=str2double(answer{1});
    VGKset.FineIter=str2double(answer{2});
    VGKset.NSurfaceMesh=str2double(answer{3});
    VGKset.viscous=str2double(answer{4});
    VGKset.SubRelax=str2double(answer{5});
    VGKset.SupRelax=str2double(answer{6});
    VGKset.ArtVisc=str2double(answer{7});
    VGKset.PartCons=str2double(answer{8});
    if VGKset.viscous==1
    prompt = {'Upper Transition Point (XTU)','Lower Transition Point (XTL)','Coarse Mesh Relaxation','Coarse Mesh BL Iteration Ratio',...
        'Fine Mesh Relaxation','Fine Mesh BL Iteration Ratio',...
        'Momentum Thickness at XTU','Momentum Thickness at XTL'};
    dlg_title = 'VGK Viscous Settings';
    num_lines = 1;
    def = {num2str(VGKset.XTU),num2str(VGKset.XTL),...
        num2str(VGKset.CMeshRelax),num2str(VGKset.CMeshInvIter),...
        num2str(VGKset.FMeshRelax),num2str(VGKset.FMeshInvIter),...
        num2str(VGKset.MomThickXTU),num2str(VGKset.MomThickXTL)};
    options.Resize='on';
    options.WindowStyle='normal';
    % Input box
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    VGKset.XTU=str2double(answer{1});
    VGKset.XTL=str2double(answer{2});
    VGKset.CMeshRelax=str2double(answer{3});
    VGKset.CMeshInvIter=str2double(answer{4});
    VGKset.FMeshRelax=str2double(answer{5});
    VGKset.FMeshInvIter=str2double(answer{6});
    VGKset.MomThickXTUx=str2double(answer{7});
    VGKset.MomThickXTL=str2double(answer{8});
    end
end

function [proc,name]=VGKstart(a,mach,aoa,Re,name)
    
[dum_var,a]=checkaerofoil(a);
[dum_var,amin]=min(a(:,1));
a=a-ones(length(a(:,1)),1)*a(amin,:);
amax=max(a(:,1));
a=a/amax;
[LE,mina]=min(a(:,1));
TE=max(a(:,1));
nu=length(a(:,1))-mina+1;
nl=mina;
[aero,message] = fopen(['VGK\' name 'aero.dat'],'wt+');
% [aero,message] = fopen('VGK\aero2.dat','wt+')
fprintf(aero,'%s\n','AEROFOIL COORDINATES');
fprintf(aero,'  %i     %i   %i %3.3f %3.3f\n  ',0,nu,nl,LE,TE);
for I=mina:length(a(:,1))
    if a(I,1)<0
        fprintf(aero,'\n %2.6f', a(I,1));
    else
        fprintf(aero,'\n  %2.6f', a(I,1));
    end
    if a(I,2)<0
        fprintf(aero,' %2.6f', a(I,2));
    else
        fprintf(aero,'  %2.6f', a(I,2));
    end
end
for I=mina:-1:1
    if a(I,1)<0
        fprintf(aero,'\n %2.6f', a(I,1));
    else
        fprintf(aero,'\n  %2.6f', a(I,1));
    end
    if a(I,2)<0
        fprintf(aero,' %2.6f', a(I,2));
    else
        fprintf(aero,'  %2.6f', a(I,2));
    end
end
fprintf(aero,'\n\n');
fclose(aero);

batch = fopen(['VGK\batch' name '.bat'],'wt+');
% name=['run' num2str(num)];

if VGKset.viscous==0 %inviscid
%     num2str(mach)
fprintf(batch,'\n%s',['(echo ' name]);
fprintf(batch,'\n%s','echo 1'); %title
fprintf(batch,'\n%s','echo 0'); %0 inviscid, 1 viscous
fprintf(batch,'\n%s','echo 1'); %new run
fprintf(batch,'\n%s',['echo ' name 'aero.dat']); %aerofoil
% fprintf(batch,'\n%s',['echo aero2.dat']); %aerofoil
fprintf(batch,'\n%s\n%s\n%s','echo n','echo n','echo n'); %stop creation of unnecessary files
fprintf(batch,'\n%s',['echo ' mach]); %mach
fprintf(batch,'\n%s',['echo ' aoa]); %angle of attack
fprintf(batch,'\n%s','echo y'); %advanced settings
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.NSurfaceMesh)]); %surface mesh points
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.CoarseIter)]); %coarse iterations
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.FineIter)]); %fin iterations
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.SubRelax)]); %over relaxation parameter
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.SupRelax)]); %under relaxation parameter
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.ArtVisc)]); %artificial viscosity
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.PartCons)]); %Partially-Conservative para
fprintf(batch,'%s',') | vgkcon.exe'); %default values
fprintf(batch,'\n%s',['echo ' name ' | vgkv20.exe']);
% fprintf(batch,'\n%s','exit 0');
fclose(batch);

elseif VGKset.viscous==1  %viscous


fprintf(batch,'\n%s',['(echo ' name]);
fprintf(batch,'\n%s','echo 1'); %title
fprintf(batch,'\n%s','echo 1'); %0 inviscid, 1 viscous
fprintf(batch,'\n%s','echo 1'); %new run
% fprintf(batch,'\n%s',['echo aero2.dat']); %aerofoil
fprintf(batch,'\n%s',['echo ' name 'aero.dat']); %aerofoil
fprintf(batch,'\n%s\n%s\n%s','echo n','echo n','echo n'); %stop creation of unnecessary files
fprintf(batch,'\n%s',['echo ' num2str(mach)]); %mach
fprintf(batch,'\n%s',['echo ' num2str(aoa)]); %angle of attack
fprintf(batch,'\n%s','echo 0'); 
fprintf(batch,'\n%s',['echo ' num2str(Re)]);
fprintf(batch,'\n%s',['echo ' num2str(VGKset.XTU)]); %upper surface transition point
fprintf(batch,'\n%s',['echo ' num2str(VGKset.XTL)]); %lower surface transition point
fprintf(batch,'\n%s','echo y'); %advanced settings
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.NSurfaceMesh)]); %surface mesh points
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.CoarseIter)]); %coarse iterations
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.FineIter)]); %fin iterations
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.SubRelax)]); %over relaxation parameter
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.SupRelax)]); %under relaxation parameter
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.CMeshRelax)]); %Coarse Mesh relaxation parameter
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.CMeshInvIter)]); %Coarse Mesh BL Solve Ratio
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.FMeshRelax)]); %Fine Mesh relaxation parameter
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.FMeshInvIter)]); %Fine Mesh BL Solve Ratio
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.MomThickXTU)]); %Momentum Thickness at XTU
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.MomThickXTL)]); %Momentum Thickness at XTL
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.ArtVisc)]); %artificial viscosity
fprintf(batch,'\n%s\n%s','echo null',['echo ' num2str(VGKset.PartCons)]); %Partially-Conservative para
fprintf(batch,'%s',') | vgkcon.exe'); %default values
fprintf(batch,'\n%s',['echo ' name ' | vgkv20.exe']);
% fprintf(batch,'\n%s','exit 0');
fclose(batch);

end

cd('VGK')
warning('off','all')
try
delete([name '.FUL'])
catch
end
try
delete([name '.BRF'])
catch
end
warning('on','all')
% status=system('batch.bat &'); %use & to open command window
% status=dos('batch.bat');
batFile = ['batch' name '.bat'];
startInfo = System.Diagnostics.ProcessStartInfo('cmd.exe', sprintf('/c "%s"', batFile));
startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;  %// if you want it invisible
proc = System.Diagnostics.Process.Start(startInfo);
if isempty(proc)
    error('Failed to launch process');
end
cd('..')

end

function [CP,CL,CD,CM]=VGKfin(name,proc)
CP=[]; CD= []; CL= []; CM= [];
name;
proc;
for jj=1:10
    if proc.HasExited
        %fprintf('\nProcess exited with status %d\n', proc.ExitCode);
        break
    end
%     fprintf('.');
    pause(.5);
end
if jj==30
    terminateVGK;
end
proc;
try
% pause(0.5)
filename = ['VGK\' name '.FUL'];
fid = fopen(filename);
failed=0;
% delete(['VGK\' name 'aero.dat'])
Text=textscan(fid,'%s','delimiter','\n');
TextCP=strfind(Text{1},'CP  ');
for ii=1:length(TextCP)
    if isempty(TextCP{ii})==0
        fclose(fid);
        fid = fopen(filename);
        data = textscan(fid,'%f %f %f %f %f %f','headerlines',ii);
        break
    end
    if ii==length(TextCP)
%         disp(' VGK failed');
        failed=1;
    end
end
fclose(fid);
if failed==0
Texttemp=strfind(Text{1},'CM =');
for ii=1:length(Texttemp)
    if isempty(Texttemp{ii})==0
        CL=str2double(Text{1}{ii}(5:14));
        CM=str2double(Text{1}{ii}(Texttemp{ii}+4:end));
        break
    end
end
CDP=str2double(Text{1}{ii+1}(6:14));
if VGKset.viscous==1
    CDF=str2double(Text{1}{ii+1}(23:32));
    CDV=str2double(Text{1}{ii+2}(6:end));
Texttemp=strfind(Text{1},'SUM OF UPPER-SURFACE AND LOWER-SURFACE'); 

    for ii=1:length(Texttemp)
        if isempty(Texttemp{ii})==0
                CDW=str2double(Text{1}{ii+2}(18:end));
                break

        end
    end
    CD=CDP+CDF+CDV+CDW;
else
    CD=CDP;
end
CP=[data{1,2} data{1,4}];

end
catch error
    disp(error)
%     terminateVGK
end
end
%=================================================================
% PLOTTING FUNCTIONS =============================================
function plothandle=plotCP(cp,label)
if isempty(cp)==0
if isempty(h.presfig)==1 || ishandle(h.presfig)==0
        h.presfig=figure('menubar','none',...
        'numbertitle','off',...
        'name','Pressure distribution on aerofoil');
        clf;
        hold on;
        title('Pressure distribution on aerofoil');
        xlabel('x/c');
        ylabel('-Cp');
        h.presaxes=get(get(0,'CurrentFigure'),'CurrentAxes');
        set(h.presaxes, 'Units', 'pixels');
        h.plots=[];
        plotno=0; 
        set(h.presfig,'resizefcn',{@resizeplot, h.presaxes});
        h.listbox=uicontrol('style','list');
        h.deleteplot=uicontrol('string','Delete','callback',...
            @deleteplot);
        h.changename=uicontrol('string','Change Name','callback',...
            @changename);
        PLOTS={};
        plothandle=plot(h.presaxes,cp(:,1),-cp(:,2),'b');
        h.plots(1)=plothandle;
else
    plotno=plotno+1;
    plothandle=plot(h.presaxes,cp(:,1),-cp(:,2));
    h.plots(end+1)=plothandle;
    set(h.plots(end),'color',Col(mod(plotno,7)+1))

end

xlim(h.presaxes,[0,1])
color=get(h.plots(end),'color');
PLOTS=[PLOTS; ['<html><font color="rgb('...
    num2str(color(1)*255) ','...
    num2str(color(2)*255) ','...
    num2str(color(3)*255) ')">' label '</font>']];
set(h.listbox,'string',PLOTS)
else
end
    function deleteplot(varargin) 
        val=get(h.listbox,'value');
        delete(h.plots(val));
        h.plots(val)=[];
        PLOTS(val)=[]; 
        if val>length(PLOTS) && val~=1
            set(h.listbox,'value',length(PLOTS));
        end
        set(h.listbox,'string',PLOTS)
        
    end
    
    function changename(varargin)
        val=get(h.listbox,'value');
        
        prompt = {'New Name'};
        dlg_title = 'Change Name';
        num_lines = 1;
        
        def = {''};

        options.Resize='on';
        options.WindowStyle='normal';

        % Input box
        answer = inputdlg(prompt,dlg_title,num_lines,def,options);
        
        color=get(h.plots(val),'color');
        PLOTS(val)=strcat('<html><font color="rgb(',...
            num2str(color(1)*255), ',',...
            num2str(color(2)*255), ',',...
            num2str(color(3)*255), ')">', answer, '</font>');

        set(h.listbox,'string',PLOTS)
        
    end
end

function resizeplot(varargin)
    fp=get(varargin{1},'Position');
    set(varargin{3},'Position',[60 40 fp(3)-250 fp(4)-70])
    set(h.listbox,'position',[fp(3)-170 40 150 fp(4)-70])
    set(h.deleteplot,'position',[fp(3)-80 20 60 20])
    set(h.changename,'position',[fp(3)-170 20 80 20])
end
% ================================================================
% BASE FUNCTIONS =================================================
function lockaxes(handle)
     xax=get(handle,'xlim');
     yax=get(handle,'ylim');
     axis(handle,[xax(1) xax(2) yax(1) yax(2)]);
end 

function makeborder(handle)
     axis(handle, 'tight');
     xax=get(handle,'xlim');
     yax=get(handle,'ylim');
     bo=max(xax(2)-xax(1),yax(2)-yax(1))/8;
     axis(handle, [xax(1)-bo,xax(2)+bo,yax(1)-bo,yax(2)+bo])
end

function resizefig(varargin)
%      h.axes=gca;
%      h
try
     fp=get(gcf,'Position');
     if fp(3)<800
         set(gcf,'Position',[fp(1:2) 800 fp(4)]);
     end
     fp=get(gcf,'Position');
     if fp(4)<450
         set(gcf,'Position',[fp(1:2) fp(3) 450]);
     end
     fp=get(gcf,'Position');
     set(h.axes,'Position', [30 50 fp(3)-60 fp(4)-115])
     makeborder(h.axes)
     axis(h.axes,'equal');
     lockaxes(h.axes);
     set(h.reset,'Position', [fp(3)-70 10 50 20]);
     set(h.group,'Position', [20 fp(4)-30 100 20]);
     set(h.selectall,'Position', [125 fp(4)-30 80 20]);
     set(h.clrselection,'Position', [210 fp(4)-30 80 20]);
     set(h.rotate,'Position', [295 fp(4)-30 80 20]);
     set(h.showmesh,'Position', [fp(3)-60 fp(4)-30 40 20]);
     set(h.createcut,'Position', [fp(3)-185 fp(4)-30 120 20]);
     set(h.showcmesh,'Position', [fp(3)-235 fp(4)-30 40 20]);
     set(h.createcmesh,'Position', [fp(3)-360 fp(4)-30 120 20]);
     set(h.editDE,'Position',[165 fp(4)-55 140 20]);
     set(h.DVedit,'Position',[20 fp(4)-55 140 20]);
     set(h.addDE,'Position',[310 fp(4)-55 70 20]);
     set(h.removeDE,'Position',[385 fp(4)-55 70 20]);
     set(h.subdivisionDE,'Position',[460 fp(4)-55 70 20]);
     set(h.inversedesign,'Position',[fp(3)-140 fp(4)-55 120 20]);
     set(h.optimise,'Position',[fp(3)-265 fp(4)-55 120 20]);
         
     setcbpos; %run setcbpos
     set(h.refresh,'Position', [fp(3)-125 10 50 20]);
     set(h.plotpres,'Position', [fp(3)-220 10 90 20]);
     set(h.xfoil,'Position', [fp(3)-285 10 60 20]);
     set(h.euler,'Position', [fp(3)-415 10 60 20]);
     set(h.eulers,'Position', [fp(3)-480 10 60 20]);
     set(h.VGK,'Position', [fp(3)-350 10 60 20]);
     set(h.plotpresRe,'Position', [160 10 25 16]);
     set(h.plotpresalpha,'Position', [235 10 35 16]);
     set(h.plotpresReedit,'Position', [190 10 40 20]);
     set(h.plotpresalphaedit,'Position', [275 10 40 20]);
     set(h.plotpresMach,'Position', [75 10 35 16]);
     set(h.plotpresMachedit,'Position', [115 10 40 20]);
end
end

function export_input(varargin)
        prompt={'Data Structure Name'};
    name='Export Data';
   numlines=1;
   defaultanswer={'LOG'};
   options.Resize='on';
   options.WindowStyle='normal';
 
   filename=inputdlg(prompt,name,numlines,defaultanswer,options);
   export(filename{1});
end

function export(filename)
    LOG=[];
    LOG.aerofoil=a;
    LOG.S=S;
    LOG.aerofoil_orig=a_orig;
    LOG.S_orig=S_orig;
    LOG.Tran=H;
    if CMESH==1
    LOG.CMESH=C;
    end
    if CUT_CELL==1
    LOG.CUT_CELL=M;
    end
    LOG.DV=DV;
    if isempty(OPTLOG)==0
    LOG.OPTLOG=OPTLOG;
    end
    assignin('base', filename, LOG)
end

function importS(filename)
s=evalin('base',filename);
for m=1:length(s(:,1))
setPosition(P{m},s(m,:));
% s(m,:)
% getPosition(P{m})
end
delete(R)
setpoints; 
setcbpos;
end

function importDV(filename)
DV=evalin('base',filename);
end
%=================================================================
resizefig;
export('logfile')
% importS('S_30it')
for scno=1:length(script)
eval(script{scno})
end
end

%non-nested functions
function A=calcarea(aerofoil)
%using greens theorm to calculate the area of the aerofoil
minval=min(aerofoil);
aerofoil=aerofoil+ones(size(aerofoil))*abs(minval(1,2)); %translate above x-axis
A=0;
    for i=1:length(aerofoil)
        x1=aerofoil(i,1);
        y1=aerofoil(i,2);
        if i~=length(aerofoil)
            x2=aerofoil(i+1,1);
            y2=aerofoil(i+1,2);
        else
            x2=aerofoil(1,1);
            y2=aerofoil(1,2);
        end
        if x1 ~= x2 %stop m=inf
        m=(y2-y1)/(x2-x1); c=y1-m*x1;
        A=A + ((m*x2^2)/2 +c*x2)-((m*x1^2)/2 +c*x1);
        end
    end  
    A=abs(A);
end

function [isaero,aerofoil]=checkaerofoil(aerofoil)
l_old=1; k=0; %l=1 means x decreaseing l=2 means increasing; k=change count
isaero=1;
    for i=2:length(aerofoil(:,1))
        if aerofoil(i,1)<aerofoil(i-1,1)
            l=1;
        elseif aerofoil(i,1)>=aerofoil(i-1,1)
            l=2;
        end
        if l~=l_old
            k=k+1;
            n=i-1;
        end
        if k>=2
            isaero=0;
            break
        end
        l_old=l;
    end
    lowermean=mean(aerofoil(1:n,2));
    uppermean=mean(aerofoil(n:length(aerofoil(:,1)),2));
    if lowermean>uppermean
        aerofoil=aerofoil(length(aerofoil(:,1)):-1:1,:); %flip aerofoil
    end
end

function Aas=setAas(S,a)
Ls=length(S(:,1));
La=length(a(:,1));
Aas=zeros(La,Ls+3);
Ax=zeros(La,Ls);
Ay=zeros(La,Ls);
Sx=zeros(La,Ls);
Sy=zeros(La,Ls);
Aas(:,1)=ones(La,1);
Aas(:,2:3)=a;
Ax=a(:,1)*ones(1,Ls);
Ay=a(:,2)*ones(1,Ls);
Sx=ones(La,1)*S(:,1)';
Sy=ones(La,1)*S(:,2)';
Aas(1:La,4:Ls+3)=phi(sqrt((Ax-Sx).^2+(Ay-Sy).^2));
end

function Css=setCss(S)
Ls=length(S(:,1));
Css=zeros(Ls+3,Ls+3);
Sx=zeros(Ls,Ls);
Sy=zeros(Ls,Ls);
Css(4:Ls+3,1)=ones(Ls,1);
Css(1,4:Ls+3)=ones(1,Ls);
Css(4:Ls+3,2:3)=S;
Css(2:3,4:Ls+3)=S';
Sx=ones(Ls,1)*S(:,1)';
Sy=ones(Ls,1)*S(:,2)';
Css(4:Ls+3,4:Ls+3)=phi(sqrt((Sx-Sx').^2+(Sy-Sy').^2));
end

function PHI=phi(r)
SR=1;
r=r./SR;
% PHI=(ones(size(r))-r).^2;
PHI=((ones(size(r))-r).^4).*((4.*r)+ones(size(r))); %C2
PHI=PHI.*(r<1);
%  PHI=((1-r))^2;
% PHI=(1-r)^4*(4*r+1);
end

function M=importmesh()
temp=importdata('euler\griduns',' ');
M.totcells=temp(1,1);
M.totedges=temp(1,2);
M.totvertices=temp(1,3);
temp=importdata('euler\griduns',' ',1);
A=1;
b=M.totedges;
M.edgedata=temp.data(A:b,1:4);
A=A+M.totedges;
b=b+M.totvertices;
M.vertexdata=temp.data(A:b,1:3);
offset=3.131592653589793E-003;
M.vertexdata(:,2:3)=M.vertexdata(:,2:3)-(offset.*ones(size(M.vertexdata(:,2:3))));
A=A+M.totvertices;
b=b+M.totcells;
M.celldata=temp.data(A:b,1);
M.colour=[zeros(M.totvertices,1),ones(M.totvertices,1),zeros(M.totvertices,1)];
end

function C=importcmesh()
    temp=importdata('CBACODES/RBF.cba',' ');
    s=3;
    C.n(1)=temp(2,1)*temp(2,2);
    C.size(1,:)=[temp(2,1) temp(2,2)];
    C.block{1}=temp(s:C.n(1)+s-1,:);
    s=C.n(1)+s+7;
    C.n(2)=temp(s-1,1)*temp(s-1,2);
    C.size(2,:)=[temp(s-1,1) temp(s-1,2)];
    C.block{2}=temp(s:C.n(2)+s-1,:);
    s=C.n(2)+s+7;
    C.n(3)=temp(s-1,1)*temp(s-1,2);
    C.size(3,:)=[temp(s-1,1) temp(s-1,2)];
    C.block{3}=temp(s:C.n(3)+s-1,:);
end

function a=checkboundary(a)
    [mina,inda]=min(a(:,1));
    m1=mean(a(1:inda,2));
    m2=mean(a(inda:end,2));
%     if mina==0
% %         a=[a(1:inda-1,:);a(inda+1:end,:)];
%         a(:,1)=a(:,1)+0.001;
%         a(:,2)=a(:,2)-0.001;
%     end
    if m2>m1
        a=flipud(a);
    end
    tdiff=a(1,2)-a(end,2);
    if tdiff<1e-5
        tadd=1e-5-tdiff;
        a(1:inda-1,2)=a(1:inda-1,2)+a(1:inda-1,1)*tadd;
        a(inda:end,2)=a(inda:end,2)-a(inda:end,1)*tadd;
    end
end

function writeboundary(a)
boundary=fopen('euler\boundary.dat','wt+');
    %write header line
    fprintf(boundary,'%i',1);
    %write boundary length
    fprintf(boundary,'\n%i   %i\n%i',length(a(:,1)),length(a(:,1)),length(a(:,1)));
    %write boundary data
    fprintf(boundary,'\n%f\t%f',a');
    fclose(boundary);    
end

function writemesh(M)
griduns=fopen('euler\griduns','wt+');
    %write header line
    fprintf(griduns,'%12i%12i%12i',M.totcells,M.totedges,M.totvertices);
    %write edgedata
    fprintf(griduns,'\n%12i%12i%12i%12i',M.edgedata');
    %write vertex data
%     vertextemp=M.vertexdata;
%     offset=3.131592653589793E-003*ones(size(vertextemp(2:3)));
%     vertextemp(2:3)=vertextemp(2:3)-offset;
    fprintf(griduns,'\n%12i\t%5.12e\t%5.12e',M.vertexdata');
    %write vertex data
    fprintf(griduns,'\n%3.14e',M.celldata');
    fclose(griduns);
end

function writecmesh(C)
    A = regexp( fileread('CBACODES/RBF.cba'), '\n', 'split');
    cmesh=fopen('CBACODES/RBF.cba','w+');
    s=3;
    fprintf(cmesh,'%s\n',A{1:2});
    fprintf(cmesh,'\t%4.16f\t\t%4.16f\t\t%4.16f\n',C.block{1,1}');
    s=s+C.n(1);
    fprintf(cmesh,'%s\n',A{s:s+6});
    fprintf(cmesh,'\t%4.16f\t\t%4.16f\t\t%4.16f\n',C.block{1,2}');
    s=s+7+C.n(2);
    fprintf(cmesh,'%s\n',A{s:s+6});
    fprintf(cmesh,'\t%4.16f\t\t%4.16f\t\t%4.16f\n',C.block{1,3}');
    s=s+7+C.n(3);
    fprintf(cmesh,'%s\n',A{s:s+6});
    fclose(cmesh);
end

function [sym,Pairs]=checksymmetry(S)
sym=0;
Pairs=[];
L=length(S(:,1));
S=1e4.*S;
S=round(S);
S=S./1e4;
S=[S'; 1:L];
S=S';
S=sortrows(S,2);
if mod(length(S(:,1)),2)==0
    S(1:L/2,:)=sortrows(S(1:L/2,:),1);
    S(1:L/2,:)=sortrows(S(1:L/2,:),2);
    S(L/2+1:L,:)=flipud(sortrows(S(L/2+1:L,:),1));
    S(L/2+1:L,:)=sortrows(S(L/2+1:L,:),2);
    if isequal(S(1:L/2,1),flipud(S(L/2+1:L,1)))==1 && ...
        isequal(flipud(S(1:L/2,2)),-S(L/2+1:L,2))==1;
        sym=1;
        Pairs= [S(1:L/2,3) flipud(S(L/2+1:L,3))];
    end
else
    S(1:(L-1)/2,:)=sortrows(S(1:(L-1)/2,:),1);
    S(1:(L-1)/2,:)=sortrows(S(1:(L-1)/2,:),2);
    S((L+1)/2+1:L,:)=flipud(sortrows(S((L+1)/2+1:L,:),1));
    S((L+1)/2+1:L,:)=sortrows(S((L+1)/2+1:L,:),2);
    if isequal(S(1:(L-1)/2,1),flipud(S((L+1)/2+1:L,1)))==1 && ...
        isequal(flipud(S(1:(L-1)/2,2)),-S((L+1)/2+1:L,2))==1 && ...
        S((L+1)/2,2)==0;
        sym=1;
        Pairs=[S(1:(L-1)/2,3) flipud(S((L+1)/2+1:L,3))];
    end
end
end

function varargout = isprocess(pname)
%ISPROCESS checks if the input process name is running on the system
%The function returns True/False (0/1) along with the number of instances of the
%process and the process ID (PID) numbers.
%
% Syntax/Usage:  [result] = isprocess('fire*')
%                [result pid_total] = isprocess('firefox')
%                [result pid_total pid_nums] = isprocess('firefox')
%
% See also endtask

% Distribution Version 2.0
% Written by Varun Gandhi 13-May-2009

if ispc
    if (strcmp(pname(end),'*'))
    pname=pname(1:(end-1));
    end
    str=sprintf('tasklist /SVC /NH /FI "IMAGENAME eq %s*"',pname);
    [sys_status,sys_out] = system(str);
    if (sys_status == 0)
        [matches, start_idx, end_idx, extents, tokens, names, splits] = regexp(sys_out,pname,'ignorecase', 'match');
    else
        disp(sys_out);
        error('Unable to access system processes');
        
    end
    
    
    
    if (numel(matches) == 0)
        
        varargout{1} = false;
        varargout{2}=0;
        varargout{3}='No Matching Process-IDs';
    else
        
        for i=1:numel(matches)
            match_pid(i) = regexp(splits(i+1), '\d+', 'match', 'once');
            pid_nums{i}=str2double(match_pid{i});
            varargout{1}=true;
        end
        varargout{2}=numel(matches);
        varargout{3}=pid_nums;
    end
    
end

if isunix
    [sys_status , sys_out] = system('ps -A -o cmd');
    expr = ['\w*' pname '\w*'];
    if (sys_status == 0)
        matches = regexp(sys_out,expr,'ignorecase', 'match');
    else
        disp(sys_out);
        error('Unable to access system processes');
    end
    
    if (numel(matches) == 0)
        varargout{1} = false;
        varargout{2}=0;
        varargout{3}='No Matching Process-IDs';
    else
        
        pgrep_cmd = ['pgrep ' matches{1}];
        [sys_status , sys_out] = system(pgrep_cmd);
        pid_nums =regexp(sys_out,'\d+','ignorecase', 'match');
        varargout{1}=true;
        varargout{2}=numel(pid_nums);
        varargout{3}=pid_nums;
    end
    
end
end

function [meanerror,toterror,C]=aeroerror(orig,approx,plotfigures)
if nargin==2
    plotfigures=0;
end
% tic
% [dum_var,C.input]=checkaerofoil(orig); 
% [dum_var,C.target]=checkaerofoil(approx);
C.input=orig;
C.target=approx;
% if length(C.target)<length(C.input) %ensure shortest aero is "input"
%     temp=C.target;
%     C.target=C.input;
%     C.input=temp;
% end
k=1;
C.input(:,2)=C.input(:,2)+2;
C.target(:,2)=C.target(:,2)+2;
[dum_var,C.mini]=min(C.input(:,1));
[dum_var,C.minj]=min(C.target(:,1));
C.intersections=[];

for i=1:length(C.input(:,1))-1
    for j=1:length(C.target(:,1))-1
%         if (C.target(j,1)<C.input(i,1)   && C.target(j,1)>C.input(i+1,1)   && i<=(1.5*C.mini) && j<(1.5*C.minj)) ||...
%            (C.target(j+1,1)<C.input(i,1) && C.target(j+1,1)>C.input(i+1,1) && i<=(1.5*C.mini) && j<(1.5*C.minj)) ||...
%            (C.target(j,1)>C.input(i,1)   && C.target(j,1)<C.input(i+1,1)   && i>=(0.5*C.mini) && j>(0.5*C.minj)) ||...
%            (C.target(j+1,1)>C.input(i,1) && C.target(j+1,1)<C.input(i+1,1) && i>=(0.5*C.mini) && j>(0.5*C.minj))
% plot(C.input(i:i+1,1),C.input(i:i+1,2),'m')
% plot(C.target(i:i+1,1),C.target(i:i+1,2),'g')
% [C.input(i,:) C.input(i+1,:)]
% [C.target(j,:) C.target(j+1,:)]
            if (i<=(1.5*C.mini) && j<(1.5*C.minj) ||...
                    i<=(1.5*C.mini) && j<(1.5*C.minj) ||...
                    i>=(0.5*C.mini) && j>(0.5*C.minj) ||...
                    i>=(0.5*C.mini) && j>(0.5*C.minj))
           [x y]=lineintersect([C.input(i,:) C.input(i+1,:)],[C.target(j,:) C.target(j+1,:)]); 
           if isnan(x)==0
                C.intersections(k,:)=[x,y];
                C.intindex(k,:)=[i,j];
                k=k+1;
           end
            end
%         end
    end
end

% C.intersections=unique(C.intersections,'rows','stable');
if plotfigures==1
figure;
plot(C.input(:,1),C.input(:,2),'b-')
hold on
plot(C.target(:,1),C.target(:,2),'r-')
plot(C.intersections(:,1),C.intersections(:,2),'og')
end
%     C.inputwint=zeros(length(C.input(:,1)),3);
%     C.targetwint=zeros(length(C.target(:,1)),3);
C.inputwint=C.input;
C.targetwint=C.target;
C.inputwint(1,3)=1;
C.targetwint(1,3)=1;
C.inputwint(end,3)=1;
C.targetwint(end,3)=1;
K=1;
if isempty(C.intersections)==0
intlength=length(C.intersections(:,1));
else
intlength=0;
end
for i=1:intlength
    line=C.intindex(i,1)+K;
    C.inputwint=[C.inputwint(1:line-1,:);
        C.intersections(i,:),1;
        C.inputwint(line:end,:)];
    K=K+1;
end
K=1;
for i=1:intlength
    line=C.intindex(i,2)+K;
    C.targetwint=[C.targetwint(1:line-1,:);
        C.intersections(i,:),1;
        C.targetwint(line:end,:)];
    K=K+1;
end

% if isequal(C.intersections(1,:),[1,1])==0
% C.inputwint=[C.inputwint;
%     C.input(1:C.intindex(1,1),:),zeros(length(1:C.intindex(1,1)),1);
%     C.intersections(1,:),1];
% C.targetwint=[C.targetwint;
%     C.target(1:C.intindex(1,2),:),zeros(length(1:C.intindex(1,2)),1);
%     C.intersections(1,:),1];
% % end
% C.inputwint(1,3)=1;
% C.targetwint(1,3)=1;
% for i=2:length(C.intindex(:,1))
%     C.inputwint=[C.inputwint;
%     C.input(C.intindex(i-1,1)+1:C.intindex(i,1),:),zeros(length(C.intindex(i-1,1)+1:C.intindex(i,1)),1);
%     C.intersections(i,:),1];
% C.targetwint=[C.targetwint;
%     C.target(C.intindex(i-1,2)+1:C.intindex(i,2),:),zeros(length(C.intindex(i-1,2)+1:C.intindex(i,2)),1);
%     C.intersections(i,:),1];
% end
% C.inputwint=[C.inputwint;
%     C.input(C.intindex(end,1)+1:end,:),zeros(length(C.input(C.intindex(i,1)+1:end,1)),1);
%     C.input(end,:),1];
% C.targetwint=[C.targetwint;
%     C.target(C.intindex(end,2)+1:end,:),zeros(length(C.target(C.intindex(i,2)+1:end,1)),1);
%     C.target(end,:),1];
instart=1;
tastart=1;
L=1;
C.toterror=0;

for l=1:intlength+1
    for i=instart+1:length(C.inputwint(:,1))
        if C.inputwint(i,3)==1
            infinish=i;
            C.Loop{L}=C.inputwint(instart:infinish,1:2);
            instart=infinish;
            break
        end
    end
    for i=tastart+1:length(C.targetwint(:,1))
        if C.targetwint(i,3)==1
            tafinish=i;
            C.Loop{L}=[C.Loop{L}; C.targetwint(tafinish:-1:tastart,1:2)];
            C.Loop{L}=unique(C.Loop{L},'rows','stable');
            C.Loop{L}=[C.Loop{L}; C.Loop{L}(1,:)];
            tastart=tafinish;
            C.error{L}=area(C.Loop{L});
            C.toterror=C.toterror+C.error{L};
            L=L+1;
            break
        end
    end
end

toterror = C.toterror;
C.arc = arclength(orig);
C.apparc= arclength(approx);
C.meanerror = (2*C.toterror)/(C.arc+C.apparc);
meanerror=C.meanerror;
% toc
end

function A=arclength(aero)
A=0;
for i=1:length(aero(:,1))-1
A=A+norm((aero(i,:)-aero(i+1,:)),2);
end
end

function A=area(B)
%using greens theorm to calculate the area of the aerofoil
% minval=min(B);
% B=B+ones(size(B))*abs(minval(1,2)); %translate above x-axis
A=0;
    for i=1:length(B(:,1))
        x1=B(i,1);
        y1=B(i,2);
        if i~=length(B(:,1))
            x2=B(i+1,1);
            y2=B(i+1,2);
        else
            x2=B(1,1);
            y2=B(1,2);
        end
        if x1 ~= x2 %stop m=inf
        m=(y2-y1)/(x2-x1); c=y1-m*x1;
        A=A + ((m*x2^2)/2 +c*x2)-((m*x1^2)/2 +c*x1);
        end
    end  
    A=abs(A);
end

function [x,y]=lineintersect(l1,l2)
%This function finds where two lines (2D) intersect
%Each line must be defined in a vector by two points
%[P1X P1Y P2X P2Y], you must provide two has arguments
%Example:
%l1=[93 388 120 354];
%l2=[102 355 124 377];
%[x,y]=lineintersect(l1,l2);
%You can draw the lines to confirm if the solution is correct
%figure
%clf
%hold on
% line([l1(1) l1(3)],[l1(2) l1(4)])
% line([l2(1) l2(3)],[l2(2) l2(4)])
% plot(x,y,'ro') %this will mark the intersection point
%
%There is also included in another m file the Testlineintersect
%That m file can be used to input the two lines interactively
%
%Made by Paulo Silva
%22-02-2011

%default values for x and y, in case of error these are the outputs
x=nan;
y=nan;

ml1=(l1(4)-l1(2))/(l1(3)-l1(1));
ml2=(l2(4)-l2(2))/(l2(3)-l2(1));
bl1=l1(2)-ml1*l1(1);
bl2=l2(2)-ml2*l2(1);
b=[bl1 bl2]';
a=[1 -ml1; 1 -ml2];
Pint=a\b;

%when the lines are paralel there's x or y will be Inf
if (any(Pint==Inf))
disp('No solution found, probably the lines are paralel')
return
end

%put the solution inside x and y
x=Pint(2);
y=Pint(1);

%find maximum and minimum values for the final test

l1minX=min([l1(1) l1(3)]);
l2minX=min([l2(1) l2(3)]);
l1minY=min([l1(2) l1(4)]);
l2minY=min([l2(2) l2(4)]);

l1maxX=max([l1(1) l1(3)]);
l2maxX=max([l2(1) l2(3)]);
l1maxY=max([l1(2) l1(4)]);
l2maxY=max([l2(2) l2(4)]);

% x<l1minX
% x>l1maxX
% y<l1minY
% y>l1maxY
% x<l2minX
% x>l2maxX
% y<l2minY
% y>l2maxY

%Test if the intersection is a point from the two lines because 
%all the performed calculations where for infinite lines 
if ((x<l1minX) | (x>l1maxX) | (y<l1minY) | (y>l1maxY) |...
       (x<l2minX) | (x>l2maxX) | (y<l2minY) | (y>l2maxY) )
x=NaN;
y=NaN;
% disp('There''s no intersection between the two lines')
return
end
end

function [target,tran]=normtargetLE(target,LE)
% figure; plot(target(:,1),target(:,2));hold on
% target=target';
target(:,3)=ones(size(target(:,1)));
orig=target;
% translate le to 0,0 =================

    tran1=[1 0 -LE(1);
            0 1 -LE(2);
            0 0 1]';
        target=target*tran1;
% ====================================
% rotate tail to align with x-axis =====
thetatail=atan(target(end,2)/target(end,1));
        if target(end,1)<0
            thetatail = thetatail + pi;
        end
    tran2=[cos(thetatail) sin(thetatail) 0;
            -sin(thetatail) cos(thetatail) 0;
            0 0 1]';
    target=target*tran2;
% % ====================================
% scale to unit chord ===============
scalefactor=1/target(end,1);
    tran3=[scalefactor 0 0;
            0 scalefactor 0;
            0 0 1]';
    target=target*tran3;
% ===================================
    tran=tran1*tran2*tran3;
    target=target(:,1:2);
%     figure
%     plot(target(:,1),target(:,2),'r');
%     hold on
%     plot(orig(:,1),orig(:,2),'g');
end

function aero=translateaero(aero,tran)
aero=[aero ones(size(aero(:,1)))]*tran;
aero=aero(:,1:2);
end

function [output,T]=subdivision(input,N,closed)
n=length(input(:,1));
if nargin==2
closed=0;
end
T=eye(length(input(:,1)));
for j=1:N
    k=1;
    P=zeros(2*n-2,n);
    for i=1:n-1
        P(k,i:i+1)=[0.75 0.25];
        P(k+1,i:i+1)=[0.25 0.75];
        k=k+2;
    end
    if closed==1
        P(k,end)=0.75;
        P(k,1)=0.25;
        P(k+1,end)=0.25;
        P(k+1,1)=0.75;
        k=k+2;
    else
        P(1,1:2)=[0.625 0.375];
        P(end,end-1:end)=[0.375 0.625];
        P=[1 zeros(1,length(P(1,:))-1);
            P; zeros(1,length(P(1,:))-1) 1];
    end
n=length(P(:,1));
size(P);
T=P*T;
end
output=T*input;
% figure;
% plot(input(:,1),input(:,2),'x-')
% hold on
% plot(output(:,1),output(:,2),'rx-')
end

function aero=translate(aero,tran)
aero=[aero ones(size(aero(:,1)))]*tran;
aero=aero(:,1:2);
end

function [target,tran]=normtarget(target)
% figure; plot(target(:,1),target(:,2));hold on
% target=target';
target(:,3)=ones(size(target(:,1)));
orig=target;
% translate le to 0,0 =================
taildiff=target-(ones(size(target(:,1)))*target(1,:));
for i=1:length(target(:,1))
taildist(i)=norm(taildiff(i,1:2));
end
    [dum_var, mint]=max(taildist);
    tran1=[1 0 -target(mint,1);
            0 1 -target(mint,2);
            0 0 1]';
        target=target*tran1;
% ====================================
% rotate tail to align with x-axis =====
thetatail=atan(target(end,2)/target(end,1));
        if target(end,1)<0
            thetatail = thetatail + pi;
        end
    tran2=[cos(thetatail) sin(thetatail) 0;
            -sin(thetatail) cos(thetatail) 0;
            0 0 1]';
    target=target*tran2;
% % ====================================
% scale to unit chord ===============
scalefactor=1/(max(target(:,1))-min(target(:,1)));
    tran3=[scalefactor 0 0;
            0 scalefactor 0;
            0 0 1]';
    target=target*tran3;
% ===================================
    tran=tran1*tran2*tran3;
    target=target(:,1:2);
%     orig=orig*tran;
%     target=target';
%     plot(target(:,1),target(:,2),'r');
%     plot(orig(:,1),orig(:,2),'g');
end

function [Y,sp,X2]=splineaeroX(aero,X,smoothing)
if nargin==2
    smoothing=0;
end
% tic
[dum_var,aero]=checkaerofoil(aero);

% xx=arclength(aero);
xx=aero(1:end-1,:)-aero(2:end,:);
xx=sqrt(xx(:,1).^2+xx(:,2).^2);
xx=[0;xx];
xx=xx.^(1/2); %centrepedial
% D=(aero(:,1).*(D/max(D)))+((aero(:,1)-1).*(D1/max(D1)));
xx=cumsum(xx);
xx=2*xx/xx(end);
xx=xx-1;
xx;
if smoothing==0
sp=spline(xx,aero');
p=1;
elseif smoothing==1
p=[];
[dum_var,minaero]=min(aero(:,1));
w=ones(size(xx));
w([1,minaero,end])=1e12;
[sp,p]=csaps(xx,aero',p, [], w);
end

% Y=ppval(sp,xx)';
% figure;
% plot(aero(:,1),aero(:,2))
% hold on
% plot(Y(:,1),Y(:,2),'r')

taildiff=aero-(ones(size(aero(:,1)))*aero(end,:));
taildist=sqrt(taildiff(:,1).^2+taildiff(:,2).^2);
[dum_var, le_approx]=max(taildist);
DIST=1;
while DIST>1e-8
    xx=linspace(xx(le_approx-3),xx(le_approx+3),51);
    Y=ppval(sp,xx)';
%     plot(Y(:,1),Y(:,2),'g')
    taildiff=Y-(ones(size(Y(:,1)))*aero(end,:));
    taildist=sqrt(taildiff(:,1).^2+taildiff(:,2).^2);
    [dum_var, le_approx]=max(taildist);
    Y2=ppval(sp,[xx(le_approx-1),xx(le_approx+1)])';
    DIST=norm(Y2(1,:)-Y2(2,:));
end
XLE=xx(le_approx);
LE=ppval(sp,XLE);
[aero,tran]=normtargetLE(aero,LE);
% 
% 
% [dum_var,tran]=normtarget(denseaero);
% denseaero=translate(denseaero,tran);
if length(X)==1
l=X;
X=linspace(-pi,pi,X)';
X=(1-cos(X))./2;
X(1:floor(l/2))=-X(1:floor(l/2));
Xmid=ceil(length(X)/2);
else
    if min(X)<-0.1
    else
        [dum_var,Xmid]=min(X);
        X(1:Xmid)=-X(1:Xmid);
    end
end

SX=sign(X);
SX(Xmid)=1;
SX=[SX(1); SX; SX(end)];

[dum_var,minind]=min(abs(X));

X1=X;
X1(1:minind)=X1(1:minind)*(1+XLE);
X1(minind:end)=X1(minind:end)*(1-XLE);
X1=X1+XLE;

X1=[X1(1)-1e-3; X1; X1(end)+1e-3];
Y=translate(ppval(sp,X1)',tran);

Yguess=Y;
%search for correct X positions
low=1; high=2;
B=zeros(length(X),3);
for i=1:length(X)

while SX(high)*Y(high,1)<=X(i)
    low=low+1;
    high=high+1;
    if high>length(SX)
        high=high-1;
        break
    end
end

B(i,1)=X1(low);
B(i,3)=X1(high);
B(i,2)=(B(i,1)+B(i,3))/2;
end
B(Xmid,:)=XLE;
% B(1,:)=-1;
% B(end,:)=1;
SX=SX(2:end-1);
T=(1:length(X))';
Ytemp=translate(ppval(sp,B(:,2))',tran);
lx=length(X);
LE=find(T==Xmid);
Ytemp(LE,1)=Ytemp(LE,1)*sign(Ytemp(LE,2));
Ytemp=SX.*Ytemp(:,1);

k=1;
tol=1e-10;

while ~isempty(Ytemp)
% for j=1:12
C=Ytemp-X(T);
H=find(C>0);
L=find(C<0);
B(T(H),3)=B(T(H),2);
B(T(L),1)=B(T(L),2);
B(T,2)=(B(T,1)+B(T,3))/2;

Ytemp=translate(ppval(sp,B(T,2))',tran);
% Ytemp=translate(ppval(sp,B(:,2))',tran);


LE=find(T==Xmid);
if ~isempty(LE)
Ytemp(LE,1)=Ytemp(LE,1)*sign(Ytemp(LE,2));
end
Ytemp=SX(T).*Ytemp(:,1);

d=abs(Ytemp-X(T));
T=T(find(d>tol));
if k>400
    d(find(T==1))=d(find(T==1))/100;
    d(find(T==lx))=d(find(T==lx))/100;
    if k>600
    d(find(T==1))=d(find(T==1))/100;
    d(find(T==lx))=d(find(T==lx))/100;
    if k>800
    d(find(T==1))=d(find(T==1))/100;
    d(find(T==lx))=d(find(T==lx))/100;
    end
    end
end
Ytemp=Ytemp(find(d>tol));
k=k+1;



if k==1000
    i;
    k;
    d;
    X(T);
    T;
    Ytemp;
    fprintf('Spline Failed: d=%g, X(T)=%g, T=%g, Ytemp=%g\n',d,X(T),T, Ytemp);
%     disp('spline failed')
%     fail
    break
end
end
k;
X2=B(:,2);
Y=translate(ppval(sp,X2)',tran);
[dum_var,minY]=min(Y(:,1));
Y(minY,:)=0;
X2=X2';
% figure; plot(Y(:,1),Y(:,2),'bx-');
% hold on; plot(aero(:,1),aero(:,2),'r-x');
% toc;
end



