function clearXFOIL(varargin)
%clear XFOIL files
%
%clear surplus XFOIL files from root ADAPT folder. Files are usually
%created when a hard stop (ctrl+c) is performed in ADAPT while an XFOIL
%process is being run.


L=dir;
for i=1:length(L)
    name=L(i).name;
    if length(name)>9
    if strcmp(name(1:5),'Polar') && strcmp(name(end-3:end),'.txt')
        delete(name)
    end
    end
    if length(name)>11
    if strcmp(name(1:7),'actions') && strcmp(name(end-3:end),'.txt')
        delete(name)
    end
    end
    if length(name)>12
    if strcmp(name(1:8),'Pressure') && strcmp(name(end-3:end),'.txt')
        delete(name)
    end
    end
    if length(name)==42
    if strcmp(name(1:2),'tp') && strcmp(name(end-3:end),'.dat')
        delete(name)
    end
    end
end