function [Aerofoil,tran]=NACA4(m,p,t,X)
if length(X)==1
    X=linspace(-pi,pi,X);
    X=(1-cos(X))./2;
    X(floor(length(X)/2)+1:end)=-X(floor(length(X)/2)+1:end);
    X;
elseif min(X)>=0
    [~,minind]=min(X);
    X(minind:end)=-X(minind:end);
    if length(X(:,1))>1
        X=X';
    end
        
end
      m=m/100;
        p=p/10;
        t=t/100;
        d=[0.2969; -0.1260;
            -0.3516; 0.2843;
            -0.1036];
        c=1;
        if m==0 && p==0
             XU=X(X>=0);
            XL=-X(X<0);
            YU=yt(XU);
            YL=-yt(XL);
            Aerofoil=[XU',YU';
                XL',YL'];
            Aerofoil=flipud(Aerofoil);
%             Aerofoil=[Aerofoil(1:n,:);
%                 Aerofoil(n+2:end,:)];
        else
            %=======find leading edge=============
%             defined as furthest point from trailing edge
            x=[0,0.025,0.05,0.075,0.1];
            count=0;
            while abs(x(1)-x(5))>1e-8
                z=sqrt((xu(x)-1).^2+yu(x).^2);
                if z(2)>z(4)
                    x=[x(1),(x(1)+x(2))/2,x(2),(x(2)+x(3))/2,x(3)];
                elseif z(4)>=z(2)
                    x=[x(3),(x(3)+x(4))/2,x(4),(x(4)+x(5))/2,x(5)];
                end
                count=count+1;
                if count>2000
                    disp('did not converge to leading edge')
                    break
                end
            end
            [~,ind]=max(z);
            xle=x(ind);
            xleco=[xu(xle) yu(xle)];
            %======calcualte transformation matrix===========
            tran1=[1 0 -xleco(1);
                    0 1 -xleco(2);
                    0 0 1]';
            thetatail=atan(-xleco(2)/(1-xleco(1)));
%             if xleco(2)>0
%             thetatail = thetatail + pi;
%             end
            tran2=[cos(thetatail) sin(thetatail) 0;
                    -sin(thetatail) cos(thetatail) 0;
                    0 0 1]';
            scalefactor=1/norm(xleco-[1 0]);    
            tran3=[scalefactor 0 0;
                    0 scalefactor 0;
                    0 0 1]';
            tran=tran1*tran2*tran3;  
            p_zero=translate([0 0],tran);
            X1=X(X>=0);
            X2=X(X>-p_zero(1));
            X2=X2(X2<0);
            X2=-X2;
            X3=X(X<=-p_zero(1));
            X3=-X3;
            %find xpoints 1
            x_guess=linspace(1,xle,1000);
            Y=translate(upper(x_guess),tran);
            low=1; high=2;
            B1=zeros(length(X1),3);
            for i=1:length(X1)
            while Y(high,1)>=X1(i)
                low=low+1;
                high=high+1;
                if high>length(x_guess)
                    high=high-1;
                    break
                end
            end
            B1(i,1)=x_guess(low);
            B1(i,3)=x_guess(high);
            B1(i,2)=(B1(i,1)+B1(i,3))/2;
            end
            tol=1e-15;
            T=(1:length(X1));
            Ytemp=translate(upper(B1(:,2)'),tran);
            while ~isempty(T)
            C=Ytemp(T,1)-X1(T)';
            H=find(C<0);
            L=find(C>0);
            B1(T(H),3)=B1(T(H),2);
            B1(T(L),1)=B1(T(L),2);
            B1(T,2)=(B1(T,1)+B1(T,3))/2;
            Ytemp=translate(upper(B1(:,2)'),tran);
            err=abs(Ytemp(T,1)-X1(T)');
            T=T(find(err>tol));
            end
            Ytemp1=Ytemp;
            
            %find xpoints 2
            if ~isempty(X2)
            x_guess=linspace(xle,0,10);
            Y=translate(upper(x_guess),tran);
            low=1; high=2;
            B2=zeros(length(X2),3);
            for i=1:length(X2)
            while Y(high,1)<=X2(i)
                low=low+1;
                high=high+1;
                if high>length(x_guess)
                    high=high-1;
                    break
                end
            end
            B2(i,1)=x_guess(low);
            B2(i,3)=x_guess(high);
            B2(i,2)=(B2(i,1)+B2(i,3))/2;
            end
            T=(1:length(X2));
            Ytemp=translate(upper(B2(:,2)'),tran);
            while ~isempty(T)
            C=Ytemp(T,1)-X2(T)';
            H=find(C>0);
            L=find(C<0);
            B2(T(H),3)=B2(T(H),2);
            B2(T(L),1)=B2(T(L),2);
            B2(T,2)=(B2(T,1)+B2(T,3))/2;
            Ytemp=translate(upper(B2(:,2)'),tran);
            err=abs(Ytemp(T,1)-X2(T)');
            T=T(find(err>tol));
            end
            Ytemp2=Ytemp;
            else
                Ytemp2=[];
            end
            %find xpoints 3
            x_guess=linspace(0,1,1000);
            Y=translate(lower(x_guess),tran);
            low=1; high=2;
            B3=zeros(length(X3),3);
            for i=1:length(X3)
            while Y(high,1)<=X3(i)
                low=low+1;
                high=high+1;
                if high>length(x_guess)
                    high=high-1;
                    break
                end
            end
            B3(i,1)=x_guess(low);
            B3(i,3)=x_guess(high);
            B3(i,2)=(B3(i,1)+B3(i,3))/2;
            end
            T=(1:length(X3));
            Ytemp=translate(lower(B3(:,2)'),tran);
            while ~isempty(T)
            C=Ytemp(T,1)-X3(T)';
            H=find(C>0);
            L=find(C<0);
            B3(T(H),3)=B3(T(H),2);
            B3(T(L),1)=B3(T(L),2);
            B3(T,2)=(B3(T,1)+B3(T,3))/2;
            Ytemp=translate(lower(B3(:,2)'),tran);
            err=abs(Ytemp(T,1)-X3(T)');
            T=T(find(err>tol));
            end
            Ytemp3=Ytemp;
            Aerofoil=[Ytemp1;Ytemp2;Ytemp3];
            Aerofoil=flipud(Aerofoil);
        end
%         figure;
%         plot(Aerofoil(:,1),Aerofoil(:,2),'b-x')
        function aero=translate(aero,tran)
        aero=[aero ones(size(aero(:,1)))]*tran;
        aero=aero(:,1:2);
        end
        function Y=upper(x)
            Y(:,1)=x-yt(x).*sin(theta(x));
            Y(:,2)=yc(x)+yt(x).*cos(theta(x));
        end
        function Y=lower(x)
            Y(:,1)=x+yt(x).*sin(theta(x));
            Y(:,2)=yc(x)-yt(x).*cos(theta(x));
        end
        function z=xu(x)
            the=atan((2*m/p^2).*(p-(x)));
            z=x-yt(x).*sin(the);
        end
        function z=yu(x)
            the=atan((2*m/p^2).*(p-(x)));
            ycam=m.*x./p^2.*(2*p-(x./c));
            z=ycam+yt(x).*cos(the);
        end
        function z=theta(x)
               z(x<p)=atan((2*m/p^2).*(p-(x(x<p))));
               z(x>=p)=atan((2*m/(1-p)^2)*(p-(x(x>=p)./c)));
        end
        function z=yt(x)
            z=5*t*c*((d(1)*(x./c).^0.5)+(d(2)*(x./c))+(d(3)*(x./c).^2)+(d(4)*(x./c).^3)+(d(5)*(x./c).^4));
        end
        function z=yc(x)
               z(x<p)=m.*x(x<p)./p^2.*(2*p-(x(x<p)./c));
               z(x>=p)=m.*((c-x(x>=p))./(1-p)^2).*(1+(x(x>=p)./c)-2*p);
        end
    end