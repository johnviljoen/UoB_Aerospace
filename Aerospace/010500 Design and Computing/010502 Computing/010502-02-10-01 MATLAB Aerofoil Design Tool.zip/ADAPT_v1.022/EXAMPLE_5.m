%EXAMPLE_5.m
script={'IDset.target=''NACA4412'';',... %set target to NACA4412
'opt([],[],''VGK'',''ID'')',... %run inverse design with VGK
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{8},NACA0012,[0.7,NaN,0],script); %run ADAPT