%EXAMPLE 1
script={'OPTset.pena=0.1;',... %set constant for area constraint to 0.1
    'VGKset.viscous=1;',... %set VGK to viscous
'opt([],[],''VGK'',''OPT'')',... %run optimisation using VGK
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{8},NACA4412,[0.7,1e7,0],script); %run ADAPT