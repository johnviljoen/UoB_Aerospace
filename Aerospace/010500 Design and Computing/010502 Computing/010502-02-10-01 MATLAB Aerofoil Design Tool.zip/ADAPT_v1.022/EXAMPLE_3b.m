%EXAMPLE 3b
[~,LOG]=RBFLS0012(RAE2822,S{3},0,0);
RAE2822_RBF10=LOG.a_sol;
script={'IDset.target=''RAE2822_RBF10'';',... %set target to RAE2822 (in design space)
    'IDset.iter=200;',... %increase maximum number of iteratiosn to 200
'opt([],[],''POTFLOW'',''ID'')',... %run inverse design with panel code
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{3},NACA0012,[NaN,NaN,3],script); %run ADAPT (note Mach and Re not used in this case)