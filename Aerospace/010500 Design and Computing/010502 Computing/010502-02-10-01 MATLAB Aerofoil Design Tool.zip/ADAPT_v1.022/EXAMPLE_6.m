%EXAMPLE_6.m
script={'IDset.target=''NACA4412'';',... %set target to NACA4412
'opt([],[],''XFOIL'',''ID'')',... %run inverse design with XFOIL
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{11},NACA0012,[0.2,1e7,0],script); %run ADAPT
