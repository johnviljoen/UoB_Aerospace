%EXAMPLE 2
script={'DV=symmetricDV;',... %set design variables to symmetric
    'OPTset.pena=0.1;',... %set constant for area constraint to 0.1
    'OPTset.pencl=0;',... %set constant for lift constraint to 0
    'OPTset.pencm=0;',... %set constant for pitching moment constraint to 0
'opt([],[],''VGK'',''OPT'')',... %run optimisation using VGK
'export(''logfile'')'}; %export data to logfile
load('S100'); %load RBF initial point positions
load('Aerofoils'); %load example aerofoils
ADAPT(S{11},NACA0012,[0.85,0,0],script); %run ADAPT